/*######################################################################
 *
 *  FILE: ffmpeg_capture.c
 *  AUTHOR: Orlando Moreno
 *
 *  DESCRIPTION:
 *	This code will produce a cgi file with the following function:
 *		
 *		1. Live video capture and segmentation from camera.
 *
 *	The ffmpeg capture page will contain input text fields for various
 *	parameters that will then be passed to the system call of capture.sh. 
 *
 *  LAST MODIFIED: 12/09/2014 [OM]
 *######################################################################
*/

#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

//######### CONSTANTS DEFINITION
#define SERVER_NAME cgiServerName	//The server name is set in the mongoose config file.
#define BufferLen 1024
#define FILELOCATION "../captures/ "//There must be a space for the last
									 //character in the quotations since 
									 //bash script input parameters are
									 //delimited by spaces.

//######## PROTOTYPES
void handle_capture();
void ShowForm();

//&&&&&&&&&&&&&&&&&&&&&&&& THE MAIN FUNCTION &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int cgiMain() 
{
  /* Send the content type, letting the browser know this is HTML */
  cgiHeaderContentType("text/html");
  /* Top of the page */
  fprintf( cgiOut, "<HTML><HEAD>\n" );
  fprintf( cgiOut, "<TITLE>Capture</TITLE></HEAD>\n" );
  //fprintf( cgiOut, "<BODY><H3>%s DashBoard</H3>\n", SERVER_NAME );

  fprintf( cgiOut, "<BODY>\n");
 
//  fprintf( cgiOut, "<hr />\n" );

//This handles the event when the capture button is pressed:

	if(cgiFormSubmitClicked("capture") == cgiFormSuccess){
		handle_capture();
		fprintf( cgiOut, "\n");
	}

  /* Now show the form -- i.e The basic/default web interface to this program*/
  ShowForm();
        
  /* Finish up the page */
  fprintf( cgiOut, "</BODY></HTML>\n" );
  return 0;
}



//&&&&&&&&&&&&&&&&&&&&&&&& HANDLER &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//This is the handler for the capture button.  
//This will call the bash script to activate the webcam of the host and save 
//the file to the /WVSNP_player/video.segments/live/ directory. If VOD is
//specified for the type of video, then the video must be located in the
///WVSNP_player/video.segments/vod directory.



void handle_capture(){

	char syscall[100];	//To be used in system call to script
	char filename[100];	//The variable that is the filename of the picture taken
	char segmentSize[10];//Specifies the segment size
	char bitRate[20];	//Specifies the bitrate of the output video segment
	char videoType[10];  //Specifies the type of video, either Live or Video-On-Demand (VOD)
	char maxSegment[10]; //Specifies the maximum number if segments to be shown to player
	char inputFile[64]; //Specifies the input file to segment (only applies to VOD)

	strcpy(syscall, "/home/root/wvsnp_dashboard_v1.0.3/www/CGI/c.sh ");	//Starting with the command to the script.
	//strcat(syscall, FILELOCATION);
	
	cgiFormStringNoNewlines( "segment", segmentSize, 4);
	//printf("%s\n", segmentSize);

	//puts("hello world\n");
	strcat(segmentSize, " ");
	cgiFormStringNoNewlines( "bitrate", bitRate, 13);
	strcat(bitRate, " ");
	cgiFormStringNoNewlines( "sname", filename, 64 );	//Getting the requested  filename from the form
	strcat(filename, " ");
	cgiFormStringNoNewlines( "type", videoType, 5);
	strcat(videoType, " ");
	cgiFormStringNoNewlines( "maxseg", maxSegment, 5);
	strcat(videoType, " ");
	cgiFormStringNoNewlines( "inputvid", inputFile, 65);

	strcat(syscall, segmentSize);
	//printf("Segmentsize is :%s\n",segmentSize);
	strcat(syscall, bitRate);
	//printf("bitRate is :%s\n",bitRate);
	strcat(syscall, filename);	//Concatenating the filename to the system call
	//printf("filename is :%s\n",filename);
	strcat(syscall, videoType);
	//printf("videoType is :%s\n",videoType);
	strcat(syscall, maxSegment);
	//printf("maxSegment is :%s\n",maxSegment);
	strcat(syscall, inputFile);
	//printf("inputFile is :%s\n",inputFile);

	system(syscall);		//calling the bash script with filename as parameter

	printf("The capture has started at \"video.segments/live/%s-0.mp4\"", filename);	//Confirmation Message
}


//&&&&&&&&&&&&&&&&&&&&&&&& HTML FORM DISPLAY &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
void ShowForm()
{
  fprintf( cgiOut, "<!-- 2.0: multipart/form-data is required for file uploads. -->");
  fprintf( cgiOut, "<form method=\"POST\" enctype=\"multipart/form-data\" ");
  fprintf( cgiOut, " action=\"");
  cgiValueEscape(cgiScriptName);
  fprintf( cgiOut, "\">\n");

  //HTML data for the capture function
  fprintf( cgiOut, "Capture Filename&nbsp;:");
  fprintf( cgiOut, "\nFormat: filename-[INT_QUALITY_MAX]-[INT_QUALITY_MIN]");
  fprintf( cgiOut, "<input type=\"text\" name=\"sname\" size=\"10\"><br />");

  fprintf( cgiOut, "Video Type (LIVE or VOD):");
  fprintf( cgiOut, "<input type=\"text\" name=\"type\" size=\"10\"><br />");

  fprintf( cgiOut, "Input video file (if using VOD):");
  fprintf( cgiOut, "<input type=\"text\" name=\"inputvid\" size=\"10\"><br />");

  fprintf( cgiOut, "Segment Size (in seconds):");
  fprintf( cgiOut, "<input type=\"text\" name=\"segment\" size=\"10\"><br />");

  fprintf( cgiOut, "Max number of segments (if using live video):");
  fprintf( cgiOut, "<input type=\"text\" name=\"maxseg\" size=\"10\"><br />");

  fprintf( cgiOut, "Video bitrate (200k, 1000k, 1500k, etc):");
  fprintf( cgiOut, "<input type=\"text\" name=\"bitrate\" size=\"10\"><br />");

  fprintf( cgiOut, "<p>Press to start ffmpeg_capture: \n");
  fprintf( cgiOut, "<input type=\"submit\" name=\"capture\" value=\"capture\">\n");
  fprintf( cgiOut, "<p>\n" );
  fprintf( cgiOut, "</form>\n" );
}
