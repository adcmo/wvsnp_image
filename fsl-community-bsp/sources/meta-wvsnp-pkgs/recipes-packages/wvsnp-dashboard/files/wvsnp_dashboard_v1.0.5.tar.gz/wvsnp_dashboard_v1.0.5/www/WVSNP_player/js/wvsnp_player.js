/** @file wvsnp_player.js
 *  @brief A video player that plays segmented videos continuously and seamlessly
 * 
 * Copyright 2012-2014 ASU | IA Fulton School of Electrical, Computer, and Energy Engineering.
 * All Rights Reserved.
 *
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 * http://www.opensource.org/licenses/gpl-license.html
 * and
 * http://www.gnu.org/copyleft/gpl.html
 * 
 * This has been inspired by Adolph Seema using his "crude video player" as a 
 * starting point, which can be found at:
 * http://dl.dropbox.com/u/41221188/html5_ajax_test.html
 * 
 * Copious resources for XHR2 and File System API and File API were used, most 
 * helpful were HLML5Rocks:
 * http://www.html5rocks.com/en/tutorials/file/xhr2/
 *  , http://www.html5rocks.com/en/tutorials/file/dndfiles/
 * and 
 * http://www.html5rocks.com/en/tutorials/file/filesystem/
 * 
 * Research for implementing the canvas element was:
 * http://html5doctor.com/video-canvas-magic/ 
 * and
 * http://answers.oreilly.com/topic/2896-how-to-display-a-video-on-html5-canvas/ 
 * 
 * Description: This is an HTML5 video player that plays segmented videos 
 * seamlessly. It utilizes the File System API to save the segmented video in a 
 * temporary local directory. This "sandbox" acts as a buffer for the segments. 
 * To play the segments seamlessly, this video player utilizes two video elements
 * and a canvas element. The two video elements are hidden and loaded with video 
 * segments. The video elements are rendered to the canvas. When one video ends 
 * the next video element is immediately rendered to the canvas.
 * 
 */

 
/** @brief creates a HTML5 player-object that is ready to play out the video
 * 
 * @param v_id	- integer id of this player
 * @param v_el	- the actual player-element (HTML5 <video></video> element)
 * @param v_src	- the source-element for this player
 * 
 * .............................................................................
 */

function Player(v_id, v_el, v_src) {

	// determine which functionality of the player to use
	
	// NO FILESYSTEM version (and BLOB)
	this.non_fs_version = (!window.requestFileSystem /* || debugTriggerNonFilesystem */);
	this.logger(this.non_fs_version ? 'Using No-FileSystem version' : 'Using Filesystem version');
	
	// left further development of non-filesystem out for future work
	/*if(this.non_fs_version)
	{
		this.use_no_fs_blob = !use_blobbuilder;
		this.logger( (this.use_no_fs_blob ? 'use blob constructor' : 'use blob builder') );
	}*/	
	
	// video and instance specific definitions
	this.video_id = v_id;
	this.video = v_el;
	this.video_src_string = v_src;
	
	// init flags (NOTE: setup_html moved to UI module!)
	this.initialized = false;
	this.triggered_init_process = false; //!< has the play-button been clicked initially? (do not call init() multiple times before flag "initialized" has been set)
	this.setup_detected = false;
	
	// ff and rw flags and data
	this.ff_time; //!< user clicked on buffer bar, this will contain the "exact" calcuated second of the stream to ff or rw to
	this.start_count_running = false; //!< Determines if get_current_time is running
	this.max_duration = 0; //!< Used in ff_rw function to determine if ff request is within bounds  
	this.segment_end_time = new Array(); //!< Array for storing the duration of each segment (during buffering, calculate more exact time-marks)
	this.typ_duration = -1; //!< typical duration of one segment (every segment SHOULD have this duration in order for ff and rw to work somehwat accurately!)
	this.last_segment_duration = -1; //!< duration of the last segment in stream (only segment allowed to vary from typical duration)
	this.current_time;
	
	// NOTE: all buffering-flags and variables moved to "Buffering" module!)
	
	// other flags
	this.is_getting_future_segments = false;
	this.read_file = true;
	this.live = true;
	this.liveBufferTimer_initalized = false;
	this.live_count_baseline;
	this.leave_live_time;
	this.reader_playback_extension = ""; //!< only used in live playback mode during vod
	this.live_episode = 1;
	
	this.start_end_of_segment_timer = false; //!< Determines if the end_of_segment_timer has been called
	this.segment_transition = false;

	// indices for writing and reading
	this.writer_video_index = 0; //!< Index of videos that have been written to the local directory
	this.reader_video_index = 0; //!< Index of next video to be read and played.  
	this.video_to_play_index = 0; //!< Keeps track of the index of the current video that is playing   
	this.play_episode = 1; //!< TODO: still needed? Seems only to be used in ff_rw and not even there
	this.last_in_buffer = 0; //!< for the check to delete buffer function
	// in case something changes, save the segment that is CURRENTLY loaded here. E.g. during fast forwarding beyond the buffering point, Player.writer_video_index might change
	// if there are download-processes running while the change is made, "invalidate" them, if they do not conform to this variable!
	// we try to avoid invalid and outdated results this way.
	this.currentSegmentLoaded = -1;
	
	// information about current stream
	this.v_dir; //!< path to directory on server-side where all segments are stored
	this.video_formats; //!< array with supported video formats, e.g. ["mp4", "webm", "ogg", "hls"]
	this.v_container; //!< selected video-format (if not hls, see "hls_name" for this special case)
	this.first_index;
	this.last_index;
	this.play_back_option;
	this.v_name;
	this.v_basename; //!< basename of the video, e.g. "filename" in "filename-1-0-0-VOD-300-1.mp4"
	this.hls_name; //!< name for HLS-file (like "filename-VOD", without any quality or segment-count parameters)
	this.v_full_name; //!< will contain the full basename of the given source-video - without extension or path
	this.v_quality = 1; //!< quality of the video (integer, contains the layer-id. per default there are two layers: 0 (low) and 1 (high)
	this.pres_int_min = 0; //!< implicit definition, should be static
	this.pres_int_max = 1;
	this.segment_quality = new Array(); //!< will contain the selected quality, layer for each segment
	
	this.waiting_for_next_segment = false;
	// storing the index of the video-segments that are currently referenced by each hidden video-element
	// needed for additional checking if video needs to be loaded
	this.video_elements_index = [-1, -1];
	
	// flags for smoother segment-transition
	// NOTE: outdated, not used any more. Used for non-filesystem-version on Android.
	// might still help even for filesystem-version to get rid of 30-40ms "gaps".
	// will only be noticable if the video has an audio-line
	this.videobootstraptime = -1;
	this.videotimeout = -1; // used for fading one video into the next
	// saves the miliseconds into the current video when the next video should be started
	// includes browser-delay to start the video, so the transisions are as seamless as possible
	this.videostarted = new Array(); // is the video already started?
	this.videoplaying = new Array(); // for state-handling save if the first valid "timeupdate" call was captured
	
	// UI Module
	//this.ui = new Player_UI(this, (detectedOS != "Android")); //!< initialise player ui module
	this.ui = new Player_UI(this, true); //!< initialise player ui module (NOTE: we always use canvas for now)
	// Buffering Module
	this.buffering = new Player_Buffering(this); //!< initialise buffering-module
	
	// INIT player, start parsing video-source
	this.parseVideoSource(this, this.video_src_string); // parse the source-element-string in order the get the actual video-segment-paths
}

/** @brief Builds the URL for fetching the video-segments
 * 
 * delegates the parsing of the video-source-link and creates an URL
 * in order to fetch all segments of the video. Will contain the suitable
 * quality-layer.
 * 
 * @param src_string - Source string to be parsed. 
 * 
 * create_video_src_string is called when the video player is initialized or the quality should
 * be changed
 * .............................................................................
 */
Player.prototype.parseVideoSource = function (that, src_string) {

	// 0 = no supported codec found
	// 1 = setup native video player (HLS, MPEG-DASH or non-WVSNP-video)
	// 2 = setup WVSNP video player
	// 3 = browser not supported
	// 4 = WVSNP not supported but HLS
	// 5 = WVSNP not supported but MPEG-DASH
	var supportedVideoFound = 0;

	if (src_string != null)
	{
	
		var regexpSearch = /^(.*?)\/([^\/]+?)-([0-9]+)-([0-9]+)-(.+?)-([0-9]+)-([0-9]+)\.(.+?)$/g;
		if(src_string.search(regexpSearch) == -1)
		{
			// #####################################
			// ### CASE 1: regular video-file    ###
			// #####################################
			// it is a regular file which does not follow the WVSNP DASH naming conventions

			var regexpDirFilename = /^(.*?)\/([^\/]+?)\.([^\.]+?)$/g;
			// check if for native video there are supported codecs by this browser
			var supportedCodecs = that.checkForOtherCodecs(that, src_string.replace(regexpDirFilename, '$1/'), src_string.replace(regexpDirFilename, '$2.$3'));
			
			// setup HLS as default on Safari
			if(supportedCodecs[0].contains('hls') && detectedBrowser == "Safari")
			{
				supportedVideoFound = 1;
				that.ui.setupNativeVideo(that, supportedCodecs[2]);
			}
			// setup MPEG-DASH if supported
			else if(supportedCodecs[0].contains('mpd'))
			{
				supportedVideoFound = 1;
				that.ui.setupNativeVideo(that, supportedCodecs[3], true);
			}
			else
			{
				// check if there are any supported codecs at all
				if(supportedCodecs[0].length > 0)
				{
					supportedVideoFound = 1;
					that.logger('Setup native video for non HLS');
					// setup the first found supported video-format, if found
					that.ui.setupNativeVideo(that, supportedCodecs[1] + '/' + src_string.replace(regexpDirFilename, '$2') + '.' + supportedCodecs[0][0]);
				}
			}
		}
		else
		{
			// #####################################
			// ### CASE 2: WVSNP name convention ###
			// #####################################
			/*
				format: path/to/segment/folder/filename-6-1-VOD-30-3.mp4
				regex: /^(.*?)\/([^\/]+?)-([0-9]+)-([0-9]+)-(.+?)-([0-9]+)-([0-9]+)\.(.+?)$/g
				=> $1: path to directory where the segments are located    => "path/to/segment/folder"
				=> $2: basename of video                                   => "filename" 
				=> $3: maximum quality presentation layer                  => "6"
				=> $4: selected presentation layer                         => "1"
				=> $5: type of video                                       => "VOD"
				=> $6: maximum video segments                              => "30"
				=> $7: start segment                                       => "3"
				=> $8: video extension                                     => "mp4"
			*/

			// -----------------------------
			// --- PATH AND NAME
			// -----------------------------

			//parse the video directory and save global var
			that.v_dir = src_string.replace(regexpSearch, '$1/');
			that.logger("var v_dir = " + that.v_dir);

			//get the filename without extension or path and save in v_full_name
			that.v_full_name = src_string.replace(regexpSearch, '$2-$3-$4-$5-$6-$7');
			that.logger("var v_full_name = " + that.v_full_name);

			//parse the video name and save global var
			// contains the file-name without path, extension, or index of starting-segment
			// "filename-MAXQUALITY-MODE" or "filename-6-VOD"
			that.v_name = src_string.replace(regexpSearch, '$2-$3-$4-$5-$6-');
			that.v_basename = src_string.replace(regexpSearch, '$2');
			that.logger("var v_name = " + that.v_name);

			// set v_container to invalid, so we can do a browser-check (see last part of function underneath)
			that.v_container = -1;

			// -----------------------------
			// --- INDEX
			// -----------------------------
		
			//parse the index from which to start
			that.first_index = 1;
			//set the video to play index, which at the start, is the same as the first_index
			that.video_to_play_index = parseInt(src_string.replace(regexpSearch, '$7'));
			//parse the episode max_int
			that.last_index = parseInt(src_string.replace(regexpSearch, '$6'));


			// -----------------------------
			// --- PLAYBACK MODE (LIVE, VOD)
			// -----------------------------

			//parse the mode
			that.play_back_option = src_string.replace(regexpSearch, '$5');
		
			// -----------------------------
			// --- QUALITY LAYERS
			// -----------------------------
		
			// now parse the quality-settings (presentation-layers of minimum and maximum quality)
			//parse the pres_int_min and save global var
			//parse the pres_int_man and save global var
			that.pres_int_max = parseInt(src_string.replace(regexpSearch, '$3'));
			that.v_quality = parseInt(src_string.replace(regexpSearch, '$4'));
			// initialise quality and buffered-segments array
			that.buffering.bufferedSegmentsInit(that);
		
			/*
			// -----------------------------
			// --- SUPPORTED FORMATS
			// -----------------------------
			*/
			var supportedCodecs = that.checkForOtherCodecs(that, that.v_dir, src_string.replace(regexpSearch, '$2-$3-$4-$5-$6-$7.$8'));
			if(supportedCodecs[0].length > 0)
			{
				// if no HLS AND no MPEG-DASH is supported AND no filesystem API (or rather WVSNP capability), exit the script here
				if(!fullyFilesystemCompatible && (!supports_media('mpeg-dash') || !supportedCodecs[0].contains('mpd')) && (!supports_media('application/x-mpegURL;', "video") || !supportedCodecs[0].contains('hls')))
				{
					supportedVideoFound = 3;
				}
				/*// if no WVSNP-capability is given BUT HLS is supported, continue
				else if(!fullyFilesystemCompatible && supports_media('mpeg-dash') && supportedCodecs[0].contains('mpd'))
				{
					supportedVideoFound = 5;
				}*/
				// if no WVSNP-capability is given BUT HLS is supported, continue
				else if(!fullyFilesystemCompatible && supports_media('application/x-mpegURL;', "video") && supportedCodecs[0].contains('hls'))
				{
					supportedVideoFound = 4;
				}
				else {
					that.v_dir = supportedCodecs[1];
					that.video_formats = supportedCodecs[0];
					supportedVideoFound = 2;
				}
			}
		}
	}
	
	if(supportedVideoFound == 0)
	{
		// although we do not have a compatible video, run the setup-function here
		// that way the dynamic-source input-field gets setup, so the user has a change to change the source
		alert("Either the linked video does not exist or your browser does not support any provided media! Please try a different stream or browser!");	
		that.ui.setupNativeVideo(that, src_string);
	}
	else if(supportedVideoFound == 2)
	{
		//call setup function
		that.setup_detected = true;
		that.logger('PluginDetect.OS: ' + detectedOS);

		that.v_container = that.video_formats[0];
		
		// init the file-system (i.e. create directory on file-system, or do nothing in non-filesystem version)
		// NOTE: moved outside "setup" function since it moved into an encapsulated UI module, as this has nothing to do with UI.
		that.initFilesystem(that);
		// setup the HTML for WVSNP
		that.ui.setup(that);
		return true;
	}
	else if(supportedVideoFound == 3)
	{
		// although we do not have a compatible video, run the setup-function here
		// that way the dynamic-source input-field gets setup, so the user has a change to change the source
		alert("Your browser does not support the WVSNP format or any alternative media!");	
		that.ui.setupNativeVideo(that, src_string);
	}
	else if(supportedVideoFound == 4)
	{
		// setup native HLS video, but alert the user that this is just a temporary alternative
		// future support for WVSNP is anticipated
		alert("Your browser does not support the WVSNP format! For now you'll see a HLS stream as alternative.");	
		that.ui.setupNativeVideo(that, supportedCodecs[2]);
	}
	else if(supportedVideoFound == 5)
	{
		// setup "native" MPEG-DASH video with dash.js, but alert the user that this is just a temporary alternative
		// future support for WVSNP is anticipated
		alert("Your browser does not support the WVSNP format! For now you'll see a MPEG-DASH stream as alternative.");	
		that.ui.setupNativeVideo(that, supportedCodecs[3], true);
	}
	return false;
}

/** @brief triggers the start of streaming
 *
 * will be used by the "play_toggle" button as well as dynamic source handler.
 * will create video-elements and "initialises" the player.
 */
Player.prototype.triggerPlaybackStart = function (that) {

	// we could use that.initialized here as flag, but getStreamDuration might take some seconds
	// to finish until init() is called. This flag makes sure, the user cannot trigger the init process
	// more than once, even if one hits the play-button multiple times before getStreamDuration has finished
	// NOTE: using dynamic source, this is fired immediately, but the play-button still has an eventlistener, that
	// might call this method again, afterwards.
	// This is a bit ugly, but it will not lead to any harm, as the triggered_init_process is set already.
	if(!that.triggered_init_process) {
		that.triggered_init_process = true;
		that.ui.create_video_elements(that);

		//! initialize the video object
		// calculate total length if it is no LIVE video
		if(that.play_back_option == "LIVE") {
			that.init(that, that.video_to_play_index);
		}
		else {
			that.getStreamDuration(that);
		}
	}
}

/** @brief 
 * 
 * Starts primary functions of the video object that was requested to play
 * 
 * @param start_index - 
 * 
 * @param that - 
 * 
 * .............................................................................
 */
Player.prototype.init = function (that, start_index) {

	if(!that.initialized) {
		that.initialized = true;
		that.writer_video_index = start_index;
		that.logger("start index " + start_index);
		that.logger("init called for v_id " + that.video_id);
		// Create wrapper div and give class name  and dive id
		that.ui.cl = new CanvasLoader('player_wrapper_' + that.video_id, undefined, that.video_id); //! Creates an object for the loading animation
		that.ui.initEventListeners(that);
		that.ui.loadingAnimation(that); //! Starts the loading animation
		
		// Checks if file on server exists. If it does, it sets off 
		// events to save to local storage and check buffer. */
		that.buffering.checkForFile(that, that.writer_video_index);
		if (that.play_back_option == 'LIVE') {
			that.ui.liveButtonToggle(that, "on", "#FFFF00");
		}
		that.buffering.buffer_segments_ahead = 3; //(that.play_back_option == "LIVE") ? 2 : 3;
		that.buffering.initialiseReader(that, start_index, start_index, that.buffering.buffer_to_play);
	}
}

Player.prototype.getLiveCountBaseline = function (that) {
	that.logger("live time called");
	var d = new Date();
	that.live_count_baseline = d.getTime();
}

Player.prototype.getLiveTime = function (that) {
	var d = new Date();
	var time_diff = d.getTime();
	time_diff = (time_diff - that.live_count_baseline) / 1000;
	//return time_diff + that.leave_live_time;
	return time_diff;

}

/** @brief listener if a specific video-index has been played out already
 * for usage on the non-filesystem version. Is not needed right now, as
 * the "non-filesystem" version is not further developed actively for now.
 */
Player.prototype.playingListener = function(that, playedOutIndex) {
	if(!that.videoplaying.contains(playedOutIndex))
	{
		that.videoplaying.push(playedOutIndex);
		// hide all other video-elements in the non-fs version
		//that.ui.hideVideoElements(that, playedOutIndex);
	}
};

Player.prototype.videoTimeupdateFunction = function (that, video_element) {

	// for the first video, capture the bootstraptime
	if(video_element.currentTime > 0.0 && that.videotimeout == -1)
	{
		that.videotimeout = (new Date().getTime() - that.videobootstraptime.getTime()) / 1000;
	}

	that.segment_transition = true;
	//if (video_element.currentTime >= Math.max(video_element.duration * 0.5, (video_element.duration - that.videotimeout)) && !that.videostarted.contains(that.video_to_play_index)) {
	if(video_element.ended) {
	
		// security measure, make sure we only listen to the current video-element (current play-index)
		// make sure no other videos interfere
		if((that.getVideoToPlayIndex(that) % 2 == 0 && !video_element.getAttribute('id').match(/wvsnp_video1_(.*?)/gi)) ||
			(that.getVideoToPlayIndex(that) % 2 == 1 && !video_element.getAttribute('id').match(/wvsnp_video2_(.*?)/gi)))
			return;
	
	
		// clean-up measurement for NO-Filesystem version. Might need retouching?
		// Leave for future work..
		/*if(that.non_fs_version)
		{
			// TODO: with removing the previous video elements, the buffering process needs
			// to be re-triggered, if one goes back in the video!
			// if exists, delete previous video element to save memory ("clean up")
			var previous_video_element = that.ui.getDesignatedVideoElement(that, that.video_to_play_index-1);
			if(previous_video_element)
			{
				that.deleteFileRequest(that, that.getRemoteFileName(that, that.video_to_play_index-1));
			}
		}*/

		that.videostarted.push(that.video_to_play_index);
		//that.logger("video_element  " + that.video_to_play_index + " ended");
		// At the end of the episode call reset_player function. Reset_player 
		// function determins current state (eg vod, live etc)
		if (that.last_index == that.video_to_play_index) {
			that.logger("that.last_index == that.video_to_play_index");
			var play_index = that.getVideoToPlayIndex(that);
			var real_play_index = that.calcRealToPlayIndex(that, that.video_to_play_index);
			if (real_play_index < (that.writer_video_index - 1) && !that.buffering.rewindFastForward_in_progress) {
				that.resetPlayer(that, that.play_back_option);
				that.segment_transition = false;
			} else if (real_play_index == (that.writer_video_index - 1) && !that.buffering.rewindFastForward_in_progress) {
				that.logger("real_play_index == (that.writer_video_index-1)");
				if (that.play_back_option == 'LIVE' && that.buffering.initialiseReader_running == false) {
					that.buffering.initialiseReader(that, (real_play_index + 1), (real_play_index + 1), that.buffering.buffer_to_play);
				} else if (that.play_back_option == "VOD" || that.play_back_option == "LOOP") {
					that.resetPlayer(that, that.play_back_option);
					that.segment_transition = false;
				}
				document.getElementById("play_toggle_img_" + that.video_id).src = that.ui.base64images.play_control;
				that.segment_transition = false;
				if (that.play_back_option == 'LIVE' && that.live == true) {
					that.ui.liveButtonToggle(that, "off", "FFFF00");
					that.live = false;
				}
			}
		} else if (that.video_to_play_index < that.last_index) {
			var real_play_index = that.calcRealToPlayIndex(that, that.video_to_play_index);
			if (real_play_index < (that.writer_video_index - 1) && !that.buffering.rewindFastForward_in_progress) {
				var play_index = that.getVideoToPlayIndex(that);
				play_index++;
				that.setVideoToPlayIndex(that, play_index);
				
				// double check that the video is really loaded that we want to play
				if(that.video_elements_index[ play_index % 2 ] != play_index) {
					that.logger('Video ' + play_index + ' not loaded yet! Load it now and then play it');
					
					/*// we need to load the previous video (again?)
					that.readFileRequest(that, that.getReaderVideoIndex(that) - 1, false, function() {
						that.playPauseTimer(that, play_index);
						that.waiting_for_next_segment = true;
					});*/
					// something must have went wrong, as a "security measure" we probably shut pull out the big weapons
					// re-initiate whole buffering
					if (that.buffering.initialiseReader_running == false) {
						that.logger('Run out of segments, re-buffering!');
						that.buffering.initialiseReader(that, play_index, play_index, that.buffering.buffer_to_play);
					}
					document.getElementById("play_toggle_img_" + that.video_id).src = that.ui.base64images.play_control;
				}
				else {
					that.logger('playpausetimer ' + play_index + ' : ' + that.video_elements_index[ play_index % 2 ]);
					that.playPauseTimer(that, play_index);
					that.waiting_for_next_segment = true;
				}

				setTimeout(function () {
					// load next video already
					if (!that.buffering.rewindFastForward_in_progress) {
						that.readFileRequest(that, that.getReaderVideoIndex(that));
						that.segment_transition = false;
					}
				}, 800);
			} else if (real_play_index >= (that.writer_video_index - 1) && !that.buffering.rewindFastForward_in_progress) {
				that.logger("real_play_index == (that.writer_video_index-1)");
				if (that.buffering.initialiseReader_running == false) {
					that.logger('Run out of segments, re-buffering!');
					that.buffering.initialiseReader(that, (real_play_index + 1), (real_play_index + 1), that.buffering.buffer_to_play);
				}
				document.getElementById("play_toggle_img_" + that.video_id).src = that.ui.base64images.play_control;
				//        that.start_end_of_segment_timer=false;
				that.segment_transition = false;
				if (that.play_back_option == 'LIVE' && that.live == true) {
					that.ui.liveButtonToggle(that, "off", "FFFF00");
					that.live = false;
				}
			}
		}
	}
}


/** @brief Function that increments the live_episode global variable.
 * 
 * A function that increments the live_episode global variable
 * .............................................................................
 */
Player.prototype.incrementLiveEpisode = function (that) {
	that.live_episode++;
	that.logger("increment_live_episode CALLED live_episode = " + that.live_episode);
}


/** @brief Function that changes video reader directory.
 * 
 * Function that changes the global variable that references which directory 
 * will be utilized as the videos are loaded.
 * 
 * .............................................................................
 */
Player.prototype.changeReaderDirectory = function (that, change_playback_type) {
	if (change_playback_type == "VOD") {
		that.logger("in change_reader_directory changing to vod");
		that.reader_playback_extension = "vod_";
	} else {
		that.logger("in change_reader_directory changing to LIVE");
		that.reader_playback_extension = "";
	}
}

//Called when video is paused and states need to be updated when ff or rw
Player.prototype.pauseStatsUpdate = function (that) {
	var play_progress = document.getElementById("play_progress_" + that.video_id); //!< A global variable for the play progress element in the video controls
	var current_time_element = document.getElementById("current_time_" + that.video_id); //!< A global variable for the current time element in the video controls
	var current_video_element = that.ui.getDesignatedVideoElement(that, that.getVideoToPlayIndex(that));
	setTimeout(function () {
		//      that.logger("video element to play = " + that.getVideoToPlayIndex(that));
		current_time = that.segment_end_time[that.getVideoToPlayIndex(that)] - current_video_element.duration + current_video_element.currentTime;
		var timePercent = (current_time / that.progress_bar_duration) * 100;
		play_progress.style.width = timePercent + "%";
		//        that.logger("current_video_element is " + 
		//                    current_video_element.currentTime);
		current_time_element.firstChild.nodeValue = format_time(current_time);
	}, 100);
	//update screen
	setTimeout(function () {
		var context = document.getElementById("wvsnp_canvas_" + that.video_id).getContext("2d");
		context.drawImage(current_video_element, 0, 0, that.ui.w, that.ui.h);
		that.buffering.rewindFastForward_in_progress = false;
		// if "no-canvas" version is active, show current video element
		//that.ui.hideVideoElements(that, that.getVideoToPlayIndex(that));
	}, 100);

}



/** @brief Plays or pauses the video and calls play_functions
 * 
 * A function that plays or pauses the video. If the video 
 * is played then play_functions are called that initialize 
 * controls and timer events.
 * 
 * .............................................................................
 */
Player.prototype.playPauseButton = function (that, a_video_to_play) {
	//    that.logger("play_pause_button called");
	var current_video_element = that.ui.getDesignatedVideoElement(that, a_video_to_play);

	that.ui.putCurrentPlaybackString(that);
	var temp = that.last_index;
	if (a_video_to_play > temp) {
		that.resetPlayer(that, that.play_back_option);
	} else {
		that.logger("play_pause called, " + "segment " + a_video_to_play + " playing" + " video element = " + that.video_id);
		if (current_video_element.paused == false) {
			current_video_element.pause();
			if (that.play_back_option == 'LIVE' && that.live == true) {
				that.logger("calling change reader directory");
				that.changeReaderDirectory(that, "VOD");
				//that.getLiveCountBaseline(that);
				//that.logger("live time is " + that.live_count_baseline);
				var a_current_time = that.segment_end_time[that.getVideoToPlayIndex(that)] - current_video_element.duration + current_video_element.currentTime;
				that.leave_live_time = a_current_time;
				that.liveButtonToggle(that, "off", "FFFF00");
				that.live = false;
			}
			document.getElementById("play_toggle_img_" + that.video_id).src = that.ui.base64images.play_control;
		} else {
			// check for initialisation
			if(that.videotimeout == -1)
			{
				that.videobootstraptime = new Date();
			}
			that.ui.endLoadingAnimation(that);
			current_video_element.addEventListener("play", that.playFunctions(that), false);
			current_video_element.play();
			//that.ui.hideVideoElements(that, a_video_to_play);
			if (that.play_back_option == 'LIVE' && that.live == false) {
				//           that.leave_live_time = that.getLiveTime(that);
				that.logger("leave_live time = " + that.leave_live_time);
				//that.getLiveCountBaseline(that);
			}
			document.getElementById("play_toggle_img_" + that.video_id).src = that.ui.base64images.pause_control;
		}
	}
} //END of play_pause-----------------------------------------------------------

/** @brief called from segment end timer to start next video
 *
 * Starts the video with index a_video_to_play.
 * .............................................................................
 */
Player.prototype.playPauseTimer = function (that, a_video_to_play) {
	//that.logger("play_pause_timer called: " + a_video_to_play);
	var current_video_element = that.ui.getDesignatedVideoElement(that, a_video_to_play);
	//    var play_index = that.getVideoToPlayIndex(that);
	//    var playing_li = document.createElement("li");
	//    playing_li.innerHTML = "segment " + a_video_to_play + " playing";
	//    var playing = document.getElementById("playing");
	//    playing.appendChild(playing_li);
	//      that.logger("a_video_to_play " +  a_video_to_play + " < " + "that.last_index " + that.last_index );
	var temp = that.last_index;
	if (a_video_to_play > temp) {
		that.resetPlayer(that, that.play_back_option);
	} else {
		//that.logger("play_pause called, " + "segment " + a_video_to_play + " playing" + " video element = " + that.video_id);
		if (current_video_element.paused !== true && !current_video_element.ended) {
			current_video_element.pause();
		} else {
			current_video_element.addEventListener("play", that.playFunctions(that), false);
			//that.ui.hideVideoElements(that, a_video_to_play);
			//that.logger('Start video ' + a_video_to_play);
			current_video_element.play();
			that.ui.putCurrentPlaybackString(that);
			document.getElementById("play_toggle_img_" + that.video_id).src = that.ui.base64images.pause_control;
		}
	}
} //END of play_pause-----------------------------------------------------------

/** @brief Calls other functions that initialize controls and timer events
 * 
 * A function that that initialize controls and timer events. Checks to see
 * is some functions are already running. If they are running, then they 
 * are not called again.
 * 
 * .............................................................................
 */
Player.prototype.playFunctions = function (that) {
	//that.logger("play functions called");
	if (!that.ui.drawScreen_running) {
		that.ui.drawScreen(that);
	}

	//that.logger("called_from_write_buffering_in_progress = " + that.buffering.called_from_write_buffering_in_progress);
	if (that.non_fs_version || !that.buffering.called_from_write_buffering_in_progress) {
		that.buffering.checkBuffer(that, that.writer_video_index);
	}

	if (!that.start_count_running) {
		that.getCurrentTime(that)
	};
	//that.logger("segment timer_is_running = " + that.start_end_of_segment_timer);
	if (!that.start_end_of_segment_timer) {
		that.ui.endOfSegementTimer(that);
	}
	//  if(!start_buffered_progress_bar){buffered_progress_bar();}
} //END of play_functions-------------------------------------------------------


Player.prototype.calcRealToPlayIndex = function (that, mod_play_i) {
	return ((that.last_index - that.first_index + 1) * (that.play_episode - 1) + mod_play_i);
}

//called when in live_vod mode when the end of an vod episode has been reached
//Dialog box give user the option to restart the current episode or go to live time.
Player.prototype.endOfEpisodePopup = function (that) {
	var x;
	var r = confirm("You have reached the end of the current episode. Press \"OK\"" + "to restart the current episode over or \"Cancel\" to start live playback");
	if (r == true) {
		that.loop(that);
		that.logger("play episode =" + that.play_episode + " live episode = " + that.live_episode);
	} else {
		that.logger("You pressed Cancel!");

		var live_time = that.getLiveTime(that);
		that.logger("cur_live_time = " + live_time);
		var episode_duration = that.getEpisodeDuration(that);
		that.logger("episode_duration = " + episode_duration);
		that.play_episode++;
		that.logger("play_episode incremented = " + that.play_episode);
		var mod_rw_ff_time = that.getModTime(that, live_time, episode_duration);
		var ep_start_segment = that.segmentSearch(that, mod_rw_ff_time);
		that.calculateBufferStatusBar(that, ep_start_segment, true);
		that.vodDirNewEpisode(that);
		var mod_play_index = that.getVideoToPlayIndex(that);
		var play_index = that.calcRealToPlayIndex(that, mod_play_index);
		that.liveRewindFastForward(that, 9999999, 0, 0, false, 0, mod_play_index, play_index);
		that.logger("play episode =" + that.play_episode + " live episode = " + that.live_episode);
		//(that, rw_ff_time, mod_rw_ff_time ,find_segment, video_is_paused, a_current_time, mod_play_index, play_index)
	}
}

//Called at the end of the episode, to ready the player for 
Player.prototype.resetPlayer = function (that, playback_option, noalert) {
	//!< A local variable for the play progress element in the video controls
	var play_progress = document.getElementById("play_progress_" + that.video_id);
	//!< A local variable for the current time element in the video controls
	var current_time_element = document.getElementById("current_time_" + that.video_id);
	//get the video to play index*** first for VOD not for LIVE
	//that.logger("video to play index " + that.video_to_play_index);
	if (that.play_back_option == 'VOD') {
		if(!noalert) alert("The End");
		
		// do not reset player if it is the "no-filesystem" API, as the videos have been deleted
		if(!that.non_fs_version)
		{
			that.rewindFastForwardCase4(that, true, that.first_index, 0);
			//that.readFileRequest(that, that.first_index);
			that.video_to_play_index = that.first_index;
			that.reader_video_index = that.first_index;
			play_progress.style.width = 0 + "%";
			//        that.logger("current_video_element is " + 
			//                    current_video_element.currentTime);
			current_time_element.firstChild.nodeValue = format_time(0);
		}
	} else if (that.play_back_option == 'LOOP') {
		that.loop(that);
	} else if (that.play_back_option == 'LIVE') {
		that.logger("reset LIVE called");
		if (that.live) {
			that.play_episode++;
			that.logger("play episode =" + that.play_episode + " live episode = " + that.live_episode);
			that.calculateBufferStatusBar(that, 0, true);
			that.loop(that);
			that.vodDirNewEpisode(that);
		} // live stats is true then continue on
		else {
			that.endOfEpisodePopup(that);
		}
	}
	that.ui.drawScreen(that);
}


//called from reset function, for loop playback
Player.prototype.loop = function (that) {
	that.video_to_play_index = that.first_index;
	that.reader_video_index = that.first_index;
	that.logger("video to play index " + that.video_to_play_index);
	that.readFileRequest(that, that.first_index);
	that.logger("reset LOOP called");
	setTimeout(function () {
		that.playPauseTimer(that, that.first_index);
		that.readFileRequest(that, that.reader_video_index);
	}, 300);
}

Player.prototype.exitFunction = function (that) {
	that.logger("on page hide called");
	for (var i = that.last_in_buffer; i < that.writer_video_index; i++) {
		// TODO: hand over file name?
		//that.delete_file_request(that);
	}
}

//123456789012345678901234567890123456789012345678901234567890123456789012345678