/** @brief puts the current original path of the segment that is played back into a div
 */
Player_UI.prototype.putCurrentPlaybackString = function (that) {
	
	var playback_string_container = document.getElementById('current_playback_segment');
	// get the current path to the original source
	var currentPlaybackString = that.getRemoteFileName(that, that.video_to_play_index);
	playback_string_container.innerHTML = currentPlaybackString;
}

/** @brief Renders a frame from the current_video_element to the canvas.
 * 
 * A function that renders a frame from the current_video_element to the canvas.
 * It calls its self every 33ms. The is approximately 30 frames per second.
 * 
 * .............................................................................
 */
Player_UI.prototype.drawScreenNoCanvas = function (that) {
	that.drawScreen_running = true;
	
	var oldVideoSegment = -1;
	//that.logger("draw screen called ");
	var q = window.setInterval(function () {
		/*var tmp_current_video_element = that.ui.getDesignatedVideoElement(that, that.video_to_play_index);
		
		if(tmp_current_video_element == null || tmp_current_video_element.paused || tmp_current_video_element.ended)
			return;
		
		// this is the canvas-version, so hide the current video in fullscreen
		// in case we are using the "no-filesystem" version concurrently
		if(that.ui.is_fullscreen || !that.non_fs_version)
		{
			//tmp_current_video_element.style.display = 'none';
		}
			
		//var context = document.getElementById("wvsnp_canvas_" + that.video_id).getContext("2d");
		//context.drawImage(tmp_current_video_element, 0, 0, that.ui.w, that.ui.h);*/
		
		// only update if video-segment changed
		if(oldVideoSegment != that.video_to_play_index) {
			oldVideoSegment = that.video_to_play_index;
			that.ui.hideVideoElements(that, that.video_to_play_index);
		}
		
	}, 50); // TODO: only every 42ms? 24 fps video. Is there a way/method to determine this dynamically?
}

/** @brief Creates a full screen view of the video or reverts back to the 
 *    standard view.
 * 
 * A function that creates a full screen view of the video or reverts back to
 * the standard view.
 * 
 * .............................................................................
 */
Player_UI.prototype.fullscreenSpecificCanvas = function (that, wants_fullscreen) {
	//    that.logger("fullscreen called " + that.ui.is_fullscreen);
	/*! Set up styles for fullscreen */
	var can_fullscreen = false; //!< Determines the browser has full screen capabilities
	var loaderObj = document.getElementById("canvasLoader_" + that.video_id);
	var wrapper = document.getElementById('player_wrapper_' + that.video_id);
	var video_controls = document.getElementById('video_controls_' + that.video_id);
	var canvas_element = document.getElementById("wvsnp_canvas_" + that.video_id);
	var progress = document.getElementById("progress_" + that.video_id);
	var time = document.getElementById("time_" + that.video_id);
	var play_div = document.getElementById("play_div_" + that.video_id);
	var live_div = document.getElementById("live_div_" + that.video_id);
	var dynamic_source = document.getElementById('dynamic_source_wrapper_' + that.video_id);
	var fullscreen_div = document.getElementById("fullscreen_div_" + that.video_id);
	var volumectrl_div = document.getElementById("volumectrl_div_" + that.video_id);
	var settingsctrl_div = document.getElementById("settingsctrl_div_" + that.video_id);
	var vids = document.querySelectorAll('.player_wrapper');
	if (wants_fullscreen) { /* wants fullscreen */
		// no need to check for fullscreen capabilities, as this has been done in fullscreen() already
	
		for (i = 0; i < vids.length; i++) {
			vids[i].style.visibility = 'hidden';
		}
		wrapper.style.visibility = 'visible';
		document.getElementById("fullscreen_img_" + that.video_id).src = that.ui.base64images.fullscreen_exit_control;
		loaderObj.parentNode.insertBefore(loaderObj, canvas_element);
		//that.logger("fullscreen sytles called");
		wrapper.style.position = 'fixed';
		wrapper.style.top = 0;
		wrapper.style.left = 0;
		wrapper.style.height = '100%';
		wrapper.style.width = '100%';
		wrapper.style.backgroundColor = '#000000';
		canvas_element.style.width = '100%';
		canvas_element.style.height = '100%';
		dynamic_source.style.display = 'none';
		
		// TODO: might not work in Android? Is this necessary?
		//that.ui.getDesignatedVideoElement(that, that.video_to_play_index).style.display = 'none';

		progress.style.width = "826px";

		time.style.width = "110px";
		time.style.marginTop = "5px";

		play_div.style.width = "60px";

		live_div.style.width = "50px";
		live_div.style.marginTop = "5px";

		video_controls.style.visibility = "block";
		video_controls.style.webkitBorderTopLeftRadius = "8px";
		video_controls.style.webkitBorderTopRightRadius = "8px";
		video_controls.style.height = '60px';
		video_controls.style.width = '850px';
		video_controls.style.position = 'absolute';
		video_controls.style.top = (screen.height - 160) + 'px';
		video_controls.style.left = (screen.width / 2 - 485) + 'px';
		
		play_div.style.marginTop = "3px";
		fullscreen_div.style.marginTop = "3px";
		volumectrl_div.style.marginTop = "3px";
		settingsctrl_div.style.marginTop = "3px";
		
	} else { /*! Return styles to normal viewing mode */

		for (i = 0; i < vids.length; i++) {
			vids[i].style.visibility = 'visible';
		}
		document.getElementById("fullscreen_img_" + that.video_id).src = that.ui.base64images.fullscreen_control;
		wrapper.style.position = 'relative';
		wrapper.style.top = "0px";
		wrapper.style.left = "10px";
		wrapper.style.backgroundColor = 'white';
		canvas_element.style.width = that.ui.w + 'px';
		canvas_element.style.height = that.ui.h + 'px';
		dynamic_source.style.display = 'block';

		video_controls.style.visibility = "visible";

		time.style.width = "95px";
		time.style.marginTop = "0px";

		play_div.style.width = "37px";
		play_div.style.marginTop = "0px";

		live_div.style.width = "38px";
		live_div.style.marginTop = "0px";

		video_controls.style.position = 'relative';
		video_controls.style.top = '0px';
		video_controls.style.left = '0px';
		video_controls.className = "video_controls";
		
		that.ui.resetPlayerControls(that);
	}
}