/** @file wvsnp_ui_default.js
 * @brief UI module for WVSNP Player
 */

/* reference to UI module source files
 */
 
// setup and init files for UI
document.write('<script type="text/javascript" language="javascript" src="js/UI/nocanvas/wvsnp_ui_nocanvas_setup.js"></script>');
// loading animation (rolling ball of death)
document.write('<script type="text/javascript" language="javascript" src="js/UI/nocanvas/wvsnp_ui_nocanvas_loading_animation.js"></script>');
// "filesystem"-specific files for UI module
document.write('<script type="text/javascript" language="javascript" src="js/UI/nocanvas/wvsnp_ui_nocanvas_filesystem.js"></script>');
// "canvas"-specific files for UI module (in this case only video-handling)
document.write('<script type="text/javascript" language="javascript" src="js/UI/nocanvas/wvsnp_ui_nocanvas_videohandling.js"></script>');

/** @brief creates an encapsulated UI for the WVSNP player
 * 
 * @param that - instance of the main player
 * 
 * .............................................................................
 */
function Player_UI(that, has_canvas) {
	this.that = that; // reference to main player. (TODO: needed? not used right now - especially since every method is called with "that" anyways)
	
	// inline base64 definition of images for controlling the player
	this.base64images = {
		fullscreen_control: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAKGSURBVHjanJU7aFVBEIa/3dl7hBjQykYrSSFJClsNiPFRREGbSCCNpYWkMZUmhWjUIGIjFpY2gmCjECKIGHzFwsIiiUXSpo8QBc/dOWPh3LBeg4oDyywz/+zZmflnT5idnaXVapFSAqCua4B+ETmdUjprZoNA4KdYCGEp5/xUVeeAlaqqAMg50263SXSJiFwWkWmgx8y63ZjZkIgMichVVZ0BbpX+WOx7gFcictP3f5Mex74q8Z0bBmAeGAAeABkw1w1w3nEP/RLJYxIw6rFHAUtN0wBMhRCOmNldYBIghECR8gnX2/m+hhAuAVNN08zEGGNfSmnaAVUnANgF3AbeAIO+XnrNdjsGoDIzUkrTMca+WFXVGLCj43Vgb875i6q+VdXDnmZU1WFVXcw5bwC9xaEAO6qqGosiMlIY1cwwsymvzTPgOPDd1zG3jZrZlGelBUNGkqfSkQ3XQ16vdRFZAFY8YEFVDwGPgA9dMQCDCZDCcBE4BxwQkQi898P2u39ZRPqLjy4De0oaxy5ubU0E/ymxrAFwz7n4UVVrVT2sqgPAZ+Czqg64rQ28c+z9sgcRWCoMu12/BsaBRSdsv6+jbhv3A8sYgKWkqvMiMtSZHKfCNWATGPGudibqBXAGeBJCeO6zvdUDVZ2PdV0/dkp0hh8z2wT2isiEiKwCNVCLyKqITAB7zWyz6/H4Xtf149Q0zVrOeabVal03s7oArAOnfP/J9cFt+lCHEGi32zNN06ylGCPADTM76Y/ATiCLSOM3A9jn+o7zsSoeiVEzew3ciDFu1ca8XnPAhT+wYnIb2wJwukO1koffgGFVveL7v8k3xw6X+N9ebFW9papP//UXICK/xP8YAHmjH0DWEBvUAAAAAElFTkSuQmCC',
		fullscreen_exit_control: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAKESURBVHjarJW/S5dRFMY/957rKwhJS5ANBWVLOIRTYKgJBhZW5uASONig4j9QGgRJ+g8oTYEt4pJIlFv+aGooHKzJJakWaXEQfL/veW+D562bBRZ04HLPPc/znPvec3+8bnp6mrq6OkIIAOR5DnBBRK6HEG7GGFsAx4FF59xmURRLqvoS+JhlGQBFUVCr1QgcMhG5JyITQEOM8TBMjLFNRNpE5KGqTgJTKe4TvwFYFZHH5h9lDcZdTflVQgcsA83AE2DX4l+BGeCbtRngi2G7xm02rQPwZVkCjDvn2oF5VR1R1V4TvQLGgE/WxoDXAKraq6ojwLxpx8uyxHvvm0MIE1avQaAdWFfV28B7S1xvDeCtYevGHYwxEkKY8N43hyzLBhLyCRFZU9U+YNE552wjHIANZ4EI3BKRxaSm9VmWDXgR6UmC28CKiFwFGg9yxXSHsWSNxlkxTXVCejzQkiR8BnQBo8BukqxmrUq6a5wu01TWEgBJAqNAn83mkvg56z8YVn0pQFN6jD3/2QKgyXgWeFBtQLLkDesv/gF7BEyYrwHYBNosMGRLeAc8dc7tm7CuUttO1wN3gUtWx8o2vaouJ4EmS/o5xrh/oP9ZSvOdYdvAHeBUhavqss/zfAHYt9iOqnao6gtV7YsxDidHJcYYiTEOq2qfcTqAHdPu53m+4Muy3CqKYtJmnxORdaBdRJ4DrRU5mbTVsHbjzjnnKIpisizLLenu7kZE3njvr9hVOu+9n7I6nQTOApeB48Bp4AZwzHvfD5wB+oGNsiyHYoy45IFtsMeg4x9PyhpwrSiKvVqt9st7uAd0qup984+yPeN2pvzfXmxVnVLVpb/9Bdit+WHfBwAhUiV6c3qKBgAAAABJRU5ErkJggg==',
		pause_control: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAJvSURBVHjarJWxixRJFIe/qldVajczuywzeJneLoYHBqKBoBysiBgouMkZ+IeIofiHGBiIC2sgJgOiYCZoZCKzGJ64rDvOds9NV7+pC67VdhxxD/aLqt579eP1r3lVZmtrCxFhNBqxvb3N8vIyMUZijOe99xecc38Cv/Eff9d1/SzG+MJ7/9J7z97eHqurqywtLaGqOFqoKtba08aYO1mW3UgpMccfzrlL3nvqut601t5V1TftAuucw3tPCAHv/TXguYgsEvtKSgkRuQE8995fa87inMPt7OwgIqjqeqfTeaSqjgOiqt1Op/OoLMsr0+l0oKq44XBInucnQwgPRGRebAwcBXyzj8A/QKdV43Z3dx9UVXW2KIr3Ns9zQgi3nXP9ObEnk8nkRFVV54B9YL+qqnOTyeQE8KRd6JzrhxBu53mOzbLslIjcWuDZQ+AT8NoYMzTGDIHXTezhAk9vZVl2yqWU1oEjCyzqhBAQEVJKHiCEgKoy98lfOJJSWrfAmZ+ZLiIHirU4Y1X1OIeEqh63HDJWRD4clpiIfLDAqwPUmgNqvrLGmAEwXZDcb60LoPpJ7gtTY8zAlmX5TlXvG/NDE5eBLnASWAV+b9bdJvetfWNQ1ftlWb5zRVEA3AOui0h7Wv4CrjZjd6yJvW3Gr9sWrOv6Y1VV94qiwK2trSEi71X15mg0egrfXWndua6PtcS/6q2srNxsNLC9Xo9+v0+WZYPxeLwhIp//x1/9PB6PN7IsG/T7fXq9Hraua2KMVFVFjPExcFFVNxd4Ou/ZJnAxxvi4OUtd19/f2CLCbDZ7k1LaKMvyl0/AbDb7YRT/HQDUBA3l0vqZLwAAAABJRU5ErkJggg==',
		play_control: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAJMSURBVHjarFWxSlxBFD0zd2bEeWwU2Ycpg2IZSCFpApGABlJZuIQg0eQL8gGSMvgB+YJEg4SgoFUgWQgG0lnYi4tlRBHX5b2wM3N3UmSVVXxvt8iBgVuce7jnzB1GbG9vg4jQbDbRaDQwOjoK7z2894+01o+VUk8A3MU//A4h/PDe/9Ra/9Ja4/z8HBMTExgZGQEzQ6EHzAwp5QMhxFtr7UKMETdwXyk1p7VGCGFLSvmOmfd7CVIpBa01jDHQWs8D2CWi28SuEGMEES0A2NVaz3d7oZSCOj09BRGBmWcrlcomMysMCGa+U6lUNvM8f9Zut+vMDHV4eIgkSe4ZYzaI6DaxPwCGS3TV2dnZhnPuYZZlRzJJEhhjVpRSaUHDe2Z+CqAwA6VUaoxZSZIE0lo7RUTLJZkZAN+Z+UWfTJettVMyxjgLYKjE0hARAcAXZn5dxosxzkoA032y7x39IzMvdXO9DdOSmccHuVEiujyfAKwX3Pq4xH+GIqLjAXfusnxJREsFLo4lgL0+WqKnfkVE6yV7uSeFEHUA7RLBdne650T0oYwnhKjLPM8PmHlNCFFEdADmiOhzoQUhwMxreZ4fyCzL4JxbDSGcFPDfENG3G9avIYRw4pxbzbIManJyEkR0xMyLzWbzK4Cb73m4T8ZhbGxssasBWa1WkaYprLX1VqtVI6KLQVeEiC5arVbNWltP0xTVahUyhADvPZxz8N7vAJhh5q2STC8z2wIw473f6fYihHDdHhGh0+nsxxhreZ73/QI6nQ667/wKfwcAqYUPKsIZ4aEAAAAASUVORK5CYII=',
		settings_control: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAM+SURBVHjafJTPa1xVFMc/95077yUDk24ymUU2BcVm4UaRWAx1VSguu6kilkCCpRXcCPpnuBE0xJBupIsWSkAhi7hpFl2kIm4KKghusgiThEjCzOTee95xMXfCs9Se5b3nnfv99Y7b2tpCROj3+5yenlKWJYPBAOccIgKwAnzNuL4ANlUVM6PdbhNCoNPp0O12UVUKXlFlWVJV1YKqXlLVS1VVLZRl+apPKIqiwDkH0FLV9RDChnOuAIgx3kgp3RQRRISU0s0Y4w0A51wRQthQ1XXAO+coigIfQsB7T4zxOzNbVVWABRHBzBZVtTV5XVVfB34UkT1VRVWXzIwYo0spfZpSwh8dHZHRNHVbatJIKQHgvQdoAUu5D1UlxlgcHByMe2KMTE1NEWO8B7wJvNuYFVX1Qbfb3QU4PDx8X0Q+zkMntQfcFRFGo9GYsqqSUore+/NG4x/OuRXg6czMDHngpnNu3cw2gSsAInJ+fn4eswQUWWyA68DVPGwA3AaeTihPaOez27mHzOh6SgkRwavqqvf+DeAWUGZdHpnZM+cc2SQAzAwzQ1WfAY9EZBkovfffAw9V9U8vIhsvGjA3N/ek0+lcoCrLkhACvV4PgFarxXA43D0+Pl7O5lwGvhIR/MvCmVGQ88ZwOGR/f5+sGaqKiLiJ083ywIqqLgC3ROSy955+v3+t3+/fr+t6HFbvLwZNHlLV9xrR+Rt4KCK/e+B+vvgZ+Clr8iHwrar+IiI45zCzC4TAO8BHGVQQkTvADkBRVRXz8/P0er0d59xeRtAGfmi43qyr+a6tqjjn9nq93s78/DxVVY3/wZOTE0ajUSulVDZ0uQLsAg+AJ/nsGvDJJNg5cuXh4WFramoqOufwDQPWgMUmFBFpActmttyg+2ItAmuqumpm+NnZWbz3HBwcWAhh0vQbEIC3s3H/SRbwa0b5Vo5R3ev1SCnhy7KkKAqqqrp3dnZWq6qIyF0gAh84574xs9dyhP4ys8+B7bzu1sxMq6r6zHs/TkRd15N9GOu6vjPZKiklpqent51zjweDwZcA7Xb7sZltD4dDvPdRVVeb2a3r+uXBnugVQsA591xE/gEIITw3s//TEoB/BwCesqpY92fSXQAAAABJRU5ErkJggg==',
		volume_control: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAHgSURBVHjapNVNaIhxHAfwz16MbWReDpqXvE5KHIglS+FA5CUnwoXJzWE3ceOk1Dg4uSjEQabVSMpLadIuStkIB1kOM28bQ+byXT1pbM2/nn7//+//PN/n+/y+39//KWlubjaGUYIHWIwNeDK0UWpsYxBdmI5WLBgt4Fxsx8RCrgYVaMRVzMbp0QIew1H8yHom7uMhyrAPHdiGvSMBrsYBvMJAcp9zrQi772jK3hHU/A1wES4VQKAan8KmK6XYj3u4jJVYOxzgFJzH/Kz7UYl2XEAPDmXveOL1xHXlaENt6P/C1KJqUXQQE1KzxziLG2Fbj9voxqZSrMGyUF6FhfHZ0KjCt6gKOxOvJdajF2+xtBR9Iyg9VJa7uBNBavE0+RmJ3WMxdk+eGUxtFb5mYAiwehRdAUuwCy/wPoZW8GgVlMekw4lSUlC5Ahdj5taw2Zr9Z4mz8LMcm4exTQsaCrmyvKAFJ9PDu/Ex4tRhDtqHq2FvOuTlHyo3YEfAr2Ba/Nofk09G299EeY49mU9KHb9kfhPrY/SmsD2Ye2/9S+VHYTAP4wtsK9EZU8tJU4cz6CgfQeETWI5xEeIdNuJr1qfSPZ2ZGwnwda7i+JB4DodTw0a8+Z8TuyTt2oct+R2A3wMARBVuVJOraBwAAAAASUVORK5CYII=',
	};
	
	
	this.w = that.video.clientWidth;
	this.h = that.video.clientHeight;
	//  this.CANVAS_HEIGHT = that.video.offsetHeight;
	//  this.CANVAS_WIDTH = that.video.offsetWidth;
	
	// CANVAS
	// NOTE: the canvas-issue seems to be solved for Android
	// however, the filesystem issue still exists in order browsers, so we do not
	// care about "old" versions of Android anyways. Use Canvas in every case
	//this.has_canvas = (detectedOS != "Android");
	this.has_canvas = true;
	that.logger(this.has_canvas ? 'Using canvas version' : 'Using no-canvas version');
	
	this.current_video_element; //!< Points to the current video element that is playing
	
	this.drawScreen_running = false;
	this.html_setup = false; //!< Variable used to determine if the html of the video object has been implemented
	this.is_fullscreen = false; //!< Determines if the view mode is in full screen or not
	this.control_hover = false;
	this.control_mouseover_count = 0;
	this.control_mouseout_count = 0;
	this.progress_bar_duration;
	
	this.cl; //! Creates an object for the loading animation
	
	// on first click on "play" button, trigger this function. Remove the listener afterwards
	this.init_player_trigger = function (e) {
		// remove listener
		document.getElementById("play_toggle_" + that.video_id).removeEventListener('click', that.ui.init_player_trigger, false);
		// trigger playback on main instance of player
		that.triggerPlaybackStart(that);
	};
		
}


Player_UI.prototype.liveButtonToggle = function (that, state, color) {
	var live_toggle = document.getElementById("live_toggle_" + that.video_id);
	if (state == "on") {
		live_toggle.style.color = color;
	}
	if (state == "off") {
		live_toggle.style.color = "#000000";
	}
}

Player_UI.prototype.drawScreen = function (that) {
	that.ui.draw_screen_running = true;
	that.ui.drawScreenNoCanvas(that);
}

/** @brief Creates a full screen view of the video or reverts back to the 
 *    standard view.
 * 
 * A function that creates a full screen view of the video or reverts back to
 * the standard view.
 * 
 * .............................................................................
 */
Player_UI.prototype.fullscreen = function (that) {
	
	// TODO: not working right now with "no-canvas" version
	
	/*
	//    that.logger("fullscreen called " + that.ui.is_fullscreen);
	// Set up styles for fullscreen
	var can_fullscreen = false; //!< Determines the browser has full screen capabilities
	var loaderObj = document.getElementById("canvasLoader_" + that.video_id);
	if (!that.ui.is_fullscreen) { // Check if browser has full screen request capability
		if (document.documentElement.requestFullScreen) {
			can_fullscreen = true;
			document.documentElement.requestFullScreen();
			that.logger("fullscreen if called");
		} else if (document.documentElement.mozRequestFullScreen) {
			can_fullscreen = true;
			document.documentElement.mozRequestFullScreen();
			//that.logger("fullscreen moz called");
		} else if (document.documentElement.webkitRequestFullScreen) {
			can_fullscreen = true;
			document.documentElement.webkitRequestFullScreen();
			//that.logger("fullscreen webkit called");
		}

		// If browser has full screen capabilities set it up
		if (can_fullscreen) {
			// call "api-specific" full-screen method
			// "filesystem" uses canvas, "no_filesystem" uses no canvas
			that.ui.fullscreenSpecific(that, true);
			
			setTimeout(function () {
				that.ui.is_fullscreen = true;
			}, 1000);
		}
	} else { // Return styles to normal viewing mode
		//that.logger("exit fullscreen called");
		if (document.cancelFullScreen) {
			document.cancelFullScreen();
		} else if (document.mozCancelFullScreen) {
			document.mozCancelFullScreen();
		} else if (document.webkitCancelFullScreen) {
			document.webkitCancelFullScreen();
		}
		// call "api-specific" full-screen method
		// "filesystem" uses canvas, "no_filesystem" uses no canvas
		that.ui.fullscreenSpecific(that, false);
		that.ui.is_fullscreen = false;
	}
	that.resetVideoDimensions(that);
	*/
}

Player_UI.prototype.fullscreenSpecific = function (that, wants_fullscreen) {
	
	// TODO: not working right now with "no-canvas" version
	
	/*if(that.ui.has_canvas)
	{
		that.ui.fullscreenSpecificCanvas(that, wants_fullscreen);
	}
	else
	{
		that.ui.fullscreenSpecificNoCanvas(that, wants_fullscreen);
	}
	*/
}

/** @brief Displays the video controls
 *
 * Displays the video controls
 *
 * .............................................................................
 */
Player_UI.prototype.showPopup = function (that) {
	if (that.ui.is_fullscreen) {
		document.getElementById("video_controls_" + that.video_id).className = "video_controls";
		that.control_hover = true;
	}
}

/** @brief Hides the video controls
 *
 * Hides the video controls
 *
 * .............................................................................
 */
Player_UI.prototype.hidePopup = function (that) {

	if (that.ui.is_fullscreen) {
		setTimeout(function () {
			if (that.ui.is_fullscreen && that.control_hover == true) {
				document.getElementById("video_controls_" + that.video_id).className = "video_controls video_controls_transparent";
				that.control_hover = false;
			}
		}, 2000);
	}
}