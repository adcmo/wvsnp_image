/** @brief gets duration of first and last segment to determine length of stream
 *
 * uses the length of the first segment and assumes that every segment has the exact same length.
 * the last segment might be shorter, however, so it uses this so determine an estimated total length
 *
 * .............................................................................
 */
Player.prototype.getStreamDuration = function (that) {

	// TODO: this will only work if BLOB is supported.
	// workaround for non-filesystem version??
	var firstSegmentLoaded = false;
	var lastSegmentLoaded = false;
	
	var tempWvsnpVideo1Listener = function() {
		if(that.typ_duration == -1) {
			that.typ_duration = document.getElementById("wvsnp_video1_" + that.video_id).duration;
		}
		firstSegmentLoaded = true;
		if(lastSegmentLoaded) {
			durationCaptured();
		}
	};
	var tempWvsnpVideo2Listener = function() {
		if(that.last_segment_duration == -1) {
			that.last_segment_duration = document.getElementById("wvsnp_video2_" + that.video_id).duration;
		}
		lastSegmentLoaded = true;
		if(firstSegmentLoaded) {
			durationCaptured();
		}
	};
	
	var durationCaptured = function() {
	
		document.getElementById("wvsnp_video1_" + that.video_id).removeEventListener('canplaythrough', tempWvsnpVideo1Listener, false);
		document.getElementById("wvsnp_video2_" + that.video_id).removeEventListener('canplaythrough', tempWvsnpVideo2Listener, false);
		
		var controls_duration = document.getElementById("duration_" + that.video_id);
		// total segments, except the last segment
		var total_segments = that.last_index - that.first_index;
		// total duration of videos calculated based on the typical duration of each segment
		// in order for this to work, every segment MUST have the exact same duration than the first segment.
		// the last segment can vary (and does, usually). It is captured separately in order to have a
		// more exact result
		that.progress_bar_duration = (total_segments * that.typ_duration) + that.last_segment_duration;
		// set total duration of video-stream
		controls_duration.firstChild.nodeValue = format_time(that.progress_bar_duration);
		
		that.logger('Total duration: ' + that.progress_bar_duration);
		
		// trigger init process
		
		if(!isNaN(that.progress_bar_duration)) {
			that.init(that, that.video_to_play_index);
			
			// calculate/"estimate" the end-times of each segment
			for(var i = that.first_index; i < that.last_index; i++) {
				that.segment_end_time[i] = (that.typ_duration * (i - that.first_index + 1));
			}
			// special treatment for last segment here
			that.segment_end_time[that.last_index] = that.segment_end_time[i] + that.last_segment_duration;	
		}
		else
			that.logger('NO TOTAL DURATION???');
			//window.setTimeout(function() {
			//	that.getStreamDuration(that);
			//}, 200);
		
	};

	var xhr1 = that.createVideoRequest(that, that.getRemoteFileName(that, that.first_index), function () {
	
		var blob1 = new Blob([xhr1.response], {type: 'video/' + that.v_container});
		// we want to get the duration of this video, so put the video-segment in the hidden video-element
		document.getElementById("wvsnp_video1_" + that.video_id).src = window.URL.createObjectURL(blob1);
		document.getElementById("wvsnp_video1_" + that.video_id).addEventListener('canplaythrough', tempWvsnpVideo1Listener, false);
	});
	
	// now load the last segment, too
	var xhr2 = that.createVideoRequest(that, that.getRemoteFileName(that, that.last_index), function () {
			
		var blob2 = new Blob([xhr2.response], {type: 'video/' + that.v_container});
		// we want to get the duration of this video, so put the video-segment in the hidden video-element
		document.getElementById("wvsnp_video2_" + that.video_id).src = window.URL.createObjectURL(blob2);
		document.getElementById("wvsnp_video2_" + that.video_id).addEventListener('canplaythrough', tempWvsnpVideo2Listener, false);
	});
}

/** @brief Gets the duration of the segment and updates the controls.
 *
 * A function to that gets the duration of the latest segment written to the local
 * directory. It is placed in a video element called check_buffered_duration_element
 * so that the duration can be determined. Then the duration is updated in the controls.
 * It is also saved to an array segment_end_time. This is used by the rewind_fast_forward
 * function.
 *
 * @param a_writer_video_index - index for the video-segment which is about to be examined
 * @param duration - (optional) if segment had been examined already, do not read duration
 *                     from temp-video-element
 * .............................................................................
 */
Player.prototype.getDuration = function (that, a_writer_video_index, durationExists) {

	if(typeof that.buffering.buffered_segments[that.segment_quality[a_writer_video_index]][a_writer_video_index] !== 'undefined') {
		//that.logger("CALLED THE SAME WRITER-INDEX AGAIN! " + a_writer_video_index);
	}
	//else {
	
		//!< A local variable for the global duration element in the video controls
		var controls_duration = document.getElementById("duration_" + that.video_id);
		//!< A local variable for the load progress element in the video controls
		var load_progress = document.getElementById("load_progress_" + that.video_id);

		if(!durationExists) {
			var videoBufferedDuration = document.getElementById((that.non_fs_version ? 'wvsnp_temp_video_' + a_writer_video_index + '_' + that.video_id : "check_buffered_duration_" + that.video_id)).duration;
			
			// NOTE: this will only be executed in non-LIVE video. Otherwise it is defined in getStreamDuration already
			// (see above)
			if (that.typ_duration == -1) {
				that.typ_duration = videoBufferedDuration;
				var total_segments = that.last_index - that.first_index + 1;
				that.progress_bar_duration = total_segments * that.typ_duration;
			}
			// update the global variable buffered_file_duration
			that.buffering.buffered_file_duration = ( (a_writer_video_index > that.first_index) ? that.segment_end_time[a_writer_video_index-1] : 0) + videoBufferedDuration;
			
			//that.logger("a_writer_video_index " + a_writer_video_index + " segment duration = " + videoBufferedDuration);
			// Adds the video duration to the segment_end_time array used in ff_rw functions
			// NOTE: this was calculated in getStreamDuration() already, so this is a more accurate calculation
			// as it considers the ACTUAL duration of each segment so far.
			// It SHOULD result in the same, as each segment should have the exactly same duration.#
			// If not, RW and especially FF beyond buffer-point will not work 100% accurately.
			that.segment_end_time[a_writer_video_index] = that.buffering.buffered_file_duration;
		}
		else {
			that.buffering.buffered_file_duration = that.segment_end_time[a_writer_video_index]
		}
		
		
		//Function call to update the duration bar in the controls.
		that.calculateBufferStatusBar(that);
		/*! Formats the duration into mm:ss and sets the duration on the video controls*/
		// if it is LIVE-video caluclate total duration
		if(that.play_back_option == "LIVE") {
			controls_duration.firstChild.nodeValue = format_time(that.buffering.buffered_file_duration);
		}
		
		/*! Set the max_duration variable */
		that.max_duration = that.buffering.buffered_file_duration;
		that.writer_video_index = ++a_writer_video_index;
		that.buffering.called_from_write_buffering_in_progress = true;
		that.buffering.checkBuffer(that, a_writer_video_index);
	//}
}


/** @brief Updates the duration in the controls.
 *
 * A function that updates the duration dispaly bar in the controls. The duration
 * is determined by the max duration from the video in the buffer.
 *
 * @param start_pos_i - gives the index of the start position. Function is
 * "overloaded" so may be undefined.
 *
 * start_pos_i is called when switching from VOD to live and the starting position
 * of the buffer bar does not start at 0.
 * .............................................................................
 */
Player.prototype.calculateBufferStatusBar = function (that, start_pos_i, reset) {
	var load_progress = document.getElementById("load_progress_" + that.video_id);
	//that.logger("start_pos_i = " + start_pos_i);
	//Set local variable to the total segments in an episode
	var total_segments = that.last_index - that.first_index + 1;
	//local variable determins the percentage each segment fills in the buffer duration
	var percent_per_segment = 100 / total_segments;
	//that.logger("percent_per_segment = " + percent_per_segment);
	/*! if start_pos was not defined in the function call, 
	 * then set it to the current start position.*/
	if (typeof reset == 'undefined') {
		reset = false;
	}
	//that.logger("reset is = " + reset);
	/*!Determine the start position as a percentage. Set global variable buffer_start_pos
	 */
	if (typeof start_pos_i == 'undefined') {
		that.buffering.buffer_start_pos = that.removePercent(load_progress.style.left);
		that.buffering.buffer_start_pos = that.buffering.buffer_start_pos;
		start_pos_i = that.buffering.buffer_start_pos / percent_per_segment;
		//that.logger("that.buffering.buffer_start_pos = " + that.buffering.buffer_start_pos + " start_pos_i " + start_pos_i);
	} else {
		that.buffering.buffer_start_pos = percent_per_segment * start_pos_i;
		//that.logger("buffer_start_pos = " + that.buffering.buffer_start_pos);
	}
	var temp_time_percent = that.removePercent(load_progress.style.width);
	/* local varible for the current time percent */
	var curr_time_percent = 1 * temp_time_percent + 1 * that.buffering.buffer_start_pos;
	//that.logger("curr_time_percent = " + curr_time_percent);

	/*Sets the global variable for the start position of the buffer bar.*/


	/*! Determines status of the duration and the percent of the buffer bar to be filled. 
	 * Modulus operator is used to get the proper percentage once duration exceeds the first episode. */
	var timePercent = that.modulo_time(that, that.buffering.buffered_file_duration);
	/*! if the timePercent is 0 change to 100. */
	if (timePercent == 0) {
		timePercent = 100;
	}
	//that.logger("timepercent = " + timePercent);

	if (curr_time_percent != 100) {
		that.updateBufferStatusBar(that, timePercent)
	} else if (curr_time_percent == 100 && reset == true) {
		that.updateBufferStatusBar(that, timePercent)
	}

}

Player.prototype.updateBufferStatusBar = function (that, timePercent) {
	var load_progress = document.getElementById("load_progress_" + that.video_id);
	/* local variable adjusted time percent based off start position */
	var adj_timePercent = timePercent - that.buffering.buffer_start_pos;
	/*! Sets the CSS style to the percent of the buffer bar to be filled */
	load_progress.style.width = adj_timePercent + "%";
	/*! Sets the CSS style for the start position of the buffer bar */
	load_progress.style.left = that.buffering.buffer_start_pos + "%";
}


/** @brief Gives the time at the position where the mouse hovers over the 
 * progress bar
 *
 * A function that gets the position of the mousemove over the progress by
 * calling findPos function. Then it updates the html element.
 *
 * @param event
 *
 * The event that is called is the parameter
 *
 * .............................................................................
 */
Player.prototype.noticeTimecode = function (that, e) {
	//that.logger("time code called");
	var timebar = document.getElementById('progress_' + that.video_id);
	var notice = document.getElementById("timebar_status_" + that.video_id);
	var pos = findPos(timebar);
	//that.logger("pos y is" + pos.y + " pos x is " + pos.x + "pagex is " + e.pageX);

	var diffx = e.pageX - pos.x;
	var rw_ff_time = Math.round(diffx / that.ui.progress_w * that.progress_bar_duration);
	//that.logger("rw_ff_time " + rw_ff_time);

	if (rw_ff_time < 0) rw_ff_time = 0;
	notice.innerHTML = format_time(rw_ff_time);

	notice.style.marginLeft = (diffx + 3 - notice.offsetWidth / 2) + 'px';
};


/** @brief Gets the current time of the segment and updates the controls
 *
 * A function that gets the current time of the segment and loads it into
 * the current_time_element in the browser and updates
 * the play progress bar in the video controls.
 *
 * .............................................................................
 */
Player.prototype.getCurrentTime = function (that) {
	that.start_count_running = true;
	var current_time = 0;
	var current_mod_time = 0;
	var play_progress = document.getElementById("play_progress_" + that.video_id); //!< A local variable for the play progress element in the video controls
	var current_time_element = document.getElementById("current_time_" + that.video_id); //!< A local variable for the current time element in the video controls
	var t = window.setInterval(function () {
		//that.logger("video element to play = " + that.getVideoToPlayIndex(that));
		var current_mod_index = that.getVideoToPlayIndex(that);
		var real_play_index = that.calcRealToPlayIndex(that, current_mod_index);

		var current_video_element = that.ui.getDesignatedVideoElement(that, current_mod_index);

		if (current_video_element == null || current_video_element.paused || current_video_element.ended) {
			//that.logger("current time current video is paused"); 
		} else {
			//that.logger("real_play_index "+ real_play_index+" segment end time = " + that.segment_end_time[real_play_index] + " current video element duration = " + current_video_element.duration + " curent_video_element current time " + current_video_element.currentTime);
			current_time = that.segment_end_time[real_play_index] - current_video_element.duration + current_video_element.currentTime;
			current_mod_time = that.segment_end_time[current_mod_index] - current_video_element.duration + current_video_element.currentTime;
			var timePercent = (current_mod_time / that.progress_bar_duration) * 100;
			timePercent = timePercent - that.buffering.buffer_start_pos;
			play_progress.style.width = timePercent + "%";
			play_progress.style.left = that.buffering.buffer_start_pos + "%";
			current_time_element.firstChild.nodeValue =
				format_time(current_time);
		}
	}, 500);
} //END of get_current_time

Player.prototype.set_current_t_bar = function (that, mod_cur_time) {
	return function (that, mod_cur_time) {

	}
}


/** @brief Checks if the element is a child node of the control panel.
 *
 * If the element is a child node of the video controls, do not call hidePopup.
 *
 * .............................................................................
 */
Player.prototype.mouseEnter = function (that, _fn) {
	return function (_evt) {
		var relTarget = _evt.relatedTarget;
		if (this === relTarget || that.isAChildOf(this, relTarget)) {
			return;
		}
		_fn.call(this, _evt);
	}
};

/** @brief Checks if the element is a child node video controls.
 *
 * Checks if the element is a node of the video controls.
 *
 * .............................................................................
 */
Player.prototype.isAChildOf = function (_parent, _child) {
	if (_parent === _child) {
		return false;
	}
	while (_child && _child !== _parent) {
		_child = _child.parentNode;
	}

	return _child === _parent;
}


/** @brief Finds the position of the mouse over the progress bar
 *
 * A function that gets the position of the mousemove over the progress bar
 *
 * @param event
 *
 * The event that is called is the parameter
 *
 * @return position
 *
 * Returns the position of the mouse over the progress bar.
 *
 * .............................................................................
 */
var findPos = function (el) {
	var x = y = 0;
	if (el.offsetParent) {
		do {
			x += el.offsetLeft;
			y += el.offsetTop;
		} while (el = el.offsetParent);
	}
	return {
		x: x,
		y: y
	};
};