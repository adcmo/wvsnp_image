#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node* next;  //add of next node
};

struct Node* head;  
void Insert(int x){
 	Node* temp = (struct Node *)malloc(sizeof(struct Node));
	*(temp).data = x;
	*(temp).next = NULL;
	//if(head!= NULL) temp->next = head;
	head = temp;
	}
void Print(){
	struct Node* temp = head;
	print("List is: ");
	while(temp!=NULL)
	{
		printf("%d",temp->data);
		temp = temp->next;
	}
	printf("\n");
}
int main(){
	head = NULL; //empty list
	printf("How many numbers?");
	int n,i,x;
	scanf("%d", &n);
	for(i=0;i<n;i++) {
		printf("enter the number \n");
		scanf("%d",&x);
		Insert(x);
		Print();	
	}

}
