#!/bin/bash
#
#   FILE: snapshot.sh
#   AUTHOR: Julius Eddards
#   
#   DESCRIPTION:
#	This script will utilize Gstreamer to get a snapshot using
#	using the webcam.  
#
#   PARAMETERS:
#	$1 The location where the photo is to be stored.
#	$2 The name of the file
#
#   LAST MODIFIED: 06/04/2013 [JE]


gst-launch v4l2src ! ffmpegcolorspace ! pngenc ! filesink location=$1$2.png
