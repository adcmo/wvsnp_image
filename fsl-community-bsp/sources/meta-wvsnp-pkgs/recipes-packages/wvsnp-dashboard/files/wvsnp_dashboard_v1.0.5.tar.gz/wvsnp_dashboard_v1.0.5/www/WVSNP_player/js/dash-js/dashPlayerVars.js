var video;
var dashPlayer;
var currentRep, curSegment=0;
var lastCall = 0;
var myBandwidth;
var myFplot;		
var overlayBuffer;
var myBuffer;
var bps;
var timeID = 0;
var adaptation;
var xmlHttp;
		