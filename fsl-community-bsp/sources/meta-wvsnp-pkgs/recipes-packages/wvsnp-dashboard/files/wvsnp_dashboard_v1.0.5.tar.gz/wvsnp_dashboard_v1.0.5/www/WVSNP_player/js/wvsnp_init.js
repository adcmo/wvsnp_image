/** @file wvsnp_player.js
 *  @brief A video player that plays segmented videos continuously and seamlessly
 * 
 * Copyright 2012-2014 ASU | IA Fulton School of Electrical, Computer, and Energy Engineering.
 * All Rights Reserved.
 *
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 * http://www.opensource.org/licenses/gpl-license.html
 * and
 * http://www.gnu.org/copyleft/gpl.html
 * 
 * This has been inspired by Adolph Seema using his "crude video player" as a 
 * starting point, which can be found at:
 * http://dl.dropbox.com/u/41221188/html5_ajax_test.html
 * 
 * Copious resources for XHR2 and File System API and File API were used, most 
 * helpful were HLML5Rocks:
 * http://www.html5rocks.com/en/tutorials/file/xhr2/
 *  , http://www.html5rocks.com/en/tutorials/file/dndfiles/
 * and 
 * http://www.html5rocks.com/en/tutorials/file/filesystem/
 * 
 * Research for implementing the canvas element was:
 * http://html5doctor.com/video-canvas-magic/ 
 * and
 * http://answers.oreilly.com/topic/2896-how-to-display-a-video-on-html5-canvas/ 
 * 
 * Description: This is an HTML5 video player that plays segmented videos 
 * seamlessly. It utilizes the File System API to save the segmented video in a 
 * temporary local directory. This "sandbox" acts as a buffer for the segments. 
 * To play the segments seamlessly, this video player utilizes two video elements
 * and a canvas element. The two video elements are hidden and loaded with video 
 * segments. The video elements are rendered to the canvas. When one video ends 
 * the next video element is immediately rendered to the canvas.
 * 
 */

window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem; // take care or vendor prefixes
window.URL = window.URL || window.webkitURL; // Take care of vendor prefixes. 

var maximumVideoPlayerId = -1;
var debugTriggerNonFilesystem = false; // trigger to explicitly disable file-system API
var video; //Global variable for video
var canvas; //Gloval variable for the canvas
var ctx; //For overlaying text 

//reference to the browser detection plugin
document.write('<script type="text/javascript" language="javascript" src="js/browserdetect/PluginDetect_NoPlugin.js"></script>');
//reference to the browser detection file
document.write('<script type="text/javascript" language="javascript" src="js/browserdetect/wvsnp_detection.js"></script>');
//reference to the browser capability test
document.write('<script type="text/javascript" language="javascript" src="js/browserdetect/wvsnp_compatbility_test.js"></script>');
//reference to the (core) init-part of the player
document.write('<script type="text/javascript" language="javascript" src="js/wvsnp_player.js"></script>');
//reference to the control type functions
document.write('<script type="text/javascript" language="javascript" src="js/wvsnp_controls.js"></script>');
//reference to the ff_rw type functions
document.write('<script type="text/javascript" language="javascript" src="js/wvsnp_ff_rw.js"></script>');
//reference to the helpers / utility collection
document.write('<script type="text/javascript" language="javascript" src="js/wvsnp_helpers.js"></script>');
//reference to the buffering module
document.write('<script type="text/javascript" language="javascript" src="js/Buffering/wvsnp_buffering.js"></script>');
//reference to the UI module. reference your custom implementation here, if needed
//see at js/UI/stub for a stub-implemention with the necessary methods
document.write('<script type="text/javascript" language="javascript" src="js/UI/default/wvsnp_ui_default.js"></script>');
//document.write('<script type="text/javascript" language="javascript" src="js/UI/nocanvas/wvsnp_ui_nocanvas.js"></script>');

	
var use_blob_api = false;
var use_blobbuilder = false;
// check if we can use the HTML5 Filesystem API
//if(window.requestFileSystem /* && !debugTriggerNonFilesystem*/) {
	document.write('<script type="text/javascript" language="javascript" src="js/filesystem/wvsnp_filesystem.js"></script>');
//}
// TODO: non-filesystem version not supported any more right now
// left as future work branch for legacy browsers (Firefox 3.5 in Windows XP?)
/*else {
	// test if "Blob" is supported. This way we can download the videos using XMLHttpRequest
	// first try catch
	var test_blob = null;
	try {
		test_blob = new Blob(['<a id="a"></a>'], {type : 'text/html'});
	} catch (e) {
		var BlobBuilder = window.WebKitBlobBuilder || window.MozBlobBuilder;
		if(BlobBuilder)
		{
			var bb = new BlobBuilder();
			bb.append(['<a id="a"></a>']);
			test_blob = bb.getBlob('text/html');
			use_blobbuilder = true;
		}
	}
	if(test_blob)
	{
		// can we use Blob or BlobBuilder?
		use_blob_api = true;
		document.write('<script type="text/javascript" language="javascript" src="js/filesystem/wvsnp_filesystem_less_blob.js"></script>');
	}
	else
	{
		console.log('not using blob to download videos');
	}
	// use raw video-elements/functionality to load the video. Might have some ugly side-effects
	document.write('<script type="text/javascript" language="javascript" src="js/filesystem/wvsnp_filesystem_less.js"></script>');
}*/

// check if current browser supports filesystem AND can play back video from Blob URLs as well as from filesystem
var fullyFilesystemCompatible = false;

// in ancient browsers (e.g. IE8) "addEventListener" is not defined
// so use this as the first entry point to inform the user about his poor choice of browser
if(typeof(window.addEventListener) == 'undefined')
{
	alert('Your browser does not support fundamental HTML5 features. Are you using Internet Explorer 8 or below?');
}
else
{
	/** @brief Listener that calls its anonymous function once the window is loaded
	 * 
	 * A function that is called when the window is loaded. This is
	 * necessary to get the elements on the page, after the page is loaded.
	 * Global variables are filled with elements from the document
	 * 
	 * .............................................................................
	 */
	window.addEventListener('load', function () {
		// run detection script to determine browser and OS
		browser_detection();
		
		/*
		// --------------------------------------
		// BROWSER CAPABILITY/COMPATABILITY CHECK
		// --------------------------------------
		*/
		
		if(detectedOS == "Android") {
			// if we are on Android, we need a "workaround" here
			// video can only start playing on user-interaction, so "force" the user to
			// interact here. Before anything else starts, hide all video-elements and
			// "replace" each one with a "play start" button
			// this user-interaction allows to start a video in order to proceed with
			// capapility/compatibility tests
			var playButtonBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAC7mlDQ1BJQ0MgUHJvZmlsZQAAeAGFVM9rE0EU/jZuqdAiCFprDrJ4kCJJWatoRdQ2/RFiawzbH7ZFkGQzSdZuNuvuJrWliOTi0SreRe2hB/+AHnrwZC9KhVpFKN6rKGKhFy3xzW5MtqXqwM5+8943731vdt8ADXLSNPWABOQNx1KiEWlsfEJq/IgAjqIJQTQlVdvsTiQGQYNz+Xvn2HoPgVtWw3v7d7J3rZrStpoHhP1A4Eea2Sqw7xdxClkSAog836Epx3QI3+PY8uyPOU55eMG1Dys9xFkifEA1Lc5/TbhTzSXTQINIOJT1cVI+nNeLlNcdB2luZsbIEL1PkKa7zO6rYqGcTvYOkL2d9H5Os94+wiHCCxmtP0a4jZ71jNU/4mHhpObEhj0cGDX0+GAVtxqp+DXCFF8QTSeiVHHZLg3xmK79VvJKgnCQOMpkYYBzWkhP10xu+LqHBX0m1xOv4ndWUeF5jxNn3tTd70XaAq8wDh0MGgyaDUhQEEUEYZiwUECGPBoxNLJyPyOrBhuTezJ1JGq7dGJEsUF7Ntw9t1Gk3Tz+KCJxlEO1CJL8Qf4qr8lP5Xn5y1yw2Fb3lK2bmrry4DvF5Zm5Gh7X08jjc01efJXUdpNXR5aseXq8muwaP+xXlzHmgjWPxHOw+/EtX5XMlymMFMXjVfPqS4R1WjE3359sfzs94i7PLrXWc62JizdWm5dn/WpI++6qvJPmVflPXvXx/GfNxGPiKTEmdornIYmXxS7xkthLqwviYG3HCJ2VhinSbZH6JNVgYJq89S9dP1t4vUZ/DPVRlBnM0lSJ93/CKmQ0nbkOb/qP28f8F+T3iuefKAIvbODImbptU3HvEKFlpW5zrgIXv9F98LZua6N+OPwEWDyrFq1SNZ8gvAEcdod6HugpmNOWls05Uocsn5O66cpiUsxQ20NSUtcl12VLFrOZVWLpdtiZ0x1uHKE5QvfEp0plk/qv8RGw/bBS+fmsUtl+ThrWgZf6b8C8/UXAeIuJAAAD3klEQVRoBd2b8W3iMBTGm8AAjNDbgE5wOQkQ/NduUCa46wQtE1Q3QbsB/Q8JkJpOcGxwjMAA0N73RY5lQhLs8BzCWUJJHPu975dnO04cgq+vryvJNBqNrne7XfT5+fk9CIJr2I7wK0sxNKzDMPxotVrxbDZblxV2PRdIABJqu93+hK1bBeWqQ5cnLGy8tdvt3xKwJwH2+/0Iyh7x49ZHimF0slgsuK2UKgEOBoMurvQzPEaVvLpXihHVh/l8vnKtGrpWQNSeAPcH9SLXuieUj+iTvl1tWEdQ9bMpHHRdnQiXX6F/3tn2TytA1dcI1xEWW9XcBhXvbPrm0SaK/nYPY+/4NQUOUhIt70objwtTKSANoO2/FNY+8wlqOwZZ2ERVs2TkLiH9KGquuRHEVeFAwj53KWmqNB/ozQVUzbJJfe5AeCajU9SVDgDVvYYRvLTUzbtP7vVBhhlXgjfxi02Y8dyYM569CALuWZKMztD5A9h8kLRbZivLoCPoY9RUcIkeDudF/aRMcMVzelQ1I8inAm8JzeYVER17c7BvWLMkgJxn4ny0X0b+qEbISDFdJYB8WJXHybdYF2TKlACib9zmy/GTWwdkyhQMh0O+bvjrA8UcZPLs+x548Fj1LeQLojzndeQxkrjSr758kS3k2y9fDmzsLpfLsS9IsoUYuq9thPgs4wuSbBxkIp/ibW17goySUdRWhO9yhISPN0k/jQIkGEY+0Xlr4wBt35bZRrlxgLbCbcs1DjCdQ9oCHCvXOEDMqkSfSRsF2Ov1XhAR0XkxAeNjYa7jPOFwY74X9hWHmCathY06m/MEd0U2LKyGH86KBCv4gqNEsoVcNhbU62SKj0semqXWQLaQN9ZzNFPfz4JkIlsyiuIqis7/9CUs2PENR7cpUwLIBf8CLeLZdcBRdMqUAKr5XyxOkzFYFxzc6s9REkClY5LRI3pYIxx1axYNqNbXYkkqQHVpD2/Nf6HTc5ZSR4oVS+KrbXpEx3yAELHFF9oCnOnC+z4ZTCc6gszEW64VNjq8ZsEL2Z8oBi1XL77oHOzgqjOKSfMy8xu+v0LTvMlq3ItgehJhHmN/kx5fwHajNB9IzY0gS/lYTjvwLpehl8uyJnMjyEIciYquStbIOY+p0Rw1s1oKAVmwjkWSrCCXY8JRY1mdwiZqVlLNdYq8jpl/xn2ODzKfchGCTQBzO45QKx6fOfFjPK79xzY6rCJoGkI0n3D8aObVuD8BGP1bJ2dAWuYUDLMUvv2KeFxD4oBX6YPYSoApkOqbjGaU5glvY9hj1LitlE4CTD2qj2X/v4/SU0BzS9gm/a3gH5bH1wCr30BqAAAAAElFTkSuQmCC";
			var video_tags_HTML5 = document.querySelectorAll('video.wvsnp_player');
			for(var v = 0; v < video_tags_HTML5.length; v++) {
				video_tags_HTML5[v].style.display = "none";
				
				// create a button
				var tempPlayButton = document.createElement('button');
				tempPlayButton.setAttribute('class', 'player_temp_play_button');
				tempPlayButton.addEventListener('click', function() {
					// interaction starts the browser-capability test
					startBrowserCapabilityTest();
				});
				var tempPlayButtonImage = document.createElement('img');
				tempPlayButtonImage.src = playButtonBase64;
				tempPlayButton.appendChild(tempPlayButtonImage);
				
				// append the play button after the current player
				if(video_tags_HTML5[v].nextSibling) {
					video_tags_HTML5[v].parentNode.insertBefore(tempPlayButton, video_tags_HTML5[v].nextSibling);
				}
				else {
					video_tags_HTML5[v].parentNode.appendChild(tempPlayButton);
				}
			}
		}
		// if we are on IE < 10, we do not even need to perform testing
		else if(detectedBrowser == "IEdeprecated") {
			fullyFilesystemCompatible = false;
			onBrowserError();
		}
		else {
			// if not on Android, start the test right away
			startBrowserCapabilityTest();
		}
	}, false);
}

/** @brief start compatibllity check
 * will run a check for certain features that are necessary for WVSNP-DASH 
 */
var startBrowserCapabilityTest = function() {
	var playbacktest = new PlayBackCapabilityTest(onBrowserCapable, onBrowserError);
	playbacktest.createFileRequest(playbacktest);
}

var onBrowserError = function() {
	console.log('Browser does not support features required for WVSNP-DASH');
	fullyFilesystemCompatible = false;
	initialisePlayer();
}

var onBrowserCapable = function() {

	console.log('Browser is compatible with WVSNP-DASH features');
	fullyFilesystemCompatible = true;
	initialisePlayer();
}

/** @brief initialise the WVSNP Player
 * after the compatibility check for the browser ran through, initialise the player here.
 *
 * NOTE: we do not exit here, even if the browser might not be compatible with WVSNP-DASH!
 * the browser still might be able to playback HLS or the plain video!
 */
var initialisePlayer = function() {

	// if browser supports MPEG-DASH, load dash-js scripts here
	if(supports_media('mpeg-dash'))
	{
		// use dash-js to support MPEG-DASH
		var dashJsScripts = ["dash-js/dashPlayerVars.js","dash-js/fplot.js","dash-js/mpdParser.js","dash-js/bandwidth.js","dash-js/adaptationlogic.js","dash-js/rate_measurement.js","dash-js/DASHttp.js","dash-js/basebuffer.js","dash-js/timeBuffer.js","dash-js/mediaSourceBuffer.js","dash-js/eventHandlers.js","dash-js/mediaSourceAPIAdaptation.js","dash-js/dash.js"];
		for(var i = 0; i < dashJsScripts.length; i++) {
			var dashScript = document.createElement('script');
			dashScript.setAttribute('src', "js/" + dashJsScripts[i]);
			document.getElementsByTagName("head")[0].appendChild(dashScript);
		}
	
		// dash.js will not work for some reason
		/*var dashScript = document.createElement('script');
		dashScript.setAttribute('src', "js/dash.js/dash.all.js");
		document.getElementsByTagName("head")[0].appendChild(dashScript);*/
	}
	
	// query all video-elements with class wvsnp_player
	var video_tags_HTML5 = document.querySelectorAll('video.wvsnp_player');
	/* query all src-elements for wvsnp */
	var video_src_strings = document.querySelectorAll('.wvsnp_src');
	/* array that will contain all player-objects */
	var video_objects = [];
	
	// remove all buttons in Android (see workaround above)
	var temp_play_buttons = document.querySelectorAll('.player_temp_play_button');
	for(var n = 0; n < temp_play_buttons.length; n++) {
		temp_play_buttons[n].parentNode.removeChild(temp_play_buttons[n]);
	}

	setTimeout(function () {
		//that.logger("video_tags.length = " + video_tags_HTML5.length);
		for (var v = 0; v < video_tags_HTML5.length; v++) {
			maximumVideoPlayerId = v;
			video_tags_HTML5[v].style.display = 'block';
			video_objects.push(new Player(v, video_tags_HTML5[v], video_src_strings[v].src));
		}
	}, 500);

	/** @brief adds a new WVSNP-video-player
	 * will create a new instance of the video-player and append it underneath the most recent instance.
	 * will also use the source of the current instance.
	 */
	function add_video() {		
		// get latest video player, use dimensions
		var latestVideoPlayer = document.getElementById('player_wrapper_' + (maximumVideoPlayerId))
		
		maximumVideoPlayerId++;
		var newVideoElement = document.createElement('video');
		// set dimensions of video-element
		newVideoElement.setAttribute('height', latestVideoPlayer.style.height);
		newVideoElement.setAttribute('width', latestVideoPlayer.style.width);
		// set id
		newVideoElement.setAttribute('id', 'video_' + maximumVideoPlayerId);
		// append underneath the current video-player
		// first check if player has a sibling following after it
		if(latestVideoPlayer.nextSibling) {
			latestVideoPlayer.parentNode.insertBefore(newVideoElement, latestVideoPlayer.nextSibling);
		}
		else {
			latestVideoPlayer.parentNode.appendChild(newVideoElement);
		}
		
		video_objects.push(new Player(maximumVideoPlayerId, newVideoElement, video_objects[(maximumVideoPlayerId-1)].video_src_string));
	}

	var add_video_button = document.getElementById('add_video_button');
	if(add_video_button)
	{
		document.getElementById('add_video_button').addEventListener('click', add_video, false);
	}
}
