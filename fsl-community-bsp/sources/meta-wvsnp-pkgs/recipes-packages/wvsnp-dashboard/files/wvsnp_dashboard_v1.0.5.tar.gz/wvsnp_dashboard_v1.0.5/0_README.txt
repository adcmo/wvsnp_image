-------------------------------------------------------------------------------
This is the official WVSNP Dashboard.
Before you do anything with this zip file read below.

------------------------------------------------------------------------------

------------------------------------------------------------------------------
2014/06/30 - Version 1.0.3 
------------------------------------------------------------------------------

1-- DESCRIPTION:

    Release of WVSNP Dashboard with updated CGI functions. Latest version 
    
2-- RELEASE AUTHOR:

	Orlando Moreno
	Updated: Sri Harsha Rentala
    
4-- RELEASE NOTES:

        A-- buttonfunctions.cgi statically compiled with libxbee
	B-- New source added, ffmpeg_capture.c, that adds capture functionality to dashboard
	C-- New shell script added, capture.sh, that is used to run the ffmpeg command to capture video
	D-- Live and VOD videos are now moved to www/WVSNP_player/video.segments
	E-- New source added, Node functions in which functionality to transfer data through Zigbeee nodes are added.
	F-- WVSNP player tab with dynamic video player to show images and text on the player while playing the video.

5-- INSTALLATION STEPS:

    A-- Unpack the latest zip version to your desktop NOT the old ones.
        
    B-- If you don't have have mongoose installed follow steps below.
        Otherwise skip to step "C--".
         
		Installation steps for mongoose.

		i--- Start up terminal and change directory to the mongoose folder.
			>cd /home/orlando/Desktop/wvsnp_dashboard_v1.0.1/mongoose
		ii-- Check to see if this is the latest version, if not, run the following git command to get the latest version.
			>git clone https://github.com/cesanta/mongoose.git
		iii- Go to the web_server directory and compile with the command below.
			>cd mongoose/examples/web_server
			>make
		iv-- Copy and edit the mongoose.conf file so that it points the document_root to the www folder of the unziped dashboard.
			>cp ~/wvsnp_dashboard_v1.0.3/mongoose/mongoose.conf .
			>vi mongoose.conf
			Around line 6 it should say "document_root /home/www". Replace that with the path to the www folder of the dashboard.
			Example: document_ root /home/rongyue/mygits/wvsnp_dashboard_v1.0.3/www
		iv-- Run the mongoose server with the specified configuration.
			>./web_server mongoose.conf
		v--- To see if mongoose is running correctly, open a web browser and type into the address bar "localhost:8080" without quotes. You 			 should see your document root directory with all the folders and files displayed.
    
    C-- If you have mongoose running stop it and follow steps below.
         
        Installation steps for Dashboard:
        
        i--- Go to www/CGI/capture.sh and edit the paths of ffmpeg and input device to match your system's path
			 Example: /home/root/ffmpeg/bin/ffmpeg is the path for the executable ffmpeg.
					  /dev/video0 is the path for the camera.
					  /home/root/wvsnp_dashboard_v1.0.3/WVSNP_player/video.segments/live is the directory where the output for live video 						  should be saved.
		ii-- Modify ffmpeg_capture.c around Line 88, where the syscall variable is being filled by the specified string. Add the full path of 				 the board's bash and capture.sh:
			 strcpy(syscall, "bash capture.sh ");
			 to
			 strcpy(syscall, "/bin/bash /home/root/wvsnp_dashboard_v1.0.3/www/CGI/capture.sh ");
			 Then recompile using the following command:;
			 >gcc cgi.c ffmpeg_capture.c -o /home/root/wvsnp_dashboard_v1.0.3/www/CGI/ffmpeg_capture.cgi
        iii- Ensure mongoose is restarted and running before testing below.
        
6-- TESTING STEPS:

    A-- Go to your browser and enter http://localhost:8080/wvsnpdash.shtml
        You should see the WVSNP Dashboard front page loading up.

    B-- If you know the IP of the device running mongoose enter it
        instead of "localhost" e.g. http://192.168.1.4:8080/wvsnpdash.shtml
        You should see the WVSNP Dashboard front page loading up.
        If you set a different port number, enter it instead of "8080".
        e.g. http://192.168.1.4:7125/wvsnpdash.shtml
        You should see the WVSNP Dashboard front page loading up.
        If you did not set a port number then you can just use IP.
        e.g. 
        http://192.168.1.4/wvsnpdash.shtml or http://localhost/wvsnpdash.shtml
        You should see the WVSNP Dashboard front page loading up.
        
    C-- If you have a webcam connected to your laptop or the device running
        mongoose server.
        Click on "Snaphost" tab.
        Click on "Take Snapshot" button. 
        You should see a picture just taken shown on the Dashboard page.

    D-- If the node functions page does not appear correctly, try to recompile the libxbee statically and recompile the buttonfunctions.c

        Congratulations! your Dashboard installation is a success!
        
-------------------------------END-OF-THIS-RELEASE----------------------------


