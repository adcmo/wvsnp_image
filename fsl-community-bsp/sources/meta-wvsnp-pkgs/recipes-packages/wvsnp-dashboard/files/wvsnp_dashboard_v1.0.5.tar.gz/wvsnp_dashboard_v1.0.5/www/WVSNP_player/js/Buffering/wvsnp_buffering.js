
function Player_Buffering(that) {

	this.that = that; // reference to main player. (TODO: needed? not used right now - especially since every method is called with "that" anyways)

	// buffer-flags (used during buffer process)
	this.rewindFastForward_in_progress = false; //!< Detect is rewind fast forward function is in progress
	this.segment_can_play = false; //!< Are there enough elements in the buffer to allow the video to play
	this.buffer_to_play = 3; //!<used in initalize_reader to determine videos in local dir
	this.buffer_segments_ahead = 3;
	this.buffer_start_pos = 0;
	this.called_from_write_buffering_in_progress = false; //!< Determines is buffering is in progress. 
	this.buffer_video_load_listeners = new Array(); //!< holds a listener for the check_buffered_duration_X video-element for each index. necessary to store in order to remove afterwards
	this.repeat_local_check_count = 0;
	this.repeatServerCheck_count = 0;
	this.initialiseReader_running = false;
	this.buffered_file_duration = 0; //!< duration of stream that has been played out so far
	
	this.buffered_segments = new Object(); //!< will contain the list of validated segments to speed up ff/rw process
	
	// contains subscribers / callbacks for the "buffering finished" event
	this.buffering_finished_observers = new Array();
	
	// contains subscribers / callbacks that are called once one video-segment is finished
	// probably will be called before the "buffering_finished_observers" queue
	this.buffering_progresses_observers = new Array();
}

/** @brief observer to be called once buffering has finished (= playback buffer filled "enough")
 *
 * @param observer - callback function to be called if buffering is over
 *                   should be a function without required arguments
 * ............................................................................
 */
Player_Buffering.prototype.addBufferingFinishedObserver = function(that, observer) {
	that.buffering.buffering_finished_observers.push(observer);	
}


/** @brief observer to be called once buffering has progressed
 *
 * once one segment has finished downloading and has been examined, this
 * observer will be called
 *
 * @param observer - callback function to be called if buffering is over
 *                   should be a function without required arguments
 * ............................................................................
 */
Player_Buffering.prototype.addBufferingProgressesObserver = function(that, observer) {
	that.buffering.buffering_progresses_observers.push(observer);	
}

/** @brief initialises the buffered_segments with all available quality-levels
 */
Player_Buffering.prototype.bufferedSegmentsInit = function (that) {
	that.buffering.buffered_segments = new Object();
	
	for(var i = that.pres_int_min; i <= that.pres_int_max; i++) {
		that.buffering.buffered_segments[i] = new Object();
	}
	// initialise quality-definitions for each segment
	for(var n = that.first_index; n <= that.last_index; n++) {
		that.segment_quality[n] = that.v_quality;
	}
}


/** @brief Checks if the requested file exists on the server.
 * 
 * A function that checks if the requested file exists on the server.
 * If is does then create_file_request is called and the file is saved to
 * the local directory. 
 * 
 * .............................................................................
 */
Player_Buffering.prototype.checkForFile = function (that, a_writer_video_index, skipLocalCheck) {
	
	that.currentSegmentLoaded = a_writer_video_index;
	
	var fileNotLocally = function() {
		// Make XHR request for file
		//    var temp_i=that.writer_video_index%(that.last_index-that.first_index+1);
		var http = new XMLHttpRequest();
		http.open('HEAD', that.getRemoteFileName(that, that.writer_video_index), false);
		http.send();
		if(http.status != 404)
		{
			//that.logger("file " + that.getRemoteFileName(that, a_writer_video_index) + " ready");
			that.triggerFileDownload(that,  that.writer_video_index);
			that.buffering.repeatServerCheck_count = 0;
		}
		else
		{
			//that.logger("file does not exist: " +  that.writer_video_index + ", status: " + http.status + ", ready state: " + http.readyState);
			that.buffering.repeatServerCheck(that,  that.writer_video_index);
		}
	}
	// first check if during the current session we already verified that the desired segment exists for the
	// current selected quality
	// to speed up the process, check for all upcoming segments until we reach a point of "no-buffering"
	var check_maximum_segment = a_writer_video_index;
	while(check_maximum_segment <= that.last_index && that.play_back_option != "LIVE" && (typeof that.buffering.buffered_segments[that.segment_quality[check_maximum_segment]][check_maximum_segment]) != 'undefined') {
		check_maximum_segment++;
	}
	
	// at least one segment was found
	if( (check_maximum_segment - 1) >= a_writer_video_index) {
		that.buffering.repeatServerCheck_count = 0;
		that.currentSegmentLoaded = check_maximum_segment-1;
		that.buffering.tempVideoLoaded(that, check_maximum_segment-1, true);
	}
	else if(!skipLocalCheck) {
		that.checkForLocalFile(that, a_writer_video_index, function () {
			// if file already exists locally, proceed to "tempVideoLoaded"
			that.buffering.tempVideoLoaded(that, a_writer_video_index);
			that.buffering.buffered_segments[that.segment_quality[a_writer_video_index]][a_writer_video_index] = 1;
			// reset server check
			that.buffering.repeatServerCheck_count = 0;
		}, function () {
			// if file does not exist or request timed-out, then check online for file and proceed to re-download it
			fileNotLocally();
		});
	}
	else {
		fileNotLocally();
	}
}

Player_Buffering.prototype.repeatServerCheck = function (that, a_writer_video_index) {

	if(that.buffering.currentRepeatServerTimeout != null)
		clearTimeout(that.buffering.currentRepeatServerTimeout);
	
	if (that.buffering.repeatServerCheck_count < 20) {
		if (that.typ_duration == -1) {
			dur = 5000
		} else {
			var dur = that.typ_duration * 900;
		}
		that.buffering.currentRepeatServerTimeout = setTimeout(function () {
			that.buffering.repeatServerCheck_count++;
			that.logger("repeat check called for segment " + a_writer_video_index + " - repeat check count = " + that.buffering.repeatServerCheck_count);
			// repeat checking for file - this time do not repeat the local-cache check
			that.buffering.checkForFile(that, a_writer_video_index, true);
		}, dur);
	} else {
		that.buffering.called_from_write_buffering_in_progress = false;
	}
}


/** @brief Checks how many video segments are in the buffer and calls for
 *    next the next segment if needed.
 * 
 * A function that checks how many segments are in the buffer that have 
 * not been played. If less than three segments are in the buffer 
 * create_file_request function is called to load segment into the buffer
 *
 * ............................................................................
 */
Player_Buffering.prototype.checkBuffer = function (that, a_writer_video_index) {
	var a_play_index = that.getVideoToPlayIndex(that);
	
	/*if (that.play_back_option == "LIVE") {
		if ((a_writer_video_index) <= 2) {
			that.buffering.checkForFile(that, a_writer_video_index);
			//that.logger("buffer checked " + a_writer_video_index);  
		}
	} else {*/
		//that.logger("check buffer called, writer: " + a_writer_video_index + ", play_index: " + a_play_index);
		// if this is the file-system-version OR we buffered less than "buffer_segments_ahead" segments after the current playing one, check for the next file
		if ((!that.non_fs_version || Math.abs(a_writer_video_index - a_play_index) <= that.buffering.buffer_segments_ahead) && a_writer_video_index <= that.last_index) {
			that.buffering.checkForFile(that, a_writer_video_index);
		}
				//that.logger("buffer checked " + a_writer_video_index);  
		if (a_writer_video_index >= that.last_index) {
			//that.logger("buffer full, segments left to play out: " + (a_writer_video_index - a_play_index));
			that.buffering.called_from_write_buffering_in_progress = false;
		}
	//}
}


/** @brief Function that sets timers to delete segments from LIVE video 
 * directory, calls function to increment live_episode and check for next
 * segment on server.
 * 
 * Timer based on setInterval and setTimeout function calls which 
 * deletes segments in the live folder and calls increment_live_episode
 * .............................................................................
 */
Player_Buffering.prototype.liveBufferTimer = function (that) {
	that.logger("live_buffer timer called");
	//if duration is not set, then do nothing
	if (that.typ_duration == -1) {} else {
		//set local variable to the episode duration in milliseconds.
		// TODO: define typ_duration maybe in ms from the beginning?
		var episode_dur = (that.typ_duration * 1000) * (that.last_index - that.first_index + 1);
		/*that.logger("live_buffer timer called with" + " segment duration = " + that.typ_duration + " last index = " + that.last_index + " first index = " + that.first_index + " duration =" + episode_dur);
		window.setInterval(function () {
			that.buffering.checkForFile(that, that.writer_video_index);
			var temp_i = that.last_in_buffer; // % (that.last_index - that.first_index + 1);
			var file_name = that.play_back_option + "_" + that.video_id + "/" + that.getFileNameForQuality(that, that.segment_quality[temp_i]) + temp_i + "." + that.v_container;
			//that.logger("delete file request called of index " + temp_i);
			// TODO: debug? deletion not working yet?          
			//that.deleteFileRequest(that, file_name);
			that.last_in_buffer++;
		}, (that.typ_duration * 1000));*/
		window.setInterval(function () {
			that.incrementLiveEpisode(that);
		}, episode_dur);
	}
}

Player_Buffering.prototype.tempVideoLoaded = function (that, a_writer_video_index, durationExists) {
	
	// make sure this segment is still up to date. In case of fast forwarding beyond the buffer-point,
	// the desired segment might have changed. Only process segment, if 
	if(that.currentSegmentLoaded == a_writer_video_index) {
		that.getDuration(that, a_writer_video_index, durationExists);
		that.buffering.canPlay(that, a_writer_video_index);
		if(!durationExists) {
			window.URL.revokeObjectURL(document.getElementById("check_buffered_duration_" + that.video_id).src); // Clean up after yourself.
			document.getElementById("check_buffered_duration_" + that.video_id).src = null;
		}
		// inform subscribers that buffering proceeded
		that.buffering.informSubscribers(that, false);
	}
	else {
		that.logger('DESIRED SEGMENT CHANGED??');
	}
}


/** @brief Detects if the minimum required segments exist in the buffer. 
 * 
 * A function that detects if at least three segments are in buffer. If there
 * are, then segment_can_play and the end_loading_animation is called. 
 *  
 *..............................................................................
 */
Player_Buffering.prototype.canPlay = function (that, a_writer_video_index) {
	var play_index = that.getVideoToPlayIndex(that);

	//  that.logger("can play index " + writer_video_index);
	/*! If the buffer has 3 or more segments that have not been played then end the 
	 * loading animation 
	 */
	if (a_writer_video_index - play_index >= that.buffering.buffer_segments_ahead && that.buffering.segment_can_play == false) {
		//that.logger("can play");
		if (!that.buffering.rewindFastForward_in_progress) {
			// do not end the loading animation here, but rather directly before playing out the video
			//that.ui.endLoadingAnimation(that);
		}
	} else {
		//that.logger("can play else ");
	}
}


/** @brief Checks local directory to determine if files are available to read. 
 * 
 * Creates an interval set for 1 second. Within the interval, it checks the 
 * current_writter_index is greater than the start_reader_i. This ensures that there 
 * is a video segment in the local directory to read. If that is true then 
 * read_file_request can be made. If the additional segments are needed in the
 * buffer before play can begin (buffer > 1) then the function is recursivally called.
 * If no files are detected in the local directory after 50 attempts then the function
 * times out.
 *  
 *..............................................................................
 */
Player_Buffering.prototype.initialiseReader = function (that, start_reader_i, play_i, buffer_to_play, timeout) {
	var thisCall = this;
	thisCall.q_count = 0;
	that.buffering.initialiseReader_running = true;
	// TODO: remove old listener(s) first?
	/*document.getElementById("play_toggle_" + that.video_id).addEventListener('click', function (e) {
		clearInterval(thisCall.q);
		that.buffering.initialiseReader_running = false;
	}, false);*/
	thisCall.q = window.setInterval(function () {
		var current_writter_i = that.writer_video_index;
		if(that.q_count >= 10 && (that.q_count % 2) == 0)
			that.logger("interval triggered, start_reader_i = " + start_reader_i + " play_i " + play_i + " buffer_to_play = " + buffer_to_play + " q_count + " + that.q_count);
		thisCall.q_count++;
		if (current_writter_i > start_reader_i) {
			//that.logger("if called in interval 1");
			clearInterval(thisCall.q);
			if (buffer_to_play > 1) {
				that.logger("calling readfile request from initalize_reader");
				that.readFileRequest(that, start_reader_i);
				that.buffering.initialiseReader(that, ++start_reader_i, play_i, --buffer_to_play, timeout);
			} else if (buffer_to_play == 1) {
				that.video_to_play_index = play_i;
				that.playPauseButton(that, play_i);
				// inform subscribers, that buffering is over
				that.buffering.informSubscribers(that, true);
				that.buffering.initialiseReader_running = false;
				if (that.play_back_option == "LIVE" && !that.liveBufferTimer_initalized) {
					that.liveBufferTimer_initalized = true;
					that.getLiveCountBaseline(that);
					that.buffering.liveBufferTimer(that);
				}
			}
		} else if (thisCall.q_count >= 50) {
			clearInterval(thisCall.q);
			that.ui.endLoadingAnimation(that);
			alert("Segment " + start_reader_i + " was not found on the server, the player has stopped checking for the file");
		}

	}, (timeout ? timeout : 1000));
}

/** @brief on buffering finished, inform subscribers
 *
 * if initialiseRader is about to call "playPauseButton()", inform
 * all subscribers for that event (callbacks in array buffering_finished_observers).
 * remove informed subscribers from the array afterwards.
 *
 * @param finishedEvent - is this the "finished" event or "buffering progresses"?
 */
Player_Buffering.prototype.informSubscribers = function (that, finishedEvent) {

	if(finishedEvent) {
		for (i = 0; i < that.buffering.buffering_finished_observers.length; i++) {
			that.buffering.buffering_finished_observers[i]();
		}
		that.buffering.buffering_finished_observers = new Array();
	}
	else {
		for (i = 0; i < that.buffering.buffering_progresses_observers.length; i++) {
			that.buffering.buffering_progresses_observers[i]();
		}
		that.buffering.buffering_progresses_observers = new Array();
	}

}

