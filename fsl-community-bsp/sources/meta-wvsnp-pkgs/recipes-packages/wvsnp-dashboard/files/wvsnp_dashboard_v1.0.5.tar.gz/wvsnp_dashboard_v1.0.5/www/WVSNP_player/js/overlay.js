/* Global Variables needed */
var video; 
var canvas;
var ctx;
var ctx2; 
var string1;

/* This function helps us set up the canvas to draw on when the page is first loaded */
function Init(){

		video = document.getElementById("videoElement"); 
		canvas = document.getElementById("can"); 
		ctx = canvas.getContext('2d');
		ctx.fillStyle = "black";
		ctx.strokeStyle = "Black";
		ctx.font = "12pt Helvetica";
		ctx.textAlign = "left";
		ctx.textBaseline = "middle";
		ctx.fillStyle = "#FF0000";
		ctx.fillRect(0,0,0,0);
		ctx2 = canvas.getContext('2d');
}



/* This function will allow us to over lay text on to the video player */
function overlayText(){

var text = document.getElementById('myTextArea').value;
var array = text.split("\n");

ctx.font = "16pt Arial";

	for(var i = 0; i < array.length; i++){
		var temp = array[i];
		ctx.textAlign="left";
		ctx.textBaseline="bottom";
		ctx.fillText(array[i], 40, 50);
		
	}
}

/* This is the function for the clear button */
function clear2(){
		canvas = document.getElementById("can"); 
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		document.getElementById("myTextArea").value = ""; 


}

/* This function helps us over lay images on the video */
function overlayPic(){
	
	string1 = document.getElementById("myImageSelection"); 
	var splitString = (string1.value).split(";");
	var pixels = splitString[0].split(",");
	var fileName = splitString[1];
	var textToDisplay = splitString[2];
	
	ctx.fillStyle = "black";
	
	var img = new Image();
	img.src = fileName; 

	img.onload = function(){
		ctx.drawImage(img, pixels[0], pixels[1], 100,100);
		ctx.fillStyle = "Red";
		ctx.strokeStyle = 'black';
		ctx.font = "bold 18px sans-serif";
		var temp;
		temp = pixels[0];
		
	}
	var left = pixels[0];
	var down = pixels[1];
	ctx.fillStyle = "Blue";
	canvas = document.getElementById("can"); 
	ctx2 = canvas.getContext('2d');
	ctx2.fillText(textToDisplay , (left + 3), (down));

}
