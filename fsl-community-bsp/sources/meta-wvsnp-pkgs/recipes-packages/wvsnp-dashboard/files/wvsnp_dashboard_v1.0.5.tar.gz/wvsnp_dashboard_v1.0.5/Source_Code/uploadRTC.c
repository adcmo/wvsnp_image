/*######################################################################
 *
 *  FILE: upload.c
 *  AUTHOR: Initial code provided by Adolph Seema, modified by 
 *	    Julius Eddards
 *
 *  DESCRIPTION:
 *	This code will produce a cgi file with the following function:
 *          1.) Upload a file.
 *
 *  This file is designed to create a HTML file that can be embedded
 *  in the WVSNP dash.
 *
 *  LAST MODIFIED: 12/07/2013 [JE]
 *######################################################################
*/

#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

//######### CONSTANTS DEFINITION
#define SERVER_NAME cgiServerName   //The server name is set in the mongoose config file.
#define BufferLen 1024
#define FILELOCATION "../CGI/" //Default file location on the server in relation to CGI file location

//######## PROTOTYPES
void handle_file();
void ShowForm();



//&&&&&&&&&&&&&&&&&&&&&&&& THE MAIN FUNCTION &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int cgiMain() 
{
    
   // if( cgiFormSubmitClicked("upload") == cgiFormSuccess )
    //{
      handle_file();
    //}

    
    return 0;
}


//&&&&&&&&&&&&&&&&&&&&&&&& HANDLER &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
void handle_file()
{
    cgiFilePtr file;            //File pointer
    char name[1024];            //File name as entered by user
    char contentType[1024];     //Content type of file to upload
    char buffer[1024];          //File write buffer
    char fileNameOnServer[64];  //Name of file with path on the server
    int size;                   //Size of file
    int got, t;                 //data pointers/index values
    int targetFile;             //New file that is created to store upload
    mode_t mode;                //Stores file mode bits
    char *tmpStr = NULL;        //Temporary string to hold file name
    int fail;	                //Flag if there is failure with file i/o
    int wflag;	                //flag to end a while loop
    int nofilespec;	            //flag used when no filename is specified.
    int fopenissue;	            //flag is couldn't open file.
    File *fp;
    
    //Setting default values:
    t         = -1;
    fail       = 0;
    wflag      = 1;
    nofilespec = 0;
    fopenissue = 0;




	
    //If no filename was entered, then error... **************For now we don't need this..as the app is opened, the JSON data need to be stored
   // if( cgiFormFileName("file", name, sizeof(name)) != cgiFormSuccess )
   // {
    //  printf("<p>No file was uploaded.<p>\n");
   //   nofilespec = 1;
   // } 
  
    //Continue if a file name was specified...
    /*if(!nofilespec){
        cgiFormFileSize("file", &size);

        fprintf( cgiOut, "The filename submitted was: " );
        cgiHtmlEscape( name );
        fprintf( cgiOut, "<p>\n" );
        cgiFormFileSize( "file", &size );
        fprintf( cgiOut, "The file size was: %d bytes<p>\n", size );

        cgiFormFileContentType( "file", contentType, sizeof(contentType) );

        fprintf( cgiOut, "The alleged content type of the file was: " );
        cgiHtmlEscape(contentType);
        fprintf( cgiOut, "<p>\n"); */
        //fprintf( cgiOut, "Of course, this is only the claim the browser made when uploading the file. Much like the filename, it cannot be trusted.<p>\n" );

        //Not showing contents
        //fprintf( cgiOut, "The file's contents are shown here: <p>\n" );
     
        if( cgiFormFileOpen("file", &file) != cgiFormSuccess ) 
        {
        fprintf( cgiOut, "Could not open the file.<p>\n" );
        fopenissue = 1;
        }

        /*You can save the file to directory here instead of displaying it*/
        if(!fopenissue){

	        while(wflag){
                tmpStr = strstr(name+t+1, "\\");
	  	        if(NULL == tmpStr)
	  		       tmpStr = strstr(name+t+1, "/");	//if \\ is not path separator, try /
	  	        if(NULL != tmpStr)
	  		       t = (int)(tmpStr - name);
	  	        else
	  		       wflag = 0;
	        }

	        strcpy(fileNameOnServer, FILELOCATION);

	        strcat(fileNameOnServer, name+t+1);

	        mode = S_IRWXU | S_IRGRP | S_IROTH;

	        //For simplicity, we will copy the file to the current folder.
	        //Create new file with a call to open

	        targetFile = open(fileNameOnServer, O_RDWR | O_CREAT | O_TRUNC | O_APPEND, mode);

	        if(targetFile < 0){
		        fprintf(stderr, "could not create the new file, %s\n", fileNameOnServer);
		        fail = 1;
            }

	        //Read content from the tmp file and write to new file
	        while(cgiFormFileRead(file, buffer, BufferLen, &got) == cgiFormSuccess){
		        if(got > 0)
			        write(targetFile, buffer, got);
	        }

            //We can now close the file...
	        cgiFormFileClose(file);
	        close(targetFile);

	        if(fail)
	        fprintf(stderr, "Failed to upload");
		
	        printf("File \"%s\" has been uploaded", fileNameOnServer);

        }//end of fopenissue if statement
    }//end of nofilespec if statement
}//end handle_file()



//&&&&&&&&&&&&&&&&&&&&&&&& HTML FORM DISPLAY &&&&&&&&&&&&&&&&&&&&&&&&&&&&
/*void ShowForm()
{
  fprintf( cgiOut, "<!-- 2.0: multipart/form-data is required for file uploads. -->");
  fprintf( cgiOut, "<form method=\"POST\" enctype=\"multipart/form-data\" ");
  fprintf( cgiOut, " action=\"");
  cgiValueEscape(cgiScriptName);
  fprintf( cgiOut, "\">\n");

        //HTML data for the upload routine
  fprintf( cgiOut, "<p>Select A Local File to Upload:\n" );
  fprintf( cgiOut, "<input type=\"file\" name=\"file\" value=\"\">\n");
  fprintf( cgiOut, "<input type=\"submit\" name=\"upload\" value=\"Upload\">\n");
  fprintf( cgiOut, "<p>\n" );

  //The following is useful when debugging issues:
  /*
  fprintf( cgiOut, "<p>Too Much Debug Info:\n\n" );
  fprintf( cgiOut, "<p>cgiRequestMethod(%s)\n", cgiRequestMethod );
  fprintf( cgiOut, "<p>cgiServerSoftware(%s)\n", cgiServerSoftware );
  fprintf( cgiOut, "<p>cgiServerName(%s)\n", cgiServerName );
  fprintf( cgiOut, "<p>cgiContentLength(%d)\n", cgiContentLength );
  fprintf( cgiOut, "<p>cgiUserAgent(%s)\n", cgiUserAgent );
  fprintf( cgiOut, "<p>cgiReferrer(%s)\n", cgiReferrer );
  fprintf( cgiOut, "<p>cgiGatewayInterface(%s)\n", cgiGatewayInterface );
  fprintf( cgiOut, "<p>cgiServerProtocol(%s)\n", cgiServerProtocol );
  fprintf( cgiOut, "<p>cgiServerPort(%s)\n", cgiServerPort );
  fprintf( cgiOut, "<p>cgiPathInfo(%s)\n", cgiPathInfo );
  fprintf( cgiOut, "<p>cgiPathTranslated(%s)\n", cgiPathTranslated );
  fprintf( cgiOut, "<p>cgiScriptName(%s)\n", cgiScriptName );
  fprintf( cgiOut, "<p>cgiQueryString(%s)\n", cgiQueryString );
  fprintf( cgiOut, "<p>cgiRemoteHost(%s)\n", cgiRemoteHost );
  fprintf( cgiOut, "<p>cgiRemoteAddr(%s)\n", cgiRemoteAddr );
  fprintf( cgiOut, "<p>cgiAuthType(%s)\n", cgiAuthType );
  fprintf( cgiOut, "<p>cgiRemoteUser(%s)\n", cgiRemoteUser );
  fprintf( cgiOut, "<p>cgiRemoteIdent(%s)\n", cgiRemoteIdent );
  fprintf( cgiOut, "<p>cgiContentType(%s)\n", cgiContentType );
  fprintf( cgiOut, "<p>cgiAccept(%s)\n", cgiAccept );
  fprintf( cgiOut, "<hr />\n" );

  

  fprintf( cgiOut, "</form>\n" );   //End of the HTML form

} */
