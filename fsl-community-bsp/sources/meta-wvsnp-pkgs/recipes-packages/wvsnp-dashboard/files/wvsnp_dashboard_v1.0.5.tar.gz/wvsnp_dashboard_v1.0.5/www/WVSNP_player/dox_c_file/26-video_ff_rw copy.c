


/** @brief Rewinds or fast forwards the video
 * 
 * FF or RW could occur within one segment. In this case no loading is required, 
 * only timeUpdate is needed. If FF occurs in the next segment that is already 
 * loaded, then no loading is required. Update the current_video_element to the 
 * other video element and update the time. If FF ahead more than one segment or 
 * RW to a prior segment, it is more complex. First, segment_end_time array is 
 * to determine the correct segment to load. Finally, the segment is loaded along 
 * with its predecessor. Once loading has occurred, play can be initiated.
 * 
 * @param event
 * 
 * The event that is called is the parameter
 * 
 * .............................................................................
 */ 
 Player.prototype.rewind_fast_forward = function(e, a_writer_video_index, that){
  //console.log("RW FF called, rewind_fastforward_in_progress = " + that.rewind_fast_forward_in_progress);
  /*! Detect if rewind fast forward is in progress.
  If it is we don't want to execute again. 
  We must wait until loading is complete before we make another
  rewind fast forward request. */
  if(!that.rewind_fast_forward_in_progress){      
    that.rewind_fast_forward_in_progress=true;    
    var video_is_paused;        
    //get the current mod_play index
    var mod_play_index = that.get_video_to_play_index();
    var current_video_element = that.set_current_video_element(mod_play_index);
    //get the current mod play time
    var mod_curr_time = that.segment_end_time[mod_play_index]- current_video_element.duration + current_video_element.currentTime;
    //get the druation of an episode, needed to calculate.
    var ep_dur = that.get_episode_dur(that);
    var back_time = (that.play_episode-1)*ep_dur;
    
    //get the current play episode
    var play_ep = that.play_episode;
    //var play_ep = that.get_play_episode(mod_curr_time, ep_dur);
    console.log("play_ep " +play_ep);
    
    //get the current segment play index
    var play_index = that.calc_real_to_play_i(that, mod_play_index);
    console.log("play_index " +play_index);
    
    //get the current time
    var a_current_time = that.segment_end_time[play_index]- current_video_element.duration + current_video_element.currentTime;   
    console.log("current_time " + a_current_time);
    
    //get the location of the mouse click on the play progress bar 
    var timebar = document.getElementById('progress_'+that.video_id);
    //! Get the time to RW or FF
    var pos = findPos(timebar);
    //  console.log("pos y is" + pos.y + " pos x is " + pos.x + "pagex is " + e.pageX); 
    var diffx = e.pageX - pos.x; 
    var mod_rw_ff_time = diffx/that.progress_w * that.progress_bar_duration;
    console.log("mod ff_rw_time" + mod_rw_ff_time);
    
    var add_remain_ep_time = ep_dur * (play_ep-1);
    console.log("added duration is " + add_remain_ep_time);
    
    var rw_ff_time = mod_rw_ff_time+add_remain_ep_time;
    var mod_find_segment = find_segment%(that.last_index - that.first_index + 1);
    /*! Case 1: If the desired segment does not currently exists in the buffer
     *  then make call to the rw_ff_case1s to fetch the segments required 
     * to play the desired segment.
     */
    
    var find_segment = that.segment_search(that, rw_ff_time);
    console.log("find segment = " + find_segment);
    
    /*! If video is paused, set variable accordingly. 
     *  If video is not paused it needs to be paused to fast foward and/ or 
     *  rewind, which is taken care of in the else if statement. This is only done for 
     *  non-live mode.
     */
    if(current_video_element.paused){     
     video_is_paused = true;
    }
    else if(that.play_back_option != 'LIVE' && rw_ff_time > a_current_time){
      video_is_paused = false;
      current_video_element.pause();
      console.log("segment not paused, now pausing segment");
    }
    /*! If playback mode is LIVE, then go to live_rewind_fast_forward function
     */
    if(that.play_back_option == 'LIVE'){
      console.log("calling live_rewind_fast_forward function");
      that.live_rewind_fast_forward(that, rw_ff_time, mod_rw_ff_time ,find_segment, video_is_paused, a_current_time, mod_play_index, play_index);     
    }
    /*! If playback mode is not LIVE (e.g. VOD or LOOP), then procede to additional cases.
     */
    else{
      if(rw_ff_time > that.max_duration){
        console.log("RW FF case 1 detected not LIVE mode (VOD of LOOP)");
        that.rewind_fast_forward_in_progress=false;
  //      that.loading_animation(); 
  //      that.is_getting_future_segments = true
        //If desired segment is not in buffer call rw_ff_case1 function.
  //      this.ff_time = rw_ff_time;
  //      that.rw_ff_case1(a_writer_video_index, that);
      }
      else{      
       /*! Case 2: If rewinding or fast forwarding within current segment, there 
        * is no need to reload segment. Just update current time.
        */
        if(play_index == find_segment && that.segment_transition == false ){
          console.log("case 2 detected");
          that.rw_ff_case2(rw_ff_time, video_is_paused, that);
        }
        /*! Case 3: If fast forwarding to next segment that is already loaded
         * there is no need to load segments. 
         */
        else if(play_index + 1 == find_segment && that.segment_transition == false){
          console.log("case 3 detected");
          that.rw_ff_case3(video_is_paused, find_segment, rw_ff_time ,that);
          }
       /*! Case 4: All other scenarios which RW or FF to other segements
         * which requires segments to be loaded. 
         */     
        else{
          that.rw_ff_case4(video_is_paused, find_segment, rw_ff_time ,that);
        }//end of Case 4    
      }    
    }
  }
 }
 
  Player.prototype.segment_search = function(that, rw_ff_time){
    var find_segment = null;
    for(var i = 0; i < that.segment_end_time.length && find_segment == null; i++){
     if(rw_ff_time <= that.segment_end_time[i]){
       find_segment = i;
       console.log("rewind to segment " + find_segment + " time of " + rw_ff_time);
     }
    }
    return find_segment;
  }

   
 
 
   /** @brief Gets segment that is beyond the buffered segments
   * 
   * A function that gets the segment and all prior segments from a fast forward
   * request that is beyond the buffered segments. 
   * 
   * .............................................................................
   */
  Player.prototype.rw_ff_case1 = function(a_writer_video_index, that){
    /*! If the maximum duration time of the buffered elements is less than the 
     * requested fastforward time, then get the next segment. */
    if(that.max_duration < that.ff_time){
      console.log("get future segments max duration " + that.max_duration + " less than ff time " + that.ff_time);
      that.check_for_file(a_writer_video_index);
    }
    /*! Once all the needed segments have been fetched and saved to the local
     * directory, then perform a check buffer to ensure that enough future segments
     * exist for the disired segment to play.  */
    else{    
      that.is_getting_future_segments = false;
      that.reader_video_index = that.segment_end_time.length - 1 ;
      that.video_to_play_index = that.segment_end_time.length - 1;
      var a_play_index = that.video_to_play_index;
      console.log("play_index " +  a_play_index);
      that.check_for_file(that.writer_video_index);
      
      var current_video_element = that.set_current_video_element(a_play_index);
      setTimeout(function(){
       console.log("calling readfile request from rw_ff case 1");
       that.read_file_request(a_play_index++);
      },30);
            
      setTimeout(function(){
        current_video_element.currentTime = that.ff_time;                        
        current_video_element.play();
        
        setTimeout(function(){
          that.end_loading_animation(); 
          that.rewind_fast_forward_in_progress=false;   
        },30);          
        console.log("calling readfile request from rw_ff case 1");
        that.read_file_request(a_play_index);
      
      },600);
    }   
  }
 
  Player.prototype.rw_ff_case2 = function(rw_ff_time, video_is_paused, that){
   var current_video_element = that.set_current_video_element(that.get_video_to_play_index());
   rw_ff_time = rw_ff_time - (that.segment_end_time[that.get_video_to_play_index()] - current_video_element.duration);
   current_video_element.currentTime = rw_ff_time;  
   if(video_is_paused==true){
     current_video_element.play();
     setTimeout(function(){
      current_video_element.pause();
      that.paused_stats_update(that);
    },33);
    }  
   else{
    current_video_element.play();  
    }
    that.rewind_fast_forward_in_progress=false;
 }
 
 
 Player.prototype.rw_ff_case3 = function(video_is_paused, find_segment, rw_ff_time ,that){
     console.log("RW FF case 3 detected, find_segment = " + find_segment + " rw_ff_time = " + rw_ff_time);
   that.video_to_play_index = find_segment;
   var current_video_element = that.set_current_video_element(find_segment);
   rw_ff_time = rw_ff_time - (that.segment_end_time[find_segment] - current_video_element.duration);
   if(video_is_paused == true){   
     current_video_element.currentTime = rw_ff_time;
     current_video_element.play();
     that.play_functions(that);
     console.log("calling readfile request from rw_ff case 3");
     that.read_file_request(++find_segment);        
     setTimeout(function(){
      current_video_element.pause();
      that.paused_stats_update(that);
     },33);
    }
    else{
     current_video_element.pause();
     current_video_element.currentTime = rw_ff_time;
     current_video_element.play();
     that.play_functions(that);
     console.log("calling readfile request from rw_ff case 3");
     that.read_file_request(++find_segment);
     that.rewind_fast_forward_in_progress=false;      
    }    
 }
 
 Player.prototype.rw_ff_case4 = function(video_is_paused, find_segment, rw_ff_time ,that ){
   console.log("RW FF case 4 detected, find_segment = " + find_segment + " rw_ff_time = " + rw_ff_time);
   that.video_to_play_index = find_segment;  
   var current_video_element = that.set_current_video_element(find_segment);
   console.log("rw_ff_time = " + rw_ff_time + " segment_end " + that.segment_end_time[find_segment] + " current duration " + current_video_element.duration + " find segment = " + find_segment);
   rw_ff_time = rw_ff_time - (that.segment_end_time[find_segment] - current_video_element.duration);
   console.log("rw_ff_time = " + rw_ff_time);
   that.loading_animation();  
   that.set_video_to_play_index(find_segment); 
   //console.log("calling readfile request from rw_ff case 4");
   that.read_file_request(find_segment);                   
   setTimeout(function(){
     current_video_element.currentTime = rw_ff_time;  
     //console.log("calling readfile request from rw_ff case 4");                 
     that.read_file_request(++find_segment);
     current_video_element.play();
     that.play_functions(that);
     that.rewind_fast_forward_in_progress=false;
     if(video_is_paused == true){
      setTimeout(function(){
        current_video_element.pause();
        that.paused_stats_update(that);     
      },100);
     }           
     setTimeout(function(){
      that.end_loading_animation(); 
         
     },100);                       
    },200);
 }//end of Case 4

  Player.prototype.get_play_episode=function(time,episode_duration){
    console.log("time = "+time + "episode_duration " + episode_duration);
    return Math.ceil(time/episode_duration);
  }

  Player.prototype.get_episode_dur=function(that){
    return that.typ_duration * (that.last_index - that.first_index + 1);
  }
  
  Player.prototype.get_mod_time=function(time, episode_duration){
    return time%episode_duration;
  } 

  Player.prototype.live_rewind_fast_forward = function(that, rw_ff_time, mod_rw_ff_time ,find_segment, video_is_paused, a_current_time, mod_play_index, play_index){
    console.log("Live mode detected, current play index = " + play_index + " mod_play_index = " + mod_play_index);
    var current_video_element = that.set_current_video_element(play_index);   
    console.log("live rewind called, current time = " + a_current_time + ", ff time = " + rw_ff_time + ", and live = " + that.live);      
    var live_time = that.get_live_time(that);
    
    /*! Case 1: If video is not live
     */ 
    if(that.live == false ){
      console.log(" get live time is " + that.get_live_time(that) + "live =" + that.live);
      
       /*! Case 1a: If user tries to fast forward past live time
        * 
       */ 
      if(rw_ff_time > live_time){
//        alert("I'm sorry, but you can'n fast forward past live time. Your are now playing live.");
        rw_ff_time = live_time;
        ep_dur=that.get_episode_dur(that);
        mod_rw_ff_time = that.get_mod_time(rw_ff_time,ep_dur);
        that.live_button_toggle(that,"on", "#FFFF00");
        console.log("calling change_reader_directory");
        that.change_reader_directory(that, "LIVE");
        that.live = true;
      }
      var episode_diff;
//      var mod_rw_ff_time=0;
      var episode_duration = that.get_episode_dur(that);
       /*! User fast forwards past the current episode. This can happen if the
        * user presses the live button.
       */ 
 /*     if(rw_ff_time > episode_duration){
        //if the desired rw/ff time is larger than an episode duration,
        //then the modulus of that time is needed to determine the point to ff to.
        //determine and set new play_episode global variable
        console.log("rw_ff_time = " + rw_ff_time + " episode_duration = " + episode_duration);
        that.play_episode = that.get_play_episode(rw_ff_time,episode_duration);
        console.log("desired play episode = " + that.play_episode);
        //Get the mod fw/ff time, by using the episode duration
        mod_rw_ff_time = that.get_mod_time(rw_ff_time,episode_duration);
        console.log("mod rw_ff_time is " + mod_rw_ff_time);    
           
      }
      else{
        mod_rw_ff_time = rw_ff_time;
      }
 */     
      var find_segment = that.segment_search(that, rw_ff_time); 
      var mod_find_segment = find_segment%(that.last_index - that.first_index + 1);
      console.log("mod_find_segment = " + mod_find_segment);
      
      var mod_live_time=live_time;
      if(live_time > episode_duration){
        console.log("The current live episode = " + that.live_episode);
        mod_live_time = live_time%episode_duration;
        console.log("mod live_time is " + mod_live_time);
      }     
      
      if(play_index == find_segment){
        console.log("case 2 detected");
        that.rw_ff_case2(mod_rw_ff_time, video_is_paused, that);
        console.log("rw_ff_time = " + rw_ff_time + " mod_rw_ff_time = " + mod_rw_ff_time + "live_time = " + live_time + 
        " mod live_time is " + mod_live_time + " that.live_episode = " + that.live_episode + "that.play_episode = " + that.play_episode);
        if(rw_ff_time == live_time && that.live_episode == that.play_episode){
          that.live=true;
          console.log("live set to true");
        }
        else{
          that.live = false;
          console.log("live set to false");
        }        
      }
      /*! If fast forwarding to next segment that is already loaded
       * there is no need to load segments. 
       */
      else if(play_index + 1 == find_segment){
        console.log("case 3 detected for live mode");
        that.rw_ff_case3(video_is_paused, mod_find_segment, mod_rw_ff_time ,that);
        console.log("rw_ff_time" + rw_ff_time + " mod_rw_ff_time = "+ mod_rw_ff_time +"live_time = " + live_time +
         "that.live_episode = " + that.live_episode + "that.play_episode = " + that.play_episode);
        if(rw_ff_time == live_time  && that.live_episode == that.play_episode){
          that.live=true;
          console.log("live set to true");
        }
        else{
          that.live = false;
          console.log("live set to false");
        } 
       }
     /*! All other scenarios which RW or FF to other segements
       * which requires segments to be loaded. 
       */     
      else{
        that.rw_ff_case4(video_is_paused, mod_find_segment, mod_rw_ff_time ,that);
        console.log("rw_ff_time  " + rw_ff_time + " mod_rw_ff_time = "+ mod_rw_ff_time + "live_time = " + live_time + 
        "that.live_episode = " + that.live_episode + " that.play_episode = " + that.play_episode);
        if(rw_ff_time == live_time  && that.live_episode == that.play_episode){
          that.live=true;
          console.log("live set to true");
        }
        else{
          that.live = false;
          console.log("live set to false");
        } 
      } 
//      rw_ff_time= that.live_time(that);       
    }
     /*!If video is live
      * 
      */        
    else if(that.live == true){
      var mod_find_segment = find_segment%(that.last_index - that.first_index + 1);
      if(rw_ff_time > a_current_time){
        console.log("I'm sorry, but you can'n fast forward past live time");
        that.live_indicator_flash(that, 9,"off")
        that.rewind_fast_forward_in_progress = false;
      }      
      else if(rw_ff_time < a_current_time){
        //that.get_live_count_baseline(that);//gives time stamp for at point live time was left
        console.log("live time is " + live_time);
        //that.leave_live_time = a_current_time;
        that.live=false;
        console.log("live time changed to = false");
        console.log("calling change_reader_directory");
        that.change_reader_directory(that, "VOD");
        that.live_button_toggle(that, "off", "#FFFF00");
        if(play_index == find_segment){
          console.log("case 2 detected");
          that.rw_ff_case2(mod_rw_ff_time, video_is_paused, that);
        }
        /*! Case 3: If fast forwarding to next segment that is already loaded
         * there is no need to load segments. 
         */
        else if(play_index + 1 == find_segment){
          console.log("case 3 detected");
          that.rw_ff_case3(video_is_paused, mod_find_segment, mod_rw_ff_time ,that);
         }
       /*! Case 4: All other scenarios which RW or FF to other segements
         * which requires segments to be loaded. 
         */     
        else{
          console.log("case 4 detected");
          that.rw_ff_case4(video_is_paused, mod_find_segment, mod_rw_ff_time ,that);
        } 
      }
    }       
    else{
      console.log("not detected case in live rw ff");
      that.rewind_fast_forward_in_progress=false;   }
  }

Player.prototype.live_indicator_flash = function(that,flash_remaining, position){
//  console.log("live flash called");
  var live_toggle = document.getElementById("live_toggle_"+that.video_id);
  if(flash_remaining>=1){
    that.live_button_toggle(that,position, "#FF0000");
    if(position == "on"){position = "off";}
    else{position ="on";}
    setTimeout(function(){
      that.live_indicator_flash(that,--flash_remaining,position);
    },200);
  }
  else if(flash_remaining == 0){
    that.live_button_toggle(that,position, "#FFFF00");
  }  
}