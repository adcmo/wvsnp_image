/*######################################################################
 *
 *  FILE: snapshot.c
 *  AUTHOR: Julius Eddards
 *
 *  DESCRIPTION:
 *	This code will produce a cgi file with the following function:
 *		
 *		1. Webcam image capture on demand.
 *
 *	The webcam service allows the user to define the name of the
 *	image taken.  If a name is not specified, then a timestamp will
 *	be used.  Once the Snapshot button is pressed, the image is
 *	taken and then presented on the web page.  The user may then
 *	click the image to get to the file.
 *
 *  LAST MODIFIED: 12/07/2013 [JE]
 *######################################################################
*/

#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

//######### CONSTANTS DEFINITION
#define SERVER_NAME cgiServerName	//The server name is set in the mongoose config file.
#define BufferLen 1024
#define FILELOCATION "../snapshots/ "//There must be a space for the last
									 //character in the quotations since 
									 //bash script input parameters are
									 //delimited by spaces.

//######## PROTOTYPES
void handle_multiply();
void handle_file();
void handle_snapshot();
void handle_playvideo();
void ShowForm();

//&&&&&&&&&&&&&&&&&&&&&&&& THE MAIN FUNCTION &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int cgiMain() 
{
  /* Send the content type, letting the browser know this is HTML */
  cgiHeaderContentType("text/html");

  /* Top of the page */
  fprintf( cgiOut, "<HTML><HEAD>\n" );
  fprintf( cgiOut, "<TITLE>Snapshot</TITLE></HEAD>\n" );

  //fprintf( cgiOut, "<BODY><H3>%s DashBoard</H3>\n", SERVER_NAME );

  fprintf( cgiOut, "<BODY>\n");
 
//  fprintf( cgiOut, "<hr />\n" );

//This handles the event when the snapshot button is pressed:

	if(cgiFormSubmitClicked("snapshot") == cgiFormSuccess){
		handle_snapshot();
		fprintf( cgiOut, "\n");
	}

  /* Now show the form -- i.e The basic/default web interface to this program*/
  ShowForm();
        
  /* Finish up the page */
  fprintf( cgiOut, "</BODY></HTML>\n" );
  return 0;
}



//&&&&&&&&&&&&&&&&&&&&&&&& HANDLER &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//This is the handler for the snapshot button.  
//This will call the bash script to activate the webcam of the host and save 
//the file to the /snapshot/ directory.  This function will check to see if the
//user entered in a requested file name.  If there is a file name specified, then
//the function will save the webcam photo using the specified file name.  If there
//is not a file name specified, then the program will use a timestamp that provides
//accuracy down to milliseconds to ensure a unique file name is created.

void handle_snapshot(){

	char syscall[64];	//To be used in system call to script
	char filename[64];	//The variable that is the filename of the picture taken

	char timestamp[64], filetimestamp[64];	//Used in the timestamp creation process

	char filepath[64];	//To hold the path to file

	struct tm *mytime;	//Structure that is defined in time.h.  This provides usefull
						//time-date data extraction capabilities.
	struct timeval tv;	//Structure that is defined in time.h.  This provides the raw
						//time information.
	long milliseconds;	//To store the milliseconds value.

	strcpy(syscall, "/bin/bash /home/root/wvsnp_dashboard_v1.0.3/www/CGI/snapshot.sh ");	//Starting with the command to the script.

	strcat(syscall, FILELOCATION);

	cgiFormStringNoNewlines( "sname", filename, 20 );	//Getting the requested  filename from the form

	strcpy(filepath, "../snapshots/");	//Starting the creation of filepath

	if(strlen(filename) == 0){	//Check if a filename was entered, if not, use timestamp

		gettimeofday(&tv, NULL);	//Getting the raw time data.
		mytime = localtime(&tv.tv_sec);	//Setting the mytime structure as localtime with precision
						//down to seconds.
	
		//It should be noted that the struct tm does not provide resolution down to the milliseconds.
		//In order to get millisecond resolution, we have to do three things: 1. Get time down to the
		//seconds, 2. get the millisecond value, 3. Create string by concatenating 1 and 2.

		strftime(timestamp, sizeof timestamp, "%Y-%m-%d_%H:%M:%S",mytime);	//1. Time down to Seconds

		milliseconds = tv.tv_usec / 1000;	//2. Getting milliseconds from microseconds

							//3. Concatenate by using a buffered string
		snprintf(filetimestamp, sizeof filetimestamp,"%s.%03ld",timestamp, milliseconds);

		strcpy(filename, filetimestamp);	//Set the filename to be the timestamp that was just created.

	}
	
	strcat(syscall, filename);	//Concatenating the filename to the system call

	system(syscall);		//calling the bash script with filename as parameter
	
	strcat(filename, ".png");	//Adding extension to filename

	printf("The snapshot \"%s\" has been uploaded", filename);	//Confirmation Message

	strcat(filepath, filename);		//Adding filename to the filepath
	
	fprintf( cgiOut, "<p>\n");
	fprintf( cgiOut, "<a href=\"%s\">", filepath);	//The image presented will also be a link
													//to the captured image.  The image as it is
													//shown on the page will be of reduced size.

	fprintf( cgiOut, "<img src=\"%s\" width=\"640\" height=\"360\" alt=\"Snapshot\">", filepath);

	fprintf( cgiOut, "</a>");
}



//&&&&&&&&&&&&&&&&&&&&&&&& HTML FORM DISPLAY &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
void ShowForm()
{
  fprintf( cgiOut, "<!-- 2.0: multipart/form-data is required for file uploads. -->");
  fprintf( cgiOut, "<form method=\"POST\" enctype=\"multipart/form-data\" ");
  fprintf( cgiOut, " action=\"");
  cgiValueEscape(cgiScriptName);
  fprintf( cgiOut, "\">\n");

	//HTML data for the snapshot function
  fprintf( cgiOut, "Snapshot Filename&nbsp;:");
  fprintf( cgiOut, "<input type=\"text\" name=\"sname\" size=\"10\"><br />");
  fprintf( cgiOut, "<p>Press to take a snapshot: \n");
  fprintf( cgiOut, "<input type=\"submit\" name=\"snapshot\" value=\"Snapshot\">\n");
  fprintf( cgiOut, "<p>\n" );

  fprintf( cgiOut, "</form>\n" );
}
