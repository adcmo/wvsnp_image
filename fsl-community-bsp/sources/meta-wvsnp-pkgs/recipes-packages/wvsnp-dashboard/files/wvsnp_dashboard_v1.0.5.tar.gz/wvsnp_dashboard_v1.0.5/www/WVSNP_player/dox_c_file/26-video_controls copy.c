  /** @brief Gets the duration of the segment and updates the controls.
   * 
   * A function to that gets the duration of the latest segment written to the local 
   * directory. It is placed in a video element called check_buffered_duration_element
   * so that the duration can be determined. Then the duration is updated in the controls.
   * It is also saved to an array segment_end_time. This is used by the rewind_fast_forward
   * function.
   * 
   * .............................................................................
   */
  Player.prototype.get_duration = function(a_writer_video_index, that){  
    //!< A local variable for the global duration element in the video controls
    var controls_duration = document.getElementById("duration_"+that.video_id); 
    //!< A local variable for the load progress element in the video controls  
    var load_progress = document.getElementById("load_progress_"+that.video_id); 
  
    if(that.typ_duration == -1){
      that.typ_duration = Math.floor(document.getElementById("check_buffered_duration_"+that.video_id).duration);
      var total_segments = that.last_index - that.first_index +1;
      that.progress_bar_duration = total_segments * that.typ_duration;
    }
    /*! update the global variable buffered_file_duration */
    that.buffered_file_duration = that.buffered_file_duration + Math.floor(document.getElementById("check_buffered_duration_"+that.video_id).duration);
    /*! Adds the video duration to the segment_end_time array used in ff_rw functions */
   console.log("a_writer_video_index "+ a_writer_video_index + " segment duration = " + Math.floor(document.getElementById("check_buffered_duration_"+that.video_id).duration));
    that.segment_end_time[a_writer_video_index] = that.buffered_file_duration;      
    //Function call to update the duration bar in the controls.
    that.calculate_buffer_status_bar();   
    /*! Formats the duration into mm:ss and sets the duration on the video controls*/
    controls_duration.firstChild.nodeValue = format_time(that.buffered_file_duration);

    /*! Set the max_duration variable */
    that.max_duration = that.buffered_file_duration;
    that.writer_video_index = ++a_writer_video_index;
    that.called_from_write_buffering_in_progress = true;
    that.check_buffer(a_writer_video_index);
  
  }
  
   Player.prototype.remove_percent=function(string){
    //console.log("string = " +string);
    string = string.substring(0, string.length -1);
    parseInt(string);
    //console.log("string = " +string);
    return string;
  }
  
    /** @brief Updates the duration in the controls.
   * 
   * A function that updates the duration dispaly bar in the controls. The duration
   * is determined by the max duration from the video in the buffer.
   * 
   * @param start_pos_i - gives the index of the start position. Function is
   * "overloaded" so may be undefined. 
   * 
   * start_pos_i is called when switching from VOD to live and the starting position
   * of the buffer bar does not start at 0. 
   * .............................................................................
   */
  Player.prototype.calculate_buffer_status_bar=function(start_pos_i, reset){
    var that = this;
    var load_progress = document.getElementById("load_progress_"+that.video_id); 
    console.log("start_pos_i = " + start_pos_i);
    //Set local variable to the total segments in an episode
    var total_segments = that.last_index - that.first_index + 1;
    //local variable determins the percentage each segment fills in the buffer duration
    var percent_per_segment = 100/total_segments;
    console.log("percent_per_segment = " + percent_per_segment);
    /*! if start_pos was not defined in the function call, 
     * then set it to the current start position.*/
    if(reset == undefined){     
      reset = false;
    }
    console.log("reset is = " +reset);
    /*!Determine the start position as a percentage. Set global variable buffer_start_pos
     */
    if(start_pos_i ==undefined){
      that.buffer_start_pos = that.remove_percent(load_progress.style.left);
      that.buffer_start_pos = that.buffer_start_pos
      start_pos_i = that.buffer_start_pos/percent_per_segment;   
      console.log("that.buffer_start_pos = " + that.buffer_start_pos + " start_pos_i " + start_pos_i);   
    }
    else{
      that.buffer_start_pos = percent_per_segment * start_pos_i;
      console.log("buffer_start_pos = " + that.buffer_start_pos);
    }
    var temp_time_percent = that.remove_percent(load_progress.style.width);
    /* local varible for the current time percent */
    var curr_time_percent = 1*temp_time_percent+1*that.buffer_start_pos;
    console.log("curr_time_percent = " + curr_time_percent);
    
    /*Sets the global variable for the start position of the buffer bar.*/

 
    /*! Determines status of the duration and the percent of the buffer bar to be filled. 
     * Modulus operator is used to get the proper percentage once duration exceeds the first episode. */
     var timePercent = that.modulo_time(that,that.buffered_file_duration); 
     /*! if the timePercent is 0 change to 100. */
     if(timePercent == 0){
       timePercent = 100;
      }
    console.log("timepercent = " + timePercent );
    
    if(curr_time_percent != 100 ){
      that.update_buffer_status_bar(that,timePercent)
    }
    else if(curr_time_percent == 100 && reset==true){
      that.update_buffer_status_bar(that,timePercent)
    }

  }
  
  Player.prototype.update_buffer_status_bar=function(that, timePercent){
    var load_progress = document.getElementById("load_progress_"+that.video_id); 
    /* local variable adjusted time percent based off start position */
    var adj_timePercent = timePercent - that.buffer_start_pos;   
    /*! Sets the CSS style to the percent of the buffer bar to be filled */
    load_progress.style.width = adj_timePercent + "%";
    /*! Sets the CSS style for the start position of the buffer bar */
    load_progress.style.left = that.buffer_start_pos + "%";     
  }
  
  Player.prototype.modulo_time = function(that, time){
    /*! Determines status of the duration and the percent of the buffer bar to be filled. 
     * Modulus operator is used to get the proper percentage once duration exceeds the first episode. */
  		return ((time%(that.progress_bar_duration))/that.progress_bar_duration)*100;       	      	
  }
  


  /** @brief Gives the time at the position where the mouse hovers over the 
   * progress bar
   * 
   * A function that gets the position of the mousemove over the progress by 
   * calling findPos function. Then it updates the html element.
   * 
   * @param event
   * 
   * The event that is called is the parameter
   * 
   * .............................................................................
   */ 
  Player.prototype.notice_timecode = function(e, that){
  //  console.log("time code called");
//    var that = this;
    var timebar = document.getElementById('progress_'+that.video_id);
    var notice = document.getElementById("timebar_status_"+that.video_id);
    var pos = findPos(timebar);
  //  console.log("pos y is" + pos.y + " pos x is " + pos.x + "pagex is " + e.pageX);    
        
    var diffx = e.pageX - pos.x;      
    var rw_ff_time = Math.round(diffx/that.progress_w * that.progress_bar_duration);
  //  console.log("rw_ff_time " + rw_ff_time);
    
    if(rw_ff_time < 0) rw_ff_time = 0;
    notice.innerHTML = format_time(rw_ff_time);
        
    notice.style.marginLeft = (diffx + 3 - notice.offsetWidth / 2)+'px';
  };
  

  /** @brief Gets the current time of the segment and updates the controls
   * 
   * A function that gets the current time of the segment and loads it into 
   * the current_time_element in the browser and updates 
   * the play progress bar in the video controls.
   * 
   * .............................................................................
   */
  Player.prototype.get_current_time = function() {
    var that = this;
    that.start_count_running = true;
    var current_time =0;
    var current_mod_time=0;
    var play_progress = document.getElementById("play_progress_"+that.video_id); //!< A local variable for the play progress element in the video controls
    var current_time_element = document.getElementById("current_time_"+that.video_id); //!< A local variable for the current time element in the video controls
    var t = window.setInterval(function() {
//      console.log("video element to play = " + that.get_video_to_play_index());
	  var current_mod_index = that.get_video_to_play_index();
	  var real_play_index= that.calc_real_to_play_i(that, current_mod_index); 
	  
      var current_video_element = that.set_current_video_element(current_mod_index);
      
      if(current_video_element.paused || current_video_element.ended){
//        console.log("current time current video is paused");     
      } 
      else{
        //console.log("real_play_index "+ real_play_index  +" segment end time = " + that.segment_end_time[real_play_index] + " current video element duration = " + current_video_element.duration + " curent_video_element current time " + current_video_element.currentTime);
        current_time = that.segment_end_time[real_play_index]- current_video_element.duration + current_video_element.currentTime;
        current_mod_time = that.segment_end_time[current_mod_index]- current_video_element.duration + current_video_element.currentTime;
        var timePercent = (current_mod_time/that.progress_bar_duration)*100;
        timePercent = timePercent - that.buffer_start_pos;
        play_progress.style.width = timePercent + "%";
        play_progress.style.left = that.buffer_start_pos + "%";
        current_time_element.firstChild.nodeValue = 
           format_time(current_time);
      } 
    },500);
  }//END of get_current_time
  
  Player.prototype.set_current_t_bar=function(that,mod_cur_time){
  	return function(that,mod_cur_time){
  		
  	}
  }
  
    
  /** @brief Checks if the element is a child node of the control panel.
   * 
   * If the element is a child node of the video controls, do not call hidePopup.
   * 
   * .............................................................................
   */
  Player.prototype.mouseEnter = function (_fn,that)
  {
     return function(_evt)
     {
        var relTarget = _evt.relatedTarget;
        if (this === relTarget || that.isAChildOf(this, relTarget)){ 
          return; 
          }
        _fn.call(this, _evt);
     }
  };

  /** @brief Checks if the element is a child node video controls.
   * 
   * Checks if the element is a node of the video controls.
   * 
   * .............................................................................
   */
  Player.prototype.isAChildOf = function(_parent, _child)
  {
     if (_parent === _child) { return false; }
        while (_child && _child !== _parent)
     { _child = _child.parentNode; }
  
     return _child === _parent;
  }
  
  /** @brief Displays the video controls
   * 
   * Displays the video controls
   * 
   * .............................................................................
   */
  Player.prototype.showPopup = function(that){
      if(that.is_fullscreen){
    that.control_mouseover_count++;
          document.getElementById("video_controls_"+that.video_id).className = "video_controls";
          that.control_hover = true;
   }
  }
  
  /** @brief Hides the video controls
   * 
   * Hides the video controls
   * 
   * .............................................................................
   */
  Player.prototype.hidePopup = function(that){
   
    that.control_hover = false; 
  
    if(that.is_fullscreen){
         setTimeout(function(){
            that.control_mouseout_count++;
             //console.log("mouse out " + that.control_mouseout_count );
        if(that.is_fullscreen && that.control_hover === false && that.control_mouseout_count === that.control_mouseover_count ){
          document.getElementById("video_controls_"+that.video_id).className = "video_controls_transparent";
        }
   // video.control
      },6000);  
    }  
  }
 
 
  
    /** @brief Formats time
   * 
   * A function that formats time
   * 
   * @param seconds
   * 
   * @return time 
   * 
   * Time gets returned in mm:ss format
   * 
   * .............................................................................
   */ 
  var format_time = function(seconds) {
    var seconds = Math.round(seconds);
    var minutes = Math.floor(seconds / 60);
    // Remaining seconds
    seconds = Math.floor(seconds % 60);
    // Add leading Zeros
    minutes = (minutes >= 10) ? minutes : "0" + minutes;
    seconds = (seconds >= 10) ? seconds : "0" + seconds;
    return minutes + ":" + seconds;
  }

  /** @brief Finds the position of the mouse over the progress bar
   * 
   * A function that gets the position of the mousemove over the progress bar
   * 
   * @param event
   * 
   * The event that is called is the parameter
   * 
   * @return position
   * 
   * Returns the position of the mouse over the progress bar.
   *  
   * .............................................................................
   */ 
  findPos = function(el){
    var x = y = 0;
    if(el.offsetParent){
     do {
       x += el.offsetLeft;
       y += el.offsetTop;
     }while(el = el.offsetParent);         
    }
    return {x:x,y:y};
  };

  