Player.prototype.getVideoToPlayIndex = function (that) {
	return that.video_to_play_index;
};

Player.prototype.setVideoToPlayIndex = function (that, val) {
	that.video_to_play_index = val;
};

Player.prototype.getReaderVideoIndex = function (that) {
	return that.reader_video_index;
};

Player.prototype.setReaderVideoIndex = function (that, val) {
	that.reader_video_index = val;
};

/** @brief returns the filename for the given quality
 * .............................................................................
 */
Player.prototype.getFileNameForQuality = function (that, quality) {

	if (quality <= that.pres_int_max && quality >= that.pres_int_min) {
		return that.v_basename + '-' + that.pres_int_max + '-' + quality + '-' + that.play_back_option + '-' + that.last_index + '-';
	}
};

/** @brief returns the filename and path at the server for the current video
 * .............................................................................
 */
Player.prototype.getRemoteFileName = function (that, video_index) {

	// return the filename with the selected quality-index for the current video-segment
	var currentRemoteFileName = that.v_dir + "/" + that.getFileNameForQuality(that, that.segment_quality[video_index]) + video_index + "." + that.v_container;
	return currentRemoteFileName;
};


/** @brief checks for a given directory and video-filename if there are other codecs available
 * 
 * given a directory and a filename for a video, this function checks if there are other
 * representations (i.e. codecs) for the video available. Returns a list of codecs supported
 * by the current browser and the topmost common directory.
 * Will work for WVSNP-format and plain videos.
 * 
 * @param parentDirectory - the current parent directory for the video-file
 * @param fileName - the current filename for the video (including extension)
 * @param wvsnp - check for WVSNP format or plain-video
 *
 * .............................................................................
 */
Player.prototype.checkForOtherCodecs = function (that, parentDirectory, fileName) {

	// -----------------------------
	// --- SUPPORTED FORMATS by WVSNP
	// -----------------------------

	console.log('Parent Dir: ' + parentDirectory);
	
	
	// order of codecs
	// make an exception for Opera and Firefox to speed up the checking process
	if(detectedBrowser == "Opera" || detectedBrowser == "Firefox") {
		var videoFormatsList = ["webm", "ogg", "ogv", "ogx", "mp4", "m4v", "hls", "mpd"];
	}
	else {
		var videoFormatsList = ["mp4", "m4v", "ogg", "ogv", "ogx", "webm", "hls", "mpd"];
	}
	// now check if there is a parent folder which contains other video-formats
	// example:  /path/to/video/mp4/filename-1-0-1-VOD-30-3.mp4
	//       --> /path/to/video/ogg/filename-1-0-1-VOD-30-3.ogg
	//       --> /path/to/video/hls/filename-VOD.m3u8
	
	// regexp produces two strings: "filename-1-0-1-VOD-30-3" and "mp4"
	var regexp_fileextension = /^(.*?)\.([^\.]+?)$/g;
	var fileNameParts = [fileName.replace(regexp_fileextension, '$1'), fileName.replace(regexp_fileextension, '$2')];
	
	// regexp would produce two strings: "/path/to/video" and "mp4"
	var regexp_directory = /^(.*?)\/([^\/]+?)\/$/g;
	var topmostDirectory = parentDirectory;
	if(parentDirectory.search(regexp_directory) != -1 && videoFormatsList.contains(parentDirectory.replace(regexp_directory, '$2')))
	{
		topmostDirectory = parentDirectory.replace(regexp_directory, '$1/');
	}
	
	// directory which will be returned by the function
	var returnDirectory = topmostDirectory;

	var returnVideoFormats = new Array();
	
	console.log('Topmost Dir: ' + topmostDirectory);
		
	/*
	========================
	check for WVSNP segments
	========================
	*/
		
	// check for eventually supported additional video formats
	// NOTE: hls with m3u8 and MPEG-DASH with mpd is not checked here, as it is tested explicitly
	// only check mime-types before that
	var http = new XMLHttpRequest();
	for(var i = 0; i < videoFormatsList.length - 2; i++)
	{
		// first check if browsers supports video
		if(supports_media('video/' + videoFormatsList[i], "video"))
		{
			// check if file exists in codec-directory
			// example: /path/to/video/FILEEXTENSION/filename-1-0-1-VOD-30-3.FILEXTENSION
			http.open('GET', topmostDirectory + videoFormatsList[i] + '/' + fileNameParts[0] + '.' + videoFormatsList[i], false);
			http.send();
			if(http.status != 404)
			{
				that.logger('stream supports ' + videoFormatsList[i]);
				// file exists, so codec exists, add to list of supported codecs
				returnVideoFormats.push(videoFormatsList[i]);
				returnDirectory = topmostDirectory + videoFormatsList[i] + '/';
				// only need to have 1 supported format, do not check further
				break;
			}
			
			// otherwise check if a video-file with supported codec is in the same directory
			// example: /path/to/video/filename-1-0-1-VOD-30-3.FILEXTENSION
			http.open('GET', topmostDirectory + fileNameParts[0] + '.' + videoFormatsList[i], false);
			http.send();
			if(http.status != 404)
			{
				that.logger('stream supports ' + videoFormatsList[i]);
				// file exists, so codec exists, add to list of supported codecs
				returnVideoFormats.push(videoFormatsList[i]);
				// only need to have 1 supported format, do not check further
				break;
			}
		}
	}
	
	/*
	=========================================
	Explicit check for MPEG-DASH streams here
	=========================================
	*/

	var mpegDashFilePath = -1;
	// check for hls/m3u8 explicity here
	if(supports_media('mpeg-dash'))
	{
		var regexpSearchWvsnp = /^([^\/]+?)-([0-9]+)-([0-9]+)-(.+?)-([0-9]+)-([0-9]+)\.(.+?)$/g;	
		
		// search for two filenames - either the "non-WVSNP" MPEG-DASH stream or
		// an alternative for the WVSNP stream, which might be filename-MODE.mpd
		var potentialNames = [];
		if(fileName.search(regexpSearchWvsnp) != -1 )
		{
			potentialNames = [fileNameParts[0], fileName.replace(regexpSearchWvsnp, '$1-$5')];
		}
		else
		{
			potentialNames = [fileNameParts[0]];
		}
		
		for(var i = 0; i < potentialNames.length; i++)
		{
			// first look in the subdirectory MPEG-DASH
			http.open('GET', topmostDirectory + 'dash/' + potentialNames[i] + '.mpd');
			http.send();
			if((http.status >= 200 && http.status < 299))
			{
				that.logger('stream supports MPEG-DASH');
				// file exists, so codec exists, add to list of supported codecs
				returnVideoFormats.push('mpd');
				mpegDashFilePath = topmostDirectory + 'dash/' + potentialNames[i] + '.mpd';
				break;
			}
			
			// otherwise check in the same directory
			http.open('GET', topmostDirectory + potentialNames[i] + '.mpd', false);
			http.send();
			if((http.status >= 200 && http.status < 299))
			{
				that.logger('stream supports MPEG-DASH');
				// file exists, so codec exists, add to list of supported codecs
				returnVideoFormats.push('mpd');
				mpegDashFilePath = topmostDirectory + potentialNames[i] + '.mpd';
				break;
			}
		}
	}
	
	/*
	===================================
	Explicit check for HLS streams here
	===================================
	*/

	var hlsFilePath = -1;
	// check for hls/m3u8 explicity here
	if(detectedBrowser == "Safari" || supports_media('application/x-mpegURL;', "video"))
	{
		var regexpSearchWvsnp = /^([^\/]+?)-([0-9]+)-([0-9]+)-(.+?)-([0-9]+)-([0-9]+)\.(.+?)$/g;	
		
		// search for two filenames - either the "non-WVSNP" HLS stream or
		// an alternative for the WVSNP stream, which might be filename-MODE.m3u8
		var potentialNames = [];
		if(fileName.search(regexpSearchWvsnp) != -1 )
		{
			potentialNames = [fileNameParts[0], fileName.replace(regexpSearchWvsnp, '$1-$5')];
		}
		else
		{
			potentialNames = [fileNameParts[0]];
		}
		
		for(var i = 0; i < potentialNames.length; i++)
		{
			// first look in the subdirectory HLS
			http.open('HEAD', topmostDirectory + 'hls/' + potentialNames[i] + '.m3u8', false);
			http.send();
			if(http.status != 404)
			{
				that.logger('stream supports hls');
				// file exists, so codec exists, add to list of supported codecs
				returnVideoFormats.push('hls');
				hlsFilePath = topmostDirectory + 'hls/' + potentialNames[i] + '.m3u8';
				break;
			}
			
			// otherwise check in the same directory
			http.open('HEAD', topmostDirectory + potentialNames[i] + '.m3u8', false);
			http.send();
			if(http.status != 404)
			{
				that.logger('stream supports hls');
				// file exists, so codec exists, add to list of supported codecs
				returnVideoFormats.push('hls');
				hlsFilePath = topmostDirectory + potentialNames[i] + '.m3u8';
				break;
			}
		}
	}
	
	return [returnVideoFormats, returnDirectory.replace(/(\/+?)/g, '/'), (hlsFilePath != -1 ? hlsFilePath.replace(/(\/+?)/g, '/') : -1), (mpegDashFilePath != -1 ? mpegDashFilePath.replace(/(\/+?)/g, '/') : -1)];
}

/** @brief helper function for buffering the video
 *  original source taken from
 *  https://www.khronos.org/registry/webgl/sdk/tests/conformance/textures/texture-npot-video.html
 *  https://www.khronos.org/registry/webgl/sdk/tests/conformance/resources/webgl-test-utils.js
 *
 * @param video - the HTML5 <video>-element that should be start buffering
 * @param callback - function that should be called as callback, once the video is "really" ready
 * @param callbackTimeout - if the video will not start playing after a specific timeout, this callback will be called
 * @param timeout - optional, specify an explicit timeoutt
 */
Player.prototype.startPlayingAndWaitForVideo = function (that, video, callback, callbackTimeout, timeout) {

	var videoValidationInterval = window.setInterval(function(){
		if (video.readyState > 0) {
			var vid_duration = video.duration;
			// once the video has a valid duration, callback
			if(!isNaN(vid_duration) && vid_duration > 0) {
				// clear timeout for "no valid execution"
				window.clearTimeout(videoValidationTimeout);
				window.clearInterval(videoValidationInterval);
				callback();
			}
		}
	}, 200);
	
	var videoValidationTimeout = window.setTimeout(function() {
		// clear interval to look for valid duration
		window.clearInterval(videoValidationInterval);
		// callback "failure" timeout - video is not valid
		callbackTimeout();
	}, (typeof timeout !== 'undefined' ? timeout : 1000));

	/*var gotPlaying = false;
	var gotTimeUpdate = false;
	var calledCallback = false;

	var maybeCallCallback = function () {
		if (gotPlaying && gotTimeUpdate && !calledCallback) {
			window.clearTimeout(currentPlaybackTimeout);
			video.pause();
			video.volume = 1;
			video.muted = false;
			video.currentTime = 0.0;
			calledCallback = true;
			video.removeEventListener('playing', playingListener, false);
			video.removeEventListener('timeupdate', timeupdateListener, false);
			callback();
		}
	};

	var playingListener = function () {
		video.muted = "muted";
		gotPlaying = true;
		maybeCallCallback();
	};

	var timeupdateListener = function () {
		// Checking to make sure the current time has advanced beyond
		// the start time seems to be a reliable heuristic that the
		// video element has data that can be consumed.
		if (video.currentTime > 0.0) {
			gotTimeUpdate = true;
			maybeCallCallback();
		}
	};
	
	var currentPlaybackTimeout = window.setTimeout(function() {
		video.removeEventListener('playing', playingListener, false);
		video.removeEventListener('timeupdate', timeupdateListener, false);
		callbackTimeout();
	}, (typeof timeout !== 'undefined' ? timeout : 1000));

	video.addEventListener('playing', playingListener, false);
	video.addEventListener('timeupdate', timeupdateListener, false);
	//video.loop = true;
	video.volume = 0;
	video.muted = "muted";
	video.load();
	video.play();*/
};


Player.prototype.removePercent = function (string) {
	string = string.substring(0, string.length - 1);
	parseInt(string);
	return string;
}


Player.prototype.modulo_time = function (that, time) {
	/*! Determines status of the duration and the percent of the buffer bar to be filled. 
	 * Modulus operator is used to get the proper percentage once duration exceeds the first episode. */
	return ((time % (that.progress_bar_duration)) / that.progress_bar_duration) * 100;
}


/** @brief Formats time
 *
 * A function that formats time
 *
 * @param seconds
 *
 * @return time
 *
 * Time gets returned in mm:ss format
 *
 * .............................................................................
 */
var format_time = function (seconds) {
	var seconds = Math.round(seconds);
	var minutes = Math.floor(seconds / 60);
	// Remaining seconds
	seconds = Math.floor(seconds % 60);
	// Add leading Zeros
	minutes = (minutes >= 10) ? minutes : "0" + minutes;
	seconds = (seconds >= 10) ? seconds : "0" + seconds;
	return minutes + ":" + seconds;
}


Player.prototype.logger = function(logTxt, logLevel) {

	console.log(new Date() + ': ' + logTxt);
	console.trace();
	if(false)
	{
		var http = new XMLHttpRequest();
		http.open('GET', 'http://localhost/wvsnp/wvsnp_logger/index.php?logtxt=' + logTxt, false);
		http.send();
	}
}
