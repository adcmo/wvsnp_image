
/** @brief Starts the loading animation and sets its properties.
 * 
 * A function that sets the custom options for the loading animation. This
 * information is passed to the loading_animation.js file. Also sets the properties
 * of the animation for normal or full screen by calling additional functions. 
 * 
 * .............................................................................
 */
Player_UI.prototype.loadingAnimation = function (that) {
	that.logger("loading aminatiom");
	that.ui.cl.setColor('#fffcff'); // default is '#000000'
	that.ui.cl.setDiameter(65); // default is 40
	that.ui.cl.setDensity(12); // default is 40
	that.ui.cl.setRange(1); // default is 1.3
	that.ui.cl.setSpeed(.6); // default is 2
	that.ui.cl.setFPS(14); // default is 24
	that.ui.cl.show(); // Hidden by default 
	that.buffering.segment_can_play = false; // Set the properties of the animation for normal or full screen
	//! if viewing mode is normal then call loading_animation_normal_settings()
	if (!that.ui.is_fullscreen) {
		that.ui.loadingAnimationNormalSettings(that);
	} else { //! else if viewing mode is fullscreen then call loading_animation_fullscreen_settings()
		that.ui.loadingAnimationFullscreenSettings(that);
	}

}

/** @brief Sets the loading animation custom options for normal viewing mode.
 * 
 * A function that sets the loading animation custom options for normal viewing mode.
 * 
 * .............................................................................
 */
Player_UI.prototype.loadingAnimationNormalSettings = function (that) {
	var loaderObj = document.getElementById("canvasLoader_" + that.video_id);
	loaderObj.style.backgroundColor = "#000000";
	loaderObj.style.width = (that.ui.w / 2 + 32.5) + "px";
	loaderObj.style.height = (that.ui.h / 2 + 32.5) + "px";
	loaderObj.style.position = "absolute";
	loaderObj.style.paddingLeft = (that.ui.w / 2 - 32.5) + "px";
	loaderObj.style.paddingTop = (that.ui.h / 2 - 32.5) + "px";
	loaderObj.style["top"] = "0px";
	loaderObj.style["left"] = "0px";

}

/** @brief Sets the loading animation custom options for full screen viewing mode.
 * 
 * A function that sets the loading animation custom options for full screen viewing mode.
 * 
 * .............................................................................
 */
Player_UI.prototype.loadingAnimationFullscreenSettings = function (that) {
	var loaderObj = document.getElementById("canvasLoader_" + that.video_id);
	loaderObj.style.backgroundColor = "#000000";
	loaderObj.style.width = "100%";
	loaderObj.style.height = "100%";
	loaderObj.style.position = "absolute";
	loaderObj.style.paddingLeft = (screen.width / 2 - 32.5) + "px";
	loaderObj.style.paddingTop = (screen.height / 2 - 32.5) + "px";
	loaderObj.style["top"] = "0px";
	loaderObj.style["left"] = "0px";
}


/** @brief Ends the loading animation
 * 
 * A function that calls functions in the loading_animation.js
 * file for the cl (canvas loader) object.
 * 
 *..............................................................................
 */
Player_UI.prototype.endLoadingAnimation = function (that) {
	that.logger("end animation")
	that.ui.cl.hide();
	that.buffering.segment_can_play = true;
}