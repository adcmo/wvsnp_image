/** @file 26-video_player.cpp
 *  @brief A video player that plays segmented videos continuously and seamlessly
 * 
 * Copyright 2012 Adolph Seema, Inc. All Rights Reserved.
 *
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 * http://www.opensource.org/licenses/gpl-license.html
 * and
 * http://www.gnu.org/copyleft/gpl.html
 * 
 * This has been inspired by Adolph Seema using his "crude video player" as a 
 * starting point, which can be found at:
 * http://dl.dropbox.com/u/41221188/html5_ajax_test.html
 * 
 * Copious resources for XHR2 and File System API and File API were used, most 
 * helpful were HLML5Rocks:
 * http://www.html5rocks.com/en/tutorials/file/xhr2/
 *  , http://www.html5rocks.com/en/tutorials/file/dndfiles/
 * and 
 * http://www.html5rocks.com/en/tutorials/file/filesystem/
 * 
 * Research for implementing the canvas element was:
 * http://html5doctor.com/video-canvas-magic/ 
 * and
 * http://answers.oreilly.com/topic/2896-how-to-display-a-video-on-html5-canvas/ 
 * 
 * Description: This is an HTML5 video player that plays segmented videos 
 * seamlessly. It utilizes the File System API to save the segmented video in a 
 * temporary local directory. This "sandbox" acts as a buffer for the segments. 
 * To play the segments seamlessly, this video player utilizes two video elements
 * and a canvas element. The two video elements are hidden and loaded with video 
 * segments. The video elements are rendered to the canvas. When one video ends 
 * the next video element is immediately rendered to the canvas.  * 
 * 
 */
//reference to the ff_rw type functions
document.write('<script type="text/javascript" language="javascript" src="26-video_ff_rw.js"></script>');
//reference to the control type functions
document.write('<script type="text/javascript" language="javascript" src="26-video_controls.js"></script>');

window.URL = window.URL || window.webkitURL;  // Take care of vendor prefixes.
window.requestFileSystem = window.requestFileSystem || 
                           window.webkitRequestFileSystem;

/** @brief Listener that calls its anonymous function once the window is loaded
 * 
 * A function that is called when the window is loaded. This is
 * necessary to get the elements on the page, after the page is loaded.
 * Global variables are filled with elements from the document
 * 
 * .............................................................................
 */

window.addEventListener('load',function(){
  var HTML5_video = document.getElementById("HTML5_video");
  var HLS_video = document.getElementById("HLS");
  var DASH_video = document.getElementById("DASH");
  var video_tags_HTML5 = document.querySelectorAll('video.wvsnp_player');
  var video_tags_HLS = document.querySelectorAll('video.wvsnp_player_HLS');
  var video_tags_DASH = document.querySelectorAll('video.wvsnp_player_DASH');
  var video_objects = [];
  
  var video_src_strings = document.querySelectorAll('.wvsnp_src');
  var video_src_strings_HLS = document.querySelectorAll('.wvsnp_src_HLS');
  var video_src_strings_DASH = document.querySelectorAll('.wvsnp_src_DASH');
    
  setTimeout(function(){ 
    //console.log("video_tags.length = " + video_tags_HTML5.length);
    for(v = 0; v < video_tags_HTML5.length; v++){
      video_objects.push(new Player(v, video_tags_HTML5[v], video_src_strings[v].src));
    }
  },300); 
  
  setTimeout(function(){ 
    //console.log("video_tags.length = " + video_tags_HLS.length);
    
    for(v = 0; v < video_tags_HLS.length; v++){
      alert("HLS is not yet supported");
 //     video_objects.push(new Player(v, video_tags_HTML5[v]));
    }
  },300); 
  
  setTimeout(function(){ 
    //console.log("video_tags.length = " + video_tags_DASH.length);
   
    for(v = 0; v < video_tags_DASH.length; v++){
       alert("DASH is not yet supported");
//      video_objects.push(new Player(v, video_tags_HTML5[v]));
  } 
  },300); 

 
},false);

 

function Player(v_id, v_el, v_src){

  this.base64images = {
  fullscreen_control: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB90DAhMdMT8PZgUAAAE4SURBVDjLjZRNjsIwDIWfUxbcrhILVIlK3IkTsuQELN83i7FnQlpmiBS1cZzn51/xulxf21fbk3LZnlLmQRcA9ULb2H4CcwGkjjrA2fbzF+/7rXbY3LpH6gG7/9vISiNF4A4sQBRAAQKRd/cxJMXomVbu6eLD9hk4dOwOwNn2ozN4y7cogzen8lKKttdiVWxSVoaWilkxuvbKaXUFjmOwgSOwpk5v5KpKcReHQylVfAawKJc72aQBRO/Svnfuv02SImID9Mn5Ze25Nqa+9uhayWxPLSJWSWqtKQFOki7AMSJUO++Pki6STkC01pQerVWQc1pbMrWb9NsOYM27B7Dkm3lTkLarYjcFmdk8A1VnuwX5Z4tUkJPV0nXAz6j4uGmHBt5t2nG2bMbIADKXO+/GyL+DDXg72L4Avo8mJBxa108AAAAASUVORK5CYII=',
  fullscreen_exit_control: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAAAXNSR0IArs4c6QAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB90DAhMZK6YBWnsAAAGuSURBVDjL3ZUhbxtBFIS/OR+wVJT+gagkoMjMUkhJf0BUUBZkanCkrFIsBQTUIH/A1GVVSFlJSaQwo1K7P6JSpF7eFGRX2l7WrUv70N7uvHlvb3Z2sX1ke217ThG2p7bPGYTtc9vTwdzc9joijkhktt3b7hJgYntn+6pCeJXWJum7S7mOiHVr+1bSW2AEfLD9DJgBx8A9T+Pe9rGkT7ZXwAIY2X6QdEtR5Wfq1BGRhxeVDi8GGKfcDqABkHSdKhV5Zl+ktRKwSByPhOl/zDJej7GXUBIJkAvPImIC0CTFboAXGV/kthW+9ndukXJvImLa2j6R9LEiQAt8qRDmuX7Q9Rg44W8REdXxfxzl8Tlky0p+fblPFElfBwVeAa+HotgeA9/yJbCruMS2LysdX+7B7mxPG0l3wBmwTfKXDugru+qLo5KxW9tnku6y9TbAqjjYh1ovm2DVNM2mtF438LIO0KvELCKiy9abA8skQg+8B7Z/8nLeZsL2QCtpaXve2j4FRpIebL9rmuba9ufk73GFaAx8B95I2kTED0nLdCeeEhH//ARExJMnICLWEfH8F920gAbjRi4MAAAAAElFTkSuQmCC',
  pause_control:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGeYUxB9wAAACBjSFJNAAB6JQAAgIMAAPn/AACA6AAAUggAARVYAAA6lwAAF2/XWh+QAAACgklEQVR42lyR22pbRxSGv5nZZ21H2kqxIrdur+JQ0ppepPEjhIS0F3Gfpn2Y4pbSF+gDlARKIL02hIJTCsanOKmsw97aM7OmF5LlqAsGBr41//rXPyqEwOMnTz978PWDfRExCsVoNGoODn78dTIev7390SZ7e3t3H+49/LZpGq21Vm8vLiY//3Twy3Q6HUUAu7tfPvpuf/+HWV0rEUEk2Jcv/3jz56tXv03GV9y7t/PN/rNn34+urlQIgdba5sWL54fA7xrg7s7Obrfb65dlWRVFp9ocDDY//mR7F6BpagaDwVfdXtXf2Nioik6nunNnOBwOtz4HiBZNTTurZ9R1g/celMLa1rKsZj5v6w+4SMA661YC3nusdVjn8N4TOUeQcP0eEaFt7YprYyAs+FJAsNZinUWWdwk3At57rLM4Z/FeMMYgywEawIvHOodbHvlg+rWDBfNLLiumryc45/DOE4A4jtBK3TgQobUW5xxKKZIkQWu1voKXhbUoMvy/JpMpR3//Q9s0pGmK0nrFIgAFJHGMbVsu370nzeq1DMQL3jkkLPKZzWarNSMAbTTT6ZTziwuMiej3CyJz40QbTZalRMaQJDFlWWKWPAJoW8vVeEye52RpxkZZYsyNTRNp8izHx44sTdd4BGCMpuyUaA1ZltO9dWsti9jEdDoF4j15vuBrDsqyjHu9LlorOkXB7aoiidPoWqDI87jqdhEROkVBv+oRx7FZfeNfr18fpUni8jSVyBh5P/rXHh8fHwNorTk/PztKksRlWSJRZOTy8t389OT0FECFEFBKxdvbn36htYoXmbT25OTkEJgrpTDGpMOtrftaKQNKNU09Pzs7Owwh2P8GAAruVo9cZ9KlAAAAAElFTkSuQmCC',
  play_control:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACUklEQVR42mNkAAIOTk4mTU0tdXsHB5sF8+ct//D+/RcGIgEjiFBT1xDz8vJOjImNqezu6qpctXLFjP9AQLQBAUHBup6enmUe7h4x33/8YNixY/v27q7OnKdPntwjygBvX18tV1e3Umdnl4RPnz4BvcTB8Orlq/fTpk2p2Lxx4yyCBnj5+Gk5OTuVOjg4Jnz+/Inh9+8/QBlGBjZWVoajR45snzZlcs7Tp9hdAzbAw9tHy9HRsdTWxi7h0+fPDH/+/mH4/+8fAyMTEwM/Pz/Dl8+f38+YPrVi4/r1s7Ab4OWjZWdnV2ppbZ3w5QskAliYmRlYWFjAmJubm4GPl5dh794929paWkCuuY9igLuHl5aNrW2phZVVwq+fPxlYgU6HY6ABbOxsDBzs7AxioqIMHz58+BQcHOR/4fz5A3AD3KAG2DvYJ/z+BfQ/w3+4F9jYWBm4ODnBrhAVEWEAWRAQ4B9x6tSpDUCFPyEu8PTWsre3L7WysUn48P4DSDvYRm4uLgYeoEYBAX4GPj4+hj179lytqqosuHf37h6MQLS0tCo1MjZJ+P//HwMPUCPIRh4ebgYRYWGGjx8//u7o6JgKTKVN//79e48RiJ7evlrWNjaltra2CUxMjGBb+YE2gmIAZGt1VWXhnTt3duNPB05OpW5ubgnMQH+LiAgzfPr48U87xNZGdFuxJOUQHU9Pj/KAgIAYUPQBo+tqVSVuWzEMUFJWlgoODslKT0+v7uzsmDx37tz6f3//viekGW4ACLCzs3Pz8vLKvHnz5jaQ+48YzSAAAGPF5xGsLhIBAAAAAElFTkSuQmCC',
  }
  this.initalize_reader_running = false;
  //This is a base64 representation of the control images put into variables
  this.video_id = v_id; 
  this.video = v_el;
  this.video_src_string = v_src; 
  this.w = this.video.offsetWidth;
  console.log("video width = " + this.w);
  this.h = this.video.offsetHeight;
  console.log("video height = " + this.h);    
//  this.CANVAS_HEIGHT = this.video.offsetHeight;
//  this.CANVAS_WIDTH = this.video.offsetWidth;
 
  this.current_video_element; //!< Points to the current video element that is playing
  this.ff_time;
  this.draw_screen_running = false;
  this.start_count_running = false; //!< Determines if get_current_time is running
  this.initialized = false;
  this.is_fullscreen = false; //!< Determines if the view mode is in full screen or not
  this.rewind_fast_forward_in_progress = false; //!< Detect is rewind fast forward function is in progress
  this.segment_can_play = false; //!< Are there enough elements in the buffer to allow the video to play
  this.called_from_write_buffering_in_progress = false; //!< Determines is buffering is in progress. 
  this.start_end_of_segment_timer = false; //!< Determines if the end_of_segment_timer has been called
  this.control_hover = false;
  this.is_getting_future_segments = false;
  this.read_file = true;
  this.live = true;
  this.segment_transition = false; 
  this.live_buffer_timer_initalized = false;
  this.live_count_baseline;
  this.leave_live_time;
  this.reader_playback_extension="";//only used in live playback mode during vod
  this.play_episode= 1;
  this.live_episode=1;
  this.buffer_to_play;//used in initalize_reader to determine videos in local dir
  this.buffer_start_pos=0;
  
  this.writer_video_index = 0; //!< Index of videos that have been written to the local directory
  this.video_to_play_index= 0;//!< Keeps track of the index of the current video that is playing   
  this.reader_video_index = 0;//!< Index of next video to be read and played.  
  this.last_in_buffer = 0; //for the check to delete buffer function
  this.control_mouseover_count = 0;
  this.control_mouseout_count = 0;
  this.max_duration = 0; //!< Used in ff_rw function to determine if ff request is within bounds  
  this.repeat_server_check_count = 0;
  this.typ_duration = -1;
  this.current_time;
  this.play_back_option;
  this.v_container;
  this.first_index;
  this.last_index;
  this.v_dir;
  this.v_name
  this.buffered_file_duration=0;
  this.progress_bar_duration;
  this.repeat_local_check_count=0;
    //! Sets the canvas height and width
//  document.getElementById("my_canvas"+this.video_id).width = this.CANVAS_WIDTH;
//  document.getElementById("my_canvas"+this.video_id).height = this.CANVAS_HEIGHT;
  
  this.cl; //! Creates an object for the loading animation
  
  this.segment_end_time = new Array(); //!< Array for storing the duration of each segment
  
  this.parse_video_src(this.video_src_string);

}
  function get_video_to_play_index (){
    return this.video_to_play_index;
  };
    
  function set_video_to_play_index (val){
    this.video_to_play_index = val;
  };
  
  function get_reader_video_index (){
    return this.reader_video_index;
  };
    
  function set_reader_video_index (val){
    this.reader_video_index = val;
  };
  
  
  
  /** @brief Parses the video source parameters in the html file
 * 
 * A function that parses the video source parameters in the html file
 * and saves the parameters as global variables. The input is in the following
 * format: filename-[presentation_int_max-min]-<mode>-<episode_max_int>-<seg_index_int>.<ext> 
 * 
 * @param src_string - Source string to be parsed. 
 * 
 * src_string is called when the video player is initialized 
 * .............................................................................
 */ 
  function parse_video_src (src_string){
    //parse the extention
    this.v_container = src_string.substring(src_string.lastIndexOf('.')+1,src_string.length);
    //remove the extension and save a local var
    var remain = src_string.substring(0, src_string.lastIndexOf('.'));
    //parse the first index
    this.first_index = parseInt(remain.substring(remain.lastIndexOf('-')+1));
    //set the video to play index, which at the start, is the same as the first_index
    this.video_to_play_index = this.first_index;
    //console.log(this.first_index);
    var remain = remain.substring(0,remain.lastIndexOf('-'));
    //console.log(remain);
    var temp = remain.substring(remain.lastIndexOf('-')+1);
    //parse the episode max_int
    this.last_index = parseInt(temp);
    var remain = remain.substring(0,remain.lastIndexOf('-'));
    console.log(remain);
    //parse the mode
    this.play_back_option = remain.substring(remain.lastIndexOf('-')+1);
    //console.log(this.play_back_option);
    var remain = remain.substring(0,remain.lastIndexOf('-'));
    //parse the pres_int_min and save global var
    this.pres_int_min = parseInt(remain.substring(remain.lastIndexOf('-')+1));
    //parse the pres_int_min and save global var
    var remain = remain.substring(0,remain.lastIndexOf('-'));
    //parse the pres_int_man and save global var
    this.pres_int_max = parseInt(remain.substring(remain.lastIndexOf('-')+1));
    //parse the video name and save global var
    this.v_name = remain.substring(remain.lastIndexOf('/')+1,remain.lastIndexOf('-'));
    //parse the video directory and save global var
    this.v_dir = remain.substring(0,remain.lastIndexOf('/')+1);
    //call setup function
    this.setup();
  }

  /** @brief A function that creates the html template for each video object
 * 
 * 
 * 
 * .............................................................................
 */ 
  function setup (){
    var that = this;
    that.create_dir(that.video_id, that.play_back_option);
    if(that.play_back_option=="LIVE"){
      that.create_dir(that.video_id, "LIVE_vod");
    }
    var wrapper = document.createElement('div');
    var newAttr = document.createAttribute('class');
    newAttr.nodeValue = 'player_wrapper';
    wrapper.setAttributeNode(newAttr);
    
    var newAttr = document.createAttribute('id');
    newAttr.nodeValue = 'player_wrapper_'+that.video_id;
    wrapper.setAttributeNode(newAttr);

    var newAttr = document.createAttribute('id');
    newAttr.nodeValue = 'player_video_'+that.video_id;
    that.video.setAttributeNode(newAttr);
    that.video.removeAttribute('controls');
    
    that.template = '<canvas class="my_canvas" id="my_canvas_'+that.video_id+'"></canvas>'
    +'<video class="my_video" id="my_video1_'+that.video_id+'" hidden="true" ></video>'
    +'<video class="my_video" id="my_video2_'+that.video_id+'" hidden="true" ></video>'
    +'<video id="check_buffered_duration_'+that.video_id+'" hidden="true"></video>'
    +'<div class="video_controls" id="video_controls_'+that.video_id+'" >'
      +'<div class="play_div" id="play_div_'+that.video_id+'">'
        +'<button class="play_toggle" id="play_toggle_'+that.video_id+'" ><img class="play_toggle" id="play_toggle_img_'+that.video_id+'" /></button>'
      +'</div>'
      +'<div class="live_div" id="live_div_'+that.video_id+'">'
        +'<button class="live_toggle" id="live_toggle_'+that.video_id+'" >Live</button>'
      +'</div>'
      +'<div class="progress" id="progress_'+that.video_id+'" role="slider" aria-valuemin="0" aria-valuemax="0" aria-valuenow="0">'
        +'<div class="load_progress" id="load_progress_'+that.video_id+'"></div>'
        +'<div class="play_progress" id="play_progress_'+that.video_id+'"></div>'
        +'<span class="timebar_status" id="timebar_status_'+that.video_id+'"></span>'
      +'</div>'
      +'<div class="time" id="time_'+that.video_id+'" role="timer">'
        +'<span class="current_time" id="current_time_'+that.video_id+'">00:00</span> / '
        +'<span id="duration_'+that.video_id+'">00:00</span></div>'
      +'<div class="fullsccreen_div" id="fullscreen_div_'+that.video_id+'">'
        +'<button class="fullscreen_btn" id="fullscreen_btn_'+that.video_id+'" >'
          +'<img class="fullscreen_img" id="fullscreen_img_'+that.video_id+'">'
        +'</button>'
      +'</div>' 
    +'</div>';  
   wrapper.innerHTML = that.template;
   
   that.video.parentNode.replaceChild(wrapper,that.video);
//   document.getElementById('my_video1_'+that.video_id).appendChild(that.video);
   document.getElementById('player_wrapper_'+that.video_id).style.height = (that.h);
   console.log("that.h is " + (that.h));
   document.getElementById('player_wrapper_'+that.video_id).style.width = that.w+'px';
   document.getElementById("my_canvas_"+that.video_id).width = that.w;
   document.getElementById("my_canvas_"+that.video_id).height = (that.h);
   document.getElementById('video_controls_'+that.video_id).style.width = that.w;
   document.getElementById('video_controls_'+that.video_id).style.height = '30px';
   that.progress_w = (that.w - 38 - 38 - 95 - 45);
   document.getElementById('progress_'+that.video_id).style.width = that.progress_w+'px';
   //! Loads full screen image 
   document.getElementById("fullscreen_img_"+that.video_id).src= that.base64images.fullscreen_control;
   //! Loads the play image on play_toggle
   document.getElementById("play_toggle_img_"+that.video_id).src=that.base64images.play_control;
   document.getElementById("play_toggle_"+that.video_id).addEventListener('click', function(e){
     if(!that.initialized){
          that.init(that.first_index ,that);
          that.initialized = true;
     }
    }, true);  

  }
  
 /** @brief Creates a directory in the sandbox for the video object
 * 
 * A function that creates a directory in the sandbox for the video object. Its
 * name is based on the video_id and a_playback_option parameters that are 
 * passed to it. More speifically, the directory name will be 
 * [a_playback_option]_[video_id]
 * 
 * @param video_id - the unique id number denoted to each video object used to 
 * identify the directory.
 * 
 * @param a_play_back_option - playback mode or option used to name the directory
 * 
 * .............................................................................
 */ 
  function create_dir (video_id, a_play_back_option){
    var that = this
    window.requestFileSystem(window.TEMPORARY, 1024*1024, function(fs) {
      fs.root.getDirectory(a_play_back_option + "_" + video_id , {create: true}, function(dirEntry) {
        console.log("dir created " + a_play_back_option + "_" + video_id);
      }, error_handler);
    }, error_handler);
    
  }

  
  function init (start_index, that){
    
    that.writer_video_index = start_index;
    console.log("start index" + start_index);
    console.log("init called for v_id" + that.video_id);
    //Create wraper div and give class name  and dive id
    
    that.cl = new CanvasLoader('player_wrapper_'+that.video_id, undefined, that.video_id); //! Creates an object for the loading animation
    
    that.initEventListeners(); 
    that.loading_animation(); //! Starts the loading animation
    /*! Checks if file on server exists. If it does, it sets off 
    events to save to local storage and check buffer. */
    
    that.check_for_file(that.writer_video_index);
    console.log("writer video index " + start_index);
    
    if(that.play_back_option == 'LIVE'){
      that.live_button_toggle(that, "on", "#FFFF00");
    }
    
    that.initalize_reader(that, start_index, start_index, 3);

    //!Listens for the onclick event to play the video
//    document.getElementById("play_toggle_"+that.video_id).onclick (){
//      that.play_pause();    
//    };    
  }
  
  function initEventListeners (){   
    var that = this;
    document.getElementById("play_toggle_"+that.video_id).addEventListener('click', function(e){that.play_pause_button(that ,that.video_to_play_index);}, true);
    //!Listener for the rewind and fast forward function
    document.getElementById("play_progress_"+that.video_id).addEventListener('mouseup', function(e){
      console.log("rw ff clicked");
      if(that.segment_transition == false){
        that.rewind_fast_forward(e, that.writer_video_index, that);
      }
      else{
        setTimeout(function(){
          that.rewind_fast_forward(e, that.writer_video_index, that);
        },300);
      }
      
      }, false); 
    document.getElementById("load_progress_"+that.video_id).addEventListener('mouseup', function(e){
      console.log("rw ff clicked");
      if(that.segment_transition == false){
        that.rewind_fast_forward(e, that.writer_video_index, that);
      }
      else{
        setTimeout(function(){
          that.rewind_fast_forward(e, that.writer_video_index, that);
        },300);
      }
      }, false);  
    //!Listener for notice timecode on an mousemove event over the progress bar
    document.getElementById("timebar_status_"+that.video_id).parentNode.addEventListener('mousemove', function(e){that.notice_timecode(e, that)}, false);
    //!Listener that shows the full screen video controls on mouseover
    document.getElementById("video_controls_"+that.video_id).addEventListener('mouseover', function(e){that.mouseEnter(that.showPopup(that), that);}, true);
    //!Listener that which hides the full screen video controls on mouseout
    document.getElementById("video_controls_"+that.video_id).addEventListener('mouseout', function(e){that.mouseEnter(that.hidePopup(that), that);}, true);
  
  
    //!Listener for the full screen function
    document.getElementById('fullscreen_btn_'+that.video_id).addEventListener('click', function(e){that.fullscreen(that);}, false);
    //!Listener for the exit_function
    window.addEventListener('pagehide', that.exit_function, false);
    //!Listener to end the full screen mode
    window.addEventListener('webkitfullscreenchange',function(e){ console.log("webkitfullscreenchange called = " + document.webkitIsFullScreen); 
    if(document.webkitIsFullScreen == false && that.is_fullscreen == true){
      that.fullscreen(that);}
      }  , false);
    document.getElementById("live_toggle_"+that.video_id).addEventListener('click', function(e){ 
      var mod_play_index = that.get_video_to_play_index();
      var play_index = that.calc_real_to_play_i(that, mod_play_index);
     that.live_rewind_fast_forward(that, 9999999,0, 0, false, 0, mod_play_index, play_index);
     }, true);
    

      
      
  }
 
 /** @brief Checks if the requested file exists on the server.
 * 
 * A function that checks if the requested file exists on the server.
 * If is does then create_file_request is called and the file is saved to
 * the local directory. 
 * 
 * .............................................................................
 */ 
  function check_for_file (a_writer_video_index){
    //!Make XHR request for file
    var that = this;
//    var temp_i=a_writer_video_index%(that.last_index-that.first_index+1);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", this.v_dir + this.v_name + a_writer_video_index + "." + this.v_container, true);
    /*! If onreadystate change is 4 and 200 then call function create_file_request  */                     
    xhr.onreadystatechange (e) {
     if (this.readyState == 4 && this.status == 200){
//        console.log("file " + that.v_dir + that.v_name + a_writer_video_index + "." + that.v_container + " ready");
        that.create_file_request(a_writer_video_index);
        that.repeat_server_check_count = 0;       
     }     
     else if(this.readyState == 4 && this.status == 404){
        console.log("file does not exist " + xhr.status + "ready state " + xhr.readyState);
        that.repeat_server_check(a_writer_video_index)
     }
     };
      xhr.responseType = "arraybuffer";
      xhr.send();    
  }
  
  function repeat_server_check (a_writer_video_index){
    var that = this    
    if(that.repeat_server_check_count < 20){
      if(that.typ_duration ==-1){
        dur = 5000
      }
      else{
        var dur = that.typ_duration*500;
      }     
      setTimeout(function(){
        that.repeat_server_check_count++;
        console.log("repeat check called with delay " + that.typ_duration + " repeat check count = " + that.repeat_server_check_count);
        that.check_for_file(a_writer_video_index);
    },dur);
   }
   else{
     this.called_from_write_buffering_in_progress = false;
   }  
  }
  
  function live_button_toggle (that, state, color){
    var live_toggle = document.getElementById("live_toggle_"+that.video_id);
    if(state == "on"){
      live_toggle.style.color = color;
    }
    if(state == "off"){
      live_toggle.style.color = "#000000";
    }
  }
  
  function get_live_count_baseline (that){
    console.log("live time called");
    var d = new Date();
    that.live_count_baseline = d.getTime();
  }
  
  function get_live_time (that){
    var d = new Date();
    var time_diff = d.getTime();
    time_diff = (time_diff - that.live_count_baseline)/1000;
    //return time_diff + that.leave_live_time;
    return time_diff;
    
  }

  
   function file_copy (cwd, src, dest){
      cwd.getFile(src, {}, function(fileEntry) {
        cwd.getDirectory(dest, {}, function(dirEntry) {
          fileEntry.copyTo(dirEntry);
        }, error_handler);
      }, error_handler);    
    } 

  //function copies segment from live file to live_vod by calling file_copy function
   function copy_to_live_vod (that, src, dest){
    console.log("copy_to_live_vod called " + src); 
    window.requestFileSystem(window.TEMPORARY, 1024*1024, function(fs){that.file_copy(fs.root,src, dest);}, error_handler  );    
  
  }

  /** @brief Requests a temporary file and calls the nested XHR_file_writer function
   * 
   * A function to request, a temporary file to be stored on the client file system.  
   * Once requested, it calls the nested function XHR_file_writer.
   * 
   * .............................................................................
   */
  function create_file_request (a_writer_video_index) {
  	var that = this;
//  	console.log("file " + a_writer_video_index + " requested");
  	window.requestFileSystem(window.TEMPORARY, 1024*1024, XHR_file_writer);
  	/**@brief Makes a XMLHttpRequest and stores file locally
  	 * 
  	 * A nested function that makes a XMLHttpRequest (XHR). The XHR gets a video 
  	 * segment, which is then stored as the local file.
  	 * 
     * ...........................................................................
  	 */
  	function XHR_file_writer(fs){
  	  var bb;
  	  var temp_i =  a_writer_video_index%(that.last_index-that.first_index+1);
  	  //console.log(temp_i);
  	  var file_name = that.play_back_option + "_" + that.video_id + "/" + that.v_name + temp_i  +"." + that.v_container;
      fs.root.getFile(file_name, {create: true}, 
      function(fileEntry) {		
  			var xhr = new XMLHttpRequest();
  			xhr.open("POST",  that.v_dir + that.v_name + a_writer_video_index + "." + that.v_container, true);
  			xhr.setRequestHeader("pragma", "no-cache");                 
  	    /*! Set the responseType to arraybuffer. "blob" is an option too, rendering 
  	    BlobBuilder unnecessary, but the support for "blob" is not widespread */
        xhr.responseType = "blob";
        
        fileEntry.createWriter(function(fileWriter) {   
          fileWriter.onwriteend (e) {
             //console.log('Write completed for index ' + a_writer_video_index);

             that.can_play(a_writer_video_index);          
          };        
          fileWriter.onerror (e) {
            console.log('Write failed: ' + e.toString());
          };
  
          //! Create a new Blob and write it to log.txt.              
          xhr.onload (){      
              var blob = new Blob([this.response],{type:'video/'+that.v_container});
              fileWriter.write(blob);           
              setTimeout(function(){ 
                //copy live video to live_vod folder if 
                if(that.play_back_option == "LIVE"){// && that.live_episode == that.play_episode){            
                  var buffer_ep = Math.floor(a_writer_video_index/(that.last_index-that.first_index+1))+1;
                  console.log("writer_index = " + a_writer_video_index  + 'buffer_episode = '+ buffer_ep + ' play episode = ' + that.play_episode);
                  if(buffer_ep == that.play_episode){
                    console.log("copy to live_vod called from file_writer, index " + a_writer_video_index);
                     that.copy_to_live_vod(that, "/"+file_name, "LIVE_vod_"+ that.video_id + "/" );
                  }
                }
                document.getElementById("check_buffered_duration_"+that.video_id).addEventListener("loadend", that.get_duration(a_writer_video_index, that), false);
                window.URL.revokeObjectURL(document.getElementById("check_buffered_duration_"+that.video_id).src); // Clean up after yourself.             
              },200);
              document.getElementById("check_buffered_duration_"+that.video_id).src = window.URL.createObjectURL(blob);       
          }
  				
  					xhr.send(); 
      	});		
      	 
    	});
  	}//END of XHR_file_writer-----------------------------------------------------
  }//END of create_file_request----------------------------------------------------------



  
  /** @brief Checks how many video segments are in the buffer and calls for
   *    next the next segment if needed.
   * 
   * A function that checks how many segments are in the buffer that have 
   * not been played. If less than three segments are in the buffer 
   * create_file_request function is called to load segment into the buffer
   * 
   * ............................................................................
   */
  function check_buffer (a_writer_video_index){
    var a_play_index = this.get_video_to_play_index();
    //console.log("check buffer called, play_index is " + a_play_index);
    if(this.play_back_option =="LIVE"){
      if((a_writer_video_index) <= 2){
        this.check_for_file(a_writer_video_index);
        //console.log("buffer checked " + a_writer_video_index);  
      }
    }
    else{
      if((a_writer_video_index) <= this.last_index*this.live_episode){
        this.check_for_file(a_writer_video_index);
        //console.log("buffer checked " + (a_writer_video_index - a_play_index));  
      }
      else{
        console.log("buffer full" + (a_writer_video_index - a_play_index));  
        this.called_from_write_buffering_in_progress = false;
      }
    }
  }
  
  /** @brief Function that sets timers to delete segments from LIVE video 
   * directory and calls function to increment live_episode.
   * 
   * Timer based on setInterval and setTimeout function calls which 
   * deletes segments in the live folder and calls increment_live_episode
   * .............................................................................
   */
  function live_buffer_timer (){
    that = this;
    console.log("live_buffer timer called");
    //if duration is not set, then do nothing
    if(that.typ_duration ==-1){
    }
    else{
      //set local variable to the episode duration in milliseconds.
      var episode_dur = (that.typ_duration*1000) *(that.last_index - that.first_index + 1);
      console.log("live_buffer timer called with" + " segment duration = " + that.typ_duration 
      + " last index = " + that.last_index + " first index = " + that.first_index + " duration =" + episode_dur);
      window.setInterval(function() {
        that.check_for_file(that.writer_video_index);       
        var temp_i= that.last_in_buffer%(that.last_index-that.first_index+1);
        var file_name = that.play_back_option + "_" + that.video_id + "/" + that.v_name + temp_i + "." + that.v_container;
        console.log("delete file request called of index " + temp_i);          
        //that.delete_file_request(file_name);
        that.last_in_buffer++;
      },(that.typ_duration*1000));      
      window.setInterval(function(){
        that.increment_live_episode(that);
      },episode_dur);
    }     
  }


  /** @brief Function that increments the live_episode global variable.
   * 
   * A function that increments the live_episode global variable
   * .............................................................................
   */
   function increment_live_episode (that){
     that.live_episode++;
     console.log("increment_live_episode CALLED live_episode = " + that.live_episode); 
   }
   
  
    /** @brief Function that changes video reader directory.
   * 
   * Function that changes the global variable that references which directory 
   * will be utilized as the videos are loaded.
   * 
   * .............................................................................
   */
  function change_reader_directory (that, change_playback_type){
    if(change_playback_type == "VOD"){
      console.log("in change_reader_directory changing to vod");
      that.reader_playback_extension = "vod_";
    }
    else{
      console.log("in change_reader_directory changing to LIVE");
      that.reader_playback_extension = "";
    }
  }
 
  
  
  
  /** @brief Starts the loading animation and sets its properties.
   * 
   * A function that sets the custom options for the loading animation. This
   * information is passed to the loading_animation.js file. Also sets the properties
   * of the animation for normal or full screen by calling additional functions. 
   * 
   * .............................................................................
   */
  function loading_animation (){
    console.log("loading aminatiom");
    this.cl.setColor('#fffcff'); // default is '#000000'
    this.cl.setDiameter(65); // default is 40
    this.cl.setDensity(12); // default is 40
    this.cl.setRange(1); // default is 1.3
    this.cl.setSpeed(.6); // default is 2
    this.cl.setFPS(14); // default is 24
    this.cl.show(); // Hidden by default 
    
    this.segment_can_play = false;
    /*! Set the properties of the animation for normal or full screen*/
   //! if viewing mode is normal then call loading_animation_normal_settings()
    if(!this.is_fullscreen){
      this.loading_animation_normal_settings();
    }
    else{ //! else if viewing mode is fullscreen then call loading_animation_fullscreen_settings()
      this.loading_animation_fullscreen_settings();
    }
  
  }
  
  /** @brief Sets the loading animation custom options for normal viewing mode.
   * 
   * A function that sets the loading animation custom options for normal viewing mode.
   * 
   * .............................................................................
   */
  function loading_animation_normal_settings (){
    var loaderObj = document.getElementById("canvasLoader_"+this.video_id);
    loaderObj.style.backgroundColor = "#000000";
    loaderObj.style.width = (this.w/2+32.5)+"px";
    loaderObj.style.height = (this.h/2+32.5)+"px";
    loaderObj.style.position = "absolute";
    loaderObj.style.paddingLeft = (this.w/2-32.5)+"px";
    loaderObj.style.paddingTop = (this.h/2-32.5)+"px";
    loaderObj.style["top"] = "0px";
    loaderObj.style["left"] = "0px"; 
    
  }
  
  /** @brief Sets the loading animation custom options for full screen viewing mode.
   * 
   * A function that sets the loading animation custom options for full screen viewing mode.
   * 
   * .............................................................................
   */
  function loading_animation_fullscreen_settings (){
    var loaderObj = document.getElementById("canvasLoader_"+this.video_id);
    loaderObj.style.backgroundColor = "#000000";
    loaderObj.style.width = "100%";
    loaderObj.style.height = "100%";
    loaderObj.style.position = "absolute";
    loaderObj.style.paddingLeft = (screen.width/2 -32.5) +"px";
    loaderObj.style.paddingTop = (screen.height/2 -32.5) +"px";
    loaderObj.style["top"] = "0px";
    loaderObj.style["left"] = "0px";  
  }
  
  
  /** @brief Ends the loading animation
   * 
   * A function that calls functions in the loading_animation.js
   * file for the cl (canvas loader) object.
   * 
   *..............................................................................
   */
  function end_loading_animation (){
    console.log("end animation")
    this.cl.hide();
  this.segment_can_play = true;
  }
  
  
  /** @brief Detects if the minimum required segments exist in the buffer. 
   * 
   * A function that detects if at least three segments are in buffer. If there
   * are, then segment_can_play and the end_loading_animation is called. 
   *  
   *..............................................................................
   */
  function can_play (a_writer_video_index){
    var play_index = this.get_video_to_play_index();
  
  //  console.log("can play index " + writer_video_index);
  /*! If the buffer has 3 or more segments that have not been played then end the 
   * loading animation 
   */
    if(a_writer_video_index - play_index  >= 2 && this.segment_can_play == false){
      //console.log("can play");
      if(!this.rewind_fast_forward_in_progress){
            this.end_loading_animation();
      }
    }else{
      //console.log("can play else ");
      }
  }
  //helper function for initalize_reader with callback to initalize reader
  //that decrements buffer_to_play index if the file is found in the local 
  //directory.
  function check_local_dir (that, start_reader_i, play_i, buffer_to_play){
    window.requestFileSystem(window.TEMPORARY, 1024*1024,function(fs){
      var temp_i =  a_reader_video_index%(that.last_index-that.first_index+1);
      fs.root.getFile(that.play_back_option +  "_" + that.reader_playback_extension + that.video_id + "/"  + that.v_name + temp_i + "." + that.v_container, {}, 
        function(fileEntry) {      
          if(fileEntry.isFile === true){
            that.initalize_reader(that,++start_reader_i, play_i, --buffer_to_play);
            console.log("check local dir is true");
          }
       },function(){that.initalize_reader(that,++start_reader_i, play_i, buffer_to_play); console.log("check local dir is false");});  
    });
    
  
  }
  
  function initalize_reader (that, start_reader_i, play_i, buffer_to_play){
    var self = this;
    self.q_count=0;
    that.initalize_reader_running = true;
    document.getElementById("play_toggle_"+that.video_id).addEventListener('click', 
      function(e){clearInterval(self.q);
        that.initalize_reader_running = false;
      }, true);
    self.q = window.setInterval(function() {
      var current_writter_i = that.writer_video_index;
      console.log("interval triggered, start_reader_i = " + start_reader_i + " play_i " + play_i  + " buffer_to_play = " + buffer_to_play + " q_count + " + self.q_count); 
      self.q_count++;     
      if(current_writter_i > start_reader_i){
        //console.log("if called in interval 1");
        clearInterval(self.q);
        if(buffer_to_play > 1){
          console.log("calling readfile request from initalize_reader");
          that.read_file_request(start_reader_i);
          that.initalize_reader(that,++start_reader_i, play_i, --buffer_to_play);
 //         that.check_local_dir(that, start_reader_i, play_i, buffer_to_play);
          
        }
        else if(buffer_to_play == 1){
          that.video_to_play_index = play_i;
          console.log("play_pause button called from initalize_reader");
          that.play_pause_button(that,play_i);
          that.initalize_reader_running = false;
          if(that.play_back_option == "LIVE" && !that.live_buffer_timer_initalized){
            that.live_buffer_timer_initalized=true;
            that.get_live_count_baseline(that);
            that.live_buffer_timer();     
          }
        }
      }
      else if(self.q_count >= 50){
        clearInterval(self.q);
        that.end_loading_animation();
        alert("Segment " + start_reader_i + " was not found on the server, the player has stopped checking for the file");
      }
      
    },1000);  
  }
   
  
  /** @brief Requests a local file and loads it to a video element
   * 
   * A function that makes a request to access local file then calling 
   * nested function read_load_video()
   * 
   *..............................................................................
   */
  function read_file_request (a_reader_video_index){
   if(a_reader_video_index <= this.last_index && a_reader_video_index < this.writer_video_index ){
    var that = this;
    window.requestFileSystem(window.TEMPORARY, 1024*1024, function(e){that.read_load_video(e,that,a_reader_video_index);});
    /*
     * A function that reads video from local directory and loads it
     * to the browser.
     */

   }    
  }
  
   function read_load_video (fs,that,a_reader_video_index) {
      var videoArea;
      /*!Determine which video element to load based on the reader_video_index 
      global variable. An even numbered index will be loaded to my_video1 */
      if(a_reader_video_index%2==0){
        //console.log("reading reader_video_index " + a_reader_video_index);
        video_element_to_load = document.getElementById("my_video1_"+that.video_id);
      }
      else{
        video_element_to_load = document.getElementById("my_video2_"+that.video_id);
        //console.log("reading reader_video_index " + a_reader_video_index);
      }
      var temp_i =  a_reader_video_index%(that.last_index-that.first_index+1);
 
      console.log("reading file " + that.play_back_option  + "_" + that.reader_playback_extension + that.video_id + "/"  + that.v_name + temp_i +  "." + that.v_container);
      fs.root.getFile(that.play_back_option +  "_" + that.reader_playback_extension + that.video_id + "/"  + that.v_name + temp_i + "." + that.v_container, {}, 
      function(fileEntry) {      
        // Get a File object representing the file,
        // then use FileReader to read its contents.
        fileEntry.file(function(file) {
          var reader = new FileReader();
          reader.onloadend (e) {
            video_element_to_load.src = window.URL.createObjectURL(file);                       
            a_reader_video_index++;
            //console.log("reader_video_index has been incremented to " + a_reader_video_index);
            that.set_reader_video_index(a_reader_video_index);
          };
        reader.readAsDataURL(file);       
        }, error_handler);
      },function(){
         console.log("ERROR read file not found = " + that.read_file + " that.live = " + that.live);         
        } );    
  //    check_buffer();   
    }
    
 
  /** @brief Requests a file from the File System and deletes it.
   * 
   * A function that requests a file from the File System and deletes it.
   * 
   * .............................................................................
   */ 
  function delete_file_request (file_name){
    that = this;

    window.requestFileSystem(window.TEMPORARY, 1024*1024, function(fs) {
      fs.root.getFile(file_name, {create: false}, 
      function(fileEntry) {
        fileEntry.remove(function() {
          console.log('File ' + file_name +' removed.');
          
        }, error_handler);  
      }, error_handler);
    }, error_handler);
  }
  
  


  //Called when video is paused and states need to be updated when ff or rw
  function paused_stats_update(that){    
    var play_progress = document.getElementById("play_progress_"+that.video_id); //!< A global variable for the play progress element in the video controls
    var current_time_element = document.getElementById("current_time_"+that.video_id); //!< A global variable for the current time element in the video controls
    var current_video_element = that.set_current_video_element(that.get_video_to_play_index());
    setTimeout(function() {
//      console.log("video element to play = " + that.get_video_to_play_index());
        current_time = that.segment_end_time[that.get_video_to_play_index()]- current_video_element.duration + current_video_element.currentTime;
        var timePercent = (current_time/that.progress_bar_duration)*100;
        play_progress.style.width = timePercent + "%";
//        console.log("current_video_element is " + 
//                    current_video_element.currentTime);
        current_time_element.firstChild.nodeValue = 
           format_time(current_time);    
    },100);  
    //update screen
    setTimeout(function(){
       var context = document.getElementById("my_canvas_"+that.video_id).getContext("2d");
       context.drawImage(current_video_element,0,0,that.w,that.h);  
       that.rewind_fast_forward_in_progress=false;   
      },100); 
    
  }



  /** @brief Plays or pauses the video and calls play_functions
   * 
   * A function that plays or pauses the video. If the video 
   * is played then play_functions are called that initialize 
   * controls and timer events.
   * 
   * .............................................................................
   */
  function play_pause_button (that, a_video_to_play){
//    console.log("play_pause_button called");
    var current_video_element = that.set_current_video_element(a_video_to_play);  
      var temp = that.last_index;
      if(a_video_to_play > temp){
        that.reset_player(that.play_back_option, that);        
        }
      else{
//        console.log("play_pause called, " + "segment " + a_video_to_play + " playing" + " video element = " + that.video_id);
        if(current_video_element.paused == false) {
          current_video_element.pause();
          if(that.play_back_option == 'LIVE' && that.live == true){
            console.log("calling change reader directory");
            that.change_reader_directory(that, "VOD");
            //that.get_live_count_baseline(that);
            //console.log("live time is " + that.live_count_baseline);
            var a_current_time = that.segment_end_time[that.get_video_to_play_index()]- current_video_element.duration + current_video_element.currentTime; 
            that.leave_live_time = a_current_time;
            that.live_button_toggle(that,"off", "FFFF00");
            that.live=false; 
          }         
          document.getElementById("play_toggle_img_"+that.video_id).src = that.base64images.play_control;
        } 
        else {      
          current_video_element.play();  
          if(that.play_back_option == 'LIVE' && that.live == false){            
 //           that.leave_live_time = that.get_live_time(that);
            console.log("leave_live time = " + that.leave_live_time);
            //that.get_live_count_baseline(that);
          }
          document.getElementById("play_toggle_img_"+that.video_id).src = that.base64images.pause_control;
          current_video_element.addEventListener("Play",that.play_functions(that),false);
        }                        
    }   
  }//END of play_pause-----------------------------------------------------------
  
 //play/pause called by the segment end timer rather the play button
    function play_pause_timer (that, a_video_to_play){
      console.log("play_pause_timer called");
    var current_video_element = that.set_current_video_element(a_video_to_play);  
//    var play_index = that.get_video_to_play_index();
 
//    var playing_li = document.createElement("li");
//    playing_li.innerHTML = "segment " + a_video_to_play + " playing";
//    var playing = document.getElementById("playing");
//    playing.appendChild(playing_li);
//      console.log("a_video_to_play " +  a_video_to_play + " < " + "that.last_index " + that.last_index );
      var temp = that.last_index;
      if(a_video_to_play > temp){
        that.reset_player(that.play_back_option, that);        
        }
      else{
        //console.log("play_pause called, " + "segment " + a_video_to_play + " playing" + " video element = " + that.video_id);
        if(current_video_element.paused == false) {
          current_video_element.pause();                
        } 
        else{      
          current_video_element.play();           
          document.getElementById("play_toggle_img_"+that.video_id).src = that.base64images.pause_control;
          current_video_element.addEventListener("Play",that.play_functions(that),false);
        }                        
    }   
  }//END of play_pause-----------------------------------------------------------
  
  /** @brief Calls other functions that initialize controls and timer events
   * 
   * A function that that initialize controls and timer events. Checks to see
   * is some functions are already running. If they are running, then they 
   * are not called again.
   * 
   * .............................................................................
   */
  function play_functions (that){
    //console.log("play functions called");
    if(!that.draw_screen_running){
      that.draw_screen();
    }
    
    //console.log("called_from_write_buffering_in_progress = " + that.called_from_write_buffering_in_progress);
    if(!that.called_from_write_buffering_in_progress){
      that.check_buffer(that.writer_video_index);  
     }

    if(!that.start_count_running){that.get_current_time()};  
    //console.log("segment timer_is_running = " + that.start_end_of_segment_timer);
    if(!that.start_end_of_segment_timer){that.end_of_segment_timer();}

    
  //  if(!start_buffered_progress_bar){buffered_progress_bar();}
  }//END of play_functions-------------------------------------------------------
  
  
  /** @brief Sets the current_video_element to point to the video element 
   * that is currently playing
   * 
   * A function that sets the current_video_element to point to the video 
   * element that is currently playing. This global variable is used by
   * functions such as play_pause, draw_screen, rewind_fast_forward, and other  
   * control related functions.
   * 
   * .............................................................................
   */
  function set_current_video_element (a_play_index){ 
    if(a_play_index%2==0){
//      console.log("video_to_play_index " + a_play_index + ", current video element is my_video1 ");
      return document.getElementById("my_video1_"+this.video_id);    
    }
    else{
//      console.log("video_to_play_index " + a_play_index + ", current video element is my_video2 ");
      return document.getElementById("my_video2_"+this.video_id);      
    }
  }
  
  function calc_real_to_play_i (that,mod_play_i){
    return ((that.last_index - that.first_index + 1)*(that.play_episode-1)+mod_play_i);
  }

  /** @brief Listens for the end of each segment.
   * 
   * A function that listens for the end of the current segment that is playing.
   * At the end of the segment the video_to_play index is updated. Then play_pause
   * is called, which then plays the proper video element. 
   * 
   * .............................................................................
   */
  function end_of_segment_timer (){
    var that = this;
  //  console.log("end of segment timer called");
    var handler;
    that.start_end_of_segment_timer=true;
    var video_element1 = document.getElementById("my_video1_"+that.video_id);
    var video_element2 = document.getElementById("my_video2_"+that.video_id);       

    video_element1.addEventListener("timeupdate", function() {
      that.segment_transition = true;  
//      console.log("listener test 1");
//      console.log("that.video_to_play_index " + that.video_to_play_index + " that.writer_video_index " + that.writer_video_index );
//      console.log("read_file = " + that.read_file);
      if(video_element1.ended){
        console.log("video_element1 ended");
        /* At the end of the episode call reset_player function. Reset_plaer 
         * function determins current state (eg vod, live etc) */
        if(that.last_index == that.video_to_play_index ){
          console.log("that.last_index == that.video_to_play_index");
          var play_index = that.get_video_to_play_index();
          var real_play_index= that.calc_real_to_play_i(that, that.video_to_play_index); 
          if (real_play_index < (that.writer_video_index-1) && !that.rewind_fast_forward_in_progress){
            that.reset_player(that.play_back_option, that);
            that.segment_transition = false;
          }
          else if(real_play_index == (that.writer_video_index-1) && !that.rewind_fast_forward_in_progress ){
            console.log("real_play_index == (that.writer_video_index-1)"); 
            video_element2.currentTime = (video_element2.duration-.2);
            if(that.play_back_option == 'LIVE' && that.initalize_reader_running == false){
              that.initalize_reader(that, (real_play_index+1), (real_play_index+1), 3);
            }  
            else if(that.play_back_option == "VOD" || that.play_back_option == "LOOP" ) {
              that.reset_player(that.play_back_option, that);
              that.segment_transition = false;
            }         
            document.getElementById("play_toggle_img_"+that.video_id).src = that.base64images.play_control;
    //        that.start_end_of_segment_timer=false;
            that.segment_transition = false;
            if(that.play_back_option == 'LIVE' && that.live == true){
                that.live_button_toggle(that,"off", "FFFF00");
                that.live=false; 
            }
          }
        }
        else if(that.video_to_play_index < that.last_index){
          //console.log("that.video_to_play_index < that.last_index");
          var real_play_index= that.calc_real_to_play_i(that, that.video_to_play_index); 
          //console.log("real_play_index = "+ real_play_index); 
          if (real_play_index < (that.writer_video_index-1) && !that.rewind_fast_forward_in_progress) { 
            var play_index = that.get_video_to_play_index();
            //console.log("real_play_index < (that.writer_video_index-1) " + real_play_index +"<"+ (that.writer_video_index-1));  
            play_index++;   
            that.set_video_to_play_index(play_index); 
            that.play_pause_timer(that, play_index);
            
            setTimeout(function(){ 
              if(!that.rewind_fast_forward_in_progress){
    //            console.log("end of segment timer loading next video element ");           
                that.read_file_request(that.get_reader_video_index());
                that.segment_transition = false; 
              }
            },100);     
          }
          else if(real_play_index == (that.writer_video_index-1) && !that.rewind_fast_forward_in_progress ){
            console.log("real_play_index == (that.writer_video_index-1)");
            video_element1.currentTime = (video_element1.duration-.2);
            if(that.initalize_reader_running == false){
              that.initalize_reader(that, (real_play_index+1), (real_play_index+1), 3);
            }            
            document.getElementById("play_toggle_img_"+that.video_id).src = that.base64images.play_control;
    //        that.start_end_of_segment_timer=false;
            that.segment_transition = false;
            if(that.play_back_option == 'LIVE' && that.live == true){
                that.live_button_toggle(that,"off", "FFFF00");
                that.live=false; 
            }   
          }
        }        
      }      
    }, false);//end of video_element1 event listener
  
    video_element2.addEventListener("timeupdate", function() {  
      that.segment_transition = true; 
//      console.log("listener test 2");
//      console.log("that.video_to_play_index " + that.video_to_play_index + " that.writer_video_index " + that.writer_video_index );
      if(video_element2.ended){
        console.log("video_element2 ended");
        /* At the end of the episode call reset_player function. Reset_plaer 
         * function determins current state (eg vod, live etc) */
        if(that.last_index == that.video_to_play_index ){
          console.log("that.last_index == that.video_to_play_index");
          var play_index = that.get_video_to_play_index();
          var real_play_index= that.calc_real_to_play_i(that, that.video_to_play_index); 
          if (real_play_index < (that.writer_video_index-1) && !that.rewind_fast_forward_in_progress){
            that.reset_player(that.play_back_option, that);
            that.segment_transition = false;
          }
          else if(real_play_index == (that.writer_video_index-1) && !that.rewind_fast_forward_in_progress ){
             console.log("real_play_index == (that.writer_video_index-1)"); 
            video_element2.currentTime = (video_element2.duration-.2);
            if(that.play_back_option == 'LIVE' && that.initalize_reader_running == false){
              that.initalize_reader(that, (real_play_index+1), (real_play_index+1), 3);
            }  
            else if(that.play_back_option == "VOD" || that.play_back_option == "LOOP" ) {
              that.reset_player(that.play_back_option, that);
              that.segment_transition = false;
            }               
            document.getElementById("play_toggle_img_"+that.video_id).src = that.base64images.play_control;
    //        that.start_end_of_segment_timer=false;
            that.segment_transition = false;
            if(that.play_back_option == 'LIVE' && that.live == true){
                that.live_button_toggle(that,"off", "FFFF00");
                that.live=false; 
            }
          }
          
        }
        else if(that.video_to_play_index < that.last_index){
          console.log("that.video_to_play_index < that.last_index");
          var real_play_index= that.calc_real_to_play_i(that, that.video_to_play_index); 
          console.log("real_play_index = "+ real_play_index); 
          if (real_play_index < (that.writer_video_index-1) && !that.rewind_fast_forward_in_progress) { 
            var play_index = that.get_video_to_play_index();
            console.log("real_play_index < (that.writer_video_index-1) " + real_play_index +"<"+ (that.writer_video_index-1)); 
            play_index++;   
            that.set_video_to_play_index(play_index); 
            that.play_pause_timer(that, play_index);
            
            setTimeout(function(){ 
              if(!that.rewind_fast_forward_in_progress){
    //            console.log("end of segment timer loading next video element ");           
                that.read_file_request(that.get_reader_video_index());
                that.segment_transition = false; 
              }
            },100);     
          }
          else if(real_play_index == (that.writer_video_index-1) && !that.rewind_fast_forward_in_progress ){
            console.log("real_play_index == (that.writer_video_index-1)"); 
            video_element2.currentTime = (video_element2.duration-.2);
            if(that.initalize_reader_running == false){
              that.initalize_reader(that, (real_play_index+1), (real_play_index+1), 3);
            }            
            document.getElementById("play_toggle_img_"+that.video_id).src = that.base64images.play_control;
    //        that.start_end_of_segment_timer=false;
            that.segment_transition = false;
            if(that.play_back_option == 'LIVE' && that.live == true){
                that.live_button_toggle(that,"off", "FFFF00");
                that.live=false; 
            }   
          }
        }        
      }      
    }, false);//end of video_element2 event listener
  }
  

  
  /** @brief Renders a frame from the current_video_element to the canvas.
   * 
   * A function that renders a frame from the current_video_element to the canvas.
   * It calls its self every 33ms. The is approximately 30 frames per second.
   * 
   * .............................................................................
   */
  function draw_screen () {
    var that = this;    
    that.draw_screen_running = true;
    console.log("draw screen called ");
    var current_video_element;  
    var q = window.setInterval(function(){ 
      var current_video_element = that.set_current_video_element(that.video_to_play_index); 
//      console.log("draw screen " + that.get_video_to_play_index());
      if(current_video_element.paused || 
         current_video_element.ended)        
         {

//           console.log("draw screen pause detected on segment " + that.video_to_play_index);
         }
      else{
        var context = document.getElementById("my_canvas_"+that.video_id).getContext("2d");
        context.drawImage(current_video_element,0,0,that.w,that.h);
//        console.log("draw screen play detected");
      }
    },42);
  }
  
   
  
  /** @brief Creates a full screen view of the video or reverts back to the 
   *    standard view.
   * 
   * A function that creates a full screen view of the video or reverts back to
   * the standard view.
   * 
   * .............................................................................
   */
  function fullscreen (that){
//    console.log("fullscreen called " + that.is_fullscreen);
    /*! Set up styles for fullscreen */
    var can_fullscreen = false; //!< Determines the browser has full screen capabilities
    var loaderObj = document.getElementById("canvasLoader_"+that.video_id);
    var wrapper = document.getElementById('player_wrapper_'+that.video_id);
    var video_controls = document.getElementById('video_controls_'+that.video_id);
    var canvas_element = document.getElementById("my_canvas_"+that.video_id);
    var progress = document.getElementById("progress_"+that.video_id);
    var time = document.getElementById("time_"+that.video_id);
    var play_div = document.getElementById("play_div_"+that.video_id);
    var live_div = document.getElementById("live_div_"+that.video_id);
    var fullscreen_div = document.getElementById("fullscreen_div_"+that.video_id);
    var vids = document.querySelectorAll('.player_wrapper');
    if(!that.is_fullscreen){
      /*! Check if browser has full screen request capability */
      if(document.documentElement.requestFullScreen){
        can_fullscreen = true;
        document.documentElement.requestFullScreen();
        console.log("fullscreen if called");
      }
      else if(document.documentElement.mozRequestFullScreen){
       can_fullscreen = true;
       document.documentElement.mozRequestFullScreen();
       //console.log("fullscreen moz called");
      }
      else if(document.documentElement.webkitRequestFullScreen){
       can_fullscreen = true;
       document.documentElement.webkitRequestFullScreen();  
       //console.log("fullscreen webkit called");
      }
      

      /*! If browser has full screen capabilities set it up */
      if(can_fullscreen){
        
        for(i = 0; i<vids.length; i++){
          vids[i].style.visibility = 'hidden';
        }          
        wrapper.style.visibility = 'visible';
        document.getElementById("fullscreen_img_"+that.video_id).src= that.base64images.fullscreen_exit_control;
        loaderObj.parentNode.insertBefore(loaderObj,canvas_element);
        //console.log("fullscreen sytles called");
        wrapper.style.position = 'fixed';
        wrapper.style.top = 0;
        wrapper.style.left = 0;
        wrapper.style.height = '100%';
        wrapper.style.width = '100%';
        wrapper.style.backgroundColor = '#000000';
        canvas_element.style.width = '100%';
        canvas_element.style.height = '100%';
           
        progress.style.width = "580px";               
        progress.style.marginTop = "12px";
                
        time.style.width = "110px";
        time.style.marginTop = "5px";
               
        play_div.style.width = "60px";
        play_div.style.marginTop = "5px";
        
        live_div.style.width = "50px";
        live_div.style.marginTop = "5px";
        
        video_controls.style.visibility = "block";
        video_controls.style.webkitBorderTopLeftRadius ="8px";
        video_controls.style.webkitBorderTopRightRadius ="8px";
        video_controls.style.height = '40px';
        video_controls.style.width = '850px';
        video_controls.style.position = 'absolute';
        video_controls.style.top = (screen.height - 160)+'px';
        video_controls.style.left = (screen.width/2 - 485)+'px';
        //console.log("screen width = " + screen.width);
//        video_controls.className = "video_controls_fullscreen";
        
        fullscreen_div.style.marginTop = "5px";
        
        setTimeout(function(){
          that.is_fullscreen= true;
        },1000);
        
        
  
      }
    }
    else{  /*! Return styles to normal viewing mode */
      //console.log("exit fullscreen called");
      if(document.cancelFullScreen){
        document.cancelFullScreen();  
      }
      else if(document.mozCancelFullScreen){
       document.mozCancelFullScreen();  
      }
      else if(document.webkitCancelFullScreen){
       document.webkitCancelFullScreen();
      }
        
      for(i = 0; i<vids.length; i++){
          vids[i].style.visibility = 'visible';
      } 
        document.getElementById("fullscreen_img_"+that.video_id).src= that.base64images.fullscreen_control;
        wrapper.style.position = 'relative';
        wrapper.style.top = "0px";
        wrapper.style.left = "10px";
   //     wrapper.style.height = '720px';
   //     wrapper.style.width = '100%';
        wrapper.style.backgroundColor = 'white';
        canvas_element.style.width = that.w + 'px';
        canvas_element.style.height = that.h + 'px';
        
        video_controls.style.visibility = "visible";
  
         video_controls.style.webkitBorderTopLeftRadius ="0px";
        video_controls.style.webkitBorderTopRightRadius ="0px";
        progress.style.width = (that.w - 38 - 38 - 95 - 45)+'px';
        progress.style.marginTop = "8px";
        
        time.style.width = "95px";
        time.style.marginTop = "0px";

        play_div.style.width = "37px";
        play_div.style.marginTop = "0px";
        
        live_div.style.width = "38px";
        live_div.style.marginTop = "0px";
        
        video_controls.style.position = 'relative';
        video_controls.style.top = '0px';
        video_controls.style.left = '0px';
        video_controls.style.display = 'block';
        video_controls.style.height = '30px';
        video_controls.style.width = that.w+'px';
        video_controls.className = "video_controls";

        fullscreen_div.style.marginTop = "0px";
                
        that.is_fullscreen= false;
        
    }
  }
 
  //Called whe a new episode is called to play. Deletes the segments in the 
  //LIVE_VOD folder and 
  function vod_dir_new_episode (that){
    console.log("vod_dir_new_episode called");
    if(that.live_episode == that.play_episode){
      //Deletes videos in LIVE_vod folder
      for(var i = that.first_index; i<=that.last_index;i++){
        var file_name = "LIVE_vod_" + that.video_id + "/" + that.v_name + i + "." + that.v_container;
        that.delete_file_request(file_name);        
      }
      for(var i = that.first_index; i<=that.first_index+2;i++){
        var file_name = that.play_back_option + "_" + that.video_id + "/" + that.v_name + i  +"." + that.v_container;
        that.copy_to_live_vod(that, "/" + file_name, "LIVE_vod_"+ that.video_id + "/" );
      }
      
    }
  }
  

  
  //called when in live_vod mode when the end of an vod episode has been reached
  //Dialog box give user the option to restart the current episode or go to live time.
  function end_of_episode_popup=function(){
    var x;
    var r=confirm("You have reached the end of the current episode. Press \"OK\""+
     "to restart the current episode over or \"Cancel\" to start live playback");
    if (r==true){
      that.loop();
      console.log("play episode =" + that.play_episode + " live episode = " + that.live_episode);
    }
    else{
      console.log("You pressed Cancel!");
      
      var live_time = that.get_live_time(that);
      console.log("cur_live_time = "+ live_time);
      var episode_duration = that.get_episode_dur(that);
      console.log("episode_duration = "+episode_duration);
      that.play_episode ++;
      console.log("play_episode incremented = "+ that.play_episode);
      var mod_rw_ff_time = that.get_mod_time(live_time,episode_duration);
      var ep_start_segment = that.segment_search(that, mod_rw_ff_time);
      that.calculate_buffer_status_bar(ep_start_segment,true);
      that.vod_dir_new_episode(that);
      var mod_play_index = that.get_video_to_play_index();
      var play_index = that.calc_real_to_play_i(that, mod_play_index);
      that.live_rewind_fast_forward(that, 9999999,0, 0, false, 0,mod_play_index, play_index);
      console.log("play episode =" + that.play_episode + " live episode = " + that.live_episode);
      //(that, rw_ff_time, mod_rw_ff_time ,find_segment, video_is_paused, a_current_time, mod_play_index, play_index)
    }
  }
  
  //Called at the end of the episode, to ready the player for 
  function reset_player (playback_option, that){
    //!< A local variable for the play progress element in the video controls
    var play_progress = document.getElementById("play_progress_"+that.video_id); 
    //!< A local variable for the current time element in the video controls
    var current_time_element = document.getElementById("current_time_"+that.video_id); 
    //get the video to play index*** first for VOD not for LIVE

    //console.log("video to play index " + that.video_to_play_index);
    
    if(that.play_back_option == 'VOD'){
      alert("The End");
      that.rw_ff_case4(true, that.first_index, 0 ,that);
      //that.read_file_request(that.first_index);
      that.video_to_play_index = that.first_index;
      that.reader_video_index = that.first_index;
      play_progress.style.width = 0 + "%";
//        console.log("current_video_element is " + 
//                    current_video_element.currentTime);
      current_time_element.firstChild.nodeValue = 
           format_time(0);      
    }
    else if(that.play_back_option == 'LOOP'){
      that.loop();    
    }
    else if(that.play_back_option == 'LIVE'){
      console.log("reset LIVE called");
      if(that.live){ 
        that.play_episode++;    
        console.log("play episode =" + that.play_episode + " live episode = " + that.live_episode);  
        that.calculate_buffer_status_bar(0,true);
        that.loop();
        that.vod_dir_new_episode(that);
      }// live stats is true then continue on
      else{
        that.end_of_episode_popup();
      }    
    }
//    that.draw_screen();
  }
  
  
  //called from reset function, for loop playback
  function loop (){
    that = this;
    that.video_to_play_index = that.first_index;
    that.reader_video_index = that.first_index;
    console.log("video to play index " + that.video_to_play_index);
    that.read_file_request(that.first_index);
    console.log("reset LOOP called");         
    setTimeout( function(){
      that.play_pause_timer(that, that.first_index);
      that.read_file_request(that.reader_video_index);
    },300);   
  }
  
  function exit_function (){
    console.log("on page hide called");
    for(var i = last_in_buffer; i < writer_video_index; i++){
      delete_file_request();
    }
  }
 
  error_handler (e) {
    var msg = '';
  
    switch (e.code) {
      case FileError.QUOTA_EXCEEDED_ERR:
        msg = 'QUOTA_EXCEEDED_ERR';
        break;
      case FileError.NOT_FOUND_ERR:
        msg = 'NOT_FOUND_ERR';
        break;
      case FileError.SECURITY_ERR:
        msg = 'SECURITY_ERR';
        break;
      case FileError.INVALID_MODIFICATION_ERR:
        msg = 'INVALID_MODIFICATION_ERR';
        break;
      case FileError.INVALID_STATE_ERR:
        msg = 'INVALID_STATE_ERR';
        break;
      default:
        msg = 'Unknown Error';
        break;
    };
  
    console.log('Error: ' + msg);
  }


//123456789012345678901234567890123456789012345678901234567890123456789012345678
