#include<stdio.h>
#include "cgic.h"	

int main() {

	FILE *fpointer;
	char name[50] = "Vidisha reddy Chirra";
	
	fpointer = fopen( "harsha.json", "w+b");
	
	if(fpointer == NULL) {
		printf("file cannot be opened\n");
	}
	else
		printf("file created successfully\n");

		fprintf(fpointer, name);

	fclose(fpointer);
	
	//getch();
	return 0;	

}
