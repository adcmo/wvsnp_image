#!/bin/bash
#
#   FILE: snapshot.sh
#   AUTHOR: Orlando Moreno
#   
#   DESCRIPTION:
#	This script will utilize ffmpeg to capture and segment a live video
#
#   PARAMETERS:
#	$1 The length of each segment
#	$2 The bitrate of the video
#	$3 The filename of the output video, which also includes the quality in the name
#	$4 Either LIVE or VOD
#	$5 The maximum number segments
#
#   LAST MODIFIED: 12/09/2014 [OM]

#gst-launch-0.10 v4l2src ! ffmpegcolorspace ! pngenc ! filesink location=$1$2.png

if [ $4  = "LIVE" ]; then
	ffmpeg -f v4l2 -i /dev/video0 -f segment -segment_time $1 -reset_timestamps 1 -s 640x360 -c:v libx264 -r 24 -g 24 -map 0 -b:v $2 -pix_fmt yuv420p /home/root/wvsnp_dashboard_v1.0.3/www/WVSNP_player/video.segments/live/$3-$4-$5-%0d.mp4 &
fi

if [ $4 = "VOD" ]; then
	cat "ffmpeg -i $6 -f segment -segment_time $1"
	ffmpeg -i $6 -f segment -segment_time $1 -reset_timestamps 1 -c:v copy -map 0 /home/root/wvsnp_dashboard_v1.0.3/www/WVSNP_player/video.segments/vod/$3-$4-$5-%0d.mp4 &
fi

