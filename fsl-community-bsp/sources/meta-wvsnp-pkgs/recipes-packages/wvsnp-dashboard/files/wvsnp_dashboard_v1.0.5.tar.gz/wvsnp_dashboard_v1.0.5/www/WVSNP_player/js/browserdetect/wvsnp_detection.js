var detectedOS = -1;
var detectedBrowser = -1;

var supports_media = function (mimetype, container) {

	if(mimetype == "mpeg-dash") {
		// as no browser directly supports MPEG-DASH at the moment, we use the external
		// player dash.js which uses Media Source Extensions. So check if this object
		// is supported here to see if mpeg-dash is supported
		// https://github.com/Dash-Industry-Forum/dash.js/
		if(window.WebKitMediaSource != null){
			window.MediaSource = window.WebKitMediaSource;
		}
		return (typeof(window.MediaSource) != "undefined");
	}
	else {
		var elem = document.createElement(container);
		if (typeof elem.canPlayType == "function") {
			var playable = elem.canPlayType(mimetype);
			if ((playable.toLowerCase() == 'maybe') || (playable.toLowerCase() == 'probably')) {
				return true;
			}
		}
		// if test for HLS, also check for the Apple-name 'vnd.apple.mpegURL'
		if(mimetype == 'application/x-mpegURL')
		{
			if (typeof elem.canPlayType == "function") {
				var playable = elem.canPlayType('vnd.apple.mpegURL');
				if ((playable.toLowerCase() == 'maybe') || (playable.toLowerCase() == 'probably')) {
					return true;
				}
			}
		}
	}
	return false;
};

Array.prototype.contains = function (obj) {
	var i = this.length;
	while (i--) {
		if (this[i] === obj) {
			return true;
		}
	}
	return false;
}

function browser_detection() {

	var $$ = PluginDetect, os = $$.OS;

	if ($$.browser.isChrome) {
		detectedBrowser = "Chrome";
	}
	if ($$.browser.isOpera) {
		detectedBrowser = "Opera";
	}
	if ($$.browser.isGecko) {
		detectedBrowser = "Firefox";
	}
	if ($$.browser.isIE && $$.browser.verIE >= 11) {
		detectedBrowser = "IE";
	}
	if($$.browser.isIE && $$.browser.isIEMobile && $$.browser.verIE > 10) {
		detectedBrowser = "IEmobile";
	}
	if($$.browser.isIE && !$$.browser.isIEMobile && $$.browser.verIE < 11) {
		detectedBrowser = "IEdeprecated";
	}

	if (os == 1) {
		detectedOS = "Windows";
	}
	if (os == 2) {
		detectedOS = "Mac OS";
		// NOTE: only set browser to Safari if it is on Mac OS (or iOS)
		// used for HLS support detection - the Windows Safari does not support HLS!
		if ($$.browser.isSafari)
			detectedBrowser = "Safari";
	}
	if (os == 3) {
		detectedOS = "Linux";
		var ua = navigator.userAgent.toLowerCase();
		var isAndroid = ua.indexOf("android") > -1; //&& ua.indexOf("mobile");
		if (isAndroid)
			detectedOS = "Android";
	}
	if (os == 21.1 || os == 21.2 || os == 21.3) {
		detectedOS = "iOS";
		detectedBrowser = "Safari";
	}
	
	if (detectedOS == -1) {
		detectedOS = "Other";
	}
	if (detectedBrowser == -1) {
		detectedBrowser = "Other";
	}
	
	/*
	console.log('PluginDetect.browser.isIE: ' + $.browser.isIE);
	console.log('PluginDetect.browser.ActiveXEnabled: ' + $.browser.ActiveXEnabled);
	console.log('PluginDetect.browser.ActiveXFilteringEnabled: ' + $.browser.ActiveXFilteringEnabled);
	console.log('PluginDetect.browser.verIE: ' + $.browser.verIE);
	console.log('PluginDetect.browser.verIEtrue: ' + $.browser.verIEtrue);
	console.log('PluginDetect.browser.docModeIE: ' + $.browser.docModeIE);
	console.log('');

	console.log('PluginDetect.browser.isGecko: ' + $.browser.isGecko);
	console.log('PluginDetect.browser.verGecko: ' + $.browser.verGecko);
	console.log('PluginDetect.browser.isSafari: ' + $.browser.isSafari);
	console.log('PluginDetect.browser.verSafari: ' + $.browser.verSafari);
	console.log('PluginDetect.browser.isChrome: ' + $.browser.isChrome);
	console.log('PluginDetect.browser.verChrome: ' + $.browser.verChrome);
	console.log('PluginDetect.browser.isOpera: ' + $.browser.isOpera);
	console.log('PluginDetect.browser.verOpera: ' + $.browser.verOpera);
	*/
}