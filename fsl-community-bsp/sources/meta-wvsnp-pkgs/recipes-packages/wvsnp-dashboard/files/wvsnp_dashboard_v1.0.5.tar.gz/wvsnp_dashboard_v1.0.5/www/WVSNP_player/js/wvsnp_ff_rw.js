/** @brief Rewinds or fast forwards the video
 *
 * FF or RW could occur within one segment. In this case no loading is required,
 * only timeUpdate is needed. If FF occurs in the next segment that is already
 * loaded, then no loading is required. Update the current_video_element to the
 * other video element and update the time. If FF ahead more than one segment or
 * RW to a prior segment, it is more complex. First, segment_end_time array is
 * to determine the correct segment to load. Finally, the segment is loaded along
 * with its predecessor. Once loading has occurred, play can be initiated.
 *
 * @param event
 *
 * The event that is called is the parameter
 *
 * .............................................................................
 */
Player.prototype.rewindFastForward = function (that, e, a_writer_video_index) {
	// Detect if rewind fast forward is in progress.
	// If it is we don't want to execute again. 
	// We must wait until loading is complete before we make another
	// rewind fast forward request.
	if (!that.buffering.rewindFastForward_in_progress) {

		// empty "videostarted" array
		that.videostarted = new Array();
		// empty "videoplaying" array
		that.videoplaying = new Array();

		that.buffering.rewindFastForward_in_progress = true;
		var video_is_paused;
		//get the current mod_play index
		var mod_play_index = that.getVideoToPlayIndex(that);
		var current_video_element = that.ui.getDesignatedVideoElement(that, mod_play_index);
		//get the current mod play time
		var mod_curr_time = that.segment_end_time[mod_play_index] - current_video_element.duration + current_video_element.currentTime;
		//get the druation of an episode, needed to calculate.
		var ep_dur = that.getEpisodeDuration(that);
		var back_time = (that.play_episode - 1) * ep_dur;

		//get the current play episode
		var play_ep = that.play_episode;
		//var play_ep = that.getPlayEpisode(that, mod_curr_time, ep_dur);
		that.logger("play_ep " + play_ep);

		//get the current segment play index
		var play_index = that.calcRealToPlayIndex(that, mod_play_index);
		that.logger("play_index " + play_index);

		//get the current time
		var a_current_time = that.segment_end_time[play_index] - current_video_element.duration + current_video_element.currentTime;
		that.logger("current_time " + a_current_time);

		//get the location of the mouse click on the play progress bar 
		var timebar = document.getElementById('progress_' + that.video_id);
		//! Get the time to RW or FF
		var pos = findPos(timebar);
		//  that.logger("pos y is" + pos.y + " pos x is " + pos.x + "pagex is " + e.pageX); 
		var diffx = e.pageX - pos.x;
		var mod_rw_ff_time = diffx / that.ui.progress_w * that.progress_bar_duration;
		that.logger("mod ff_rw_time" + mod_rw_ff_time);

		var add_remain_ep_time = ep_dur * (play_ep - 1);
		that.logger("added duration is " + add_remain_ep_time);

		var rw_ff_time = mod_rw_ff_time + add_remain_ep_time;
		var mod_find_segment = find_segment % (that.last_index - that.first_index + 1);
		
		// Case 1: If the desired segment does not currently exists in the buffer
		//  then make call to the rw_ff_case1s to fetch the segments required
		// to play the desired segment.
		var find_segment = that.segmentSearch(that, rw_ff_time);
		that.logger("FF time to: " + rw_ff_time + " - found segment: " + find_segment);

		// If video is paused, set variable accordingly. 
		// If video is not paused it needs to be paused to fast foward and/ or
		// rewind, which is taken care of in the else if statement. This is only done for
		// non-live mode.
		/*if (current_video_element.paused) {
			video_is_paused = true;
		} else if (that.play_back_option != 'LIVE' && rw_ff_time > a_current_time) {
			video_is_paused = false;
			current_video_element.pause();
			that.logger("segment not paused, now pausing segment");
		}*/
		current_video_element.pause();
		video_is_paused = true;
		
		// If playback mode is LIVE, then go to live_rewind_fast_forward function
		if (that.play_back_option == 'LIVE') {
			that.logger("calling live_rewind_fast_forward function");
			that.liveRewindFastForward(that, rw_ff_time, mod_rw_ff_time, find_segment, video_is_paused, a_current_time, mod_play_index, play_index);
		}
		// If playback mode is not LIVE (e.g. VOD or LOOP), then procede to additional cases.
		else {
		
			// Case 1: If rewinding or fast forwarding within current segment, there 
			// is no need to reload segment. Just update current time.
			// -----------------------------------------------------------------------
			if (play_index == find_segment && that.segment_transition == false) {
				that.logger("FF or RW inbetween current segment");
				that.rewindFastForwardCaseSameSegment(that, rw_ff_time, video_is_paused);
			}
			// Case 2: If rewinding or fast forwarding within current segment, there 
			// is no need to reload segment. Just update current time.
			// -----------------------------------------------------------------------
			else if (play_index + 1 == find_segment && that.segment_transition == false) {
				that.logger("case 3 detected");
				that.rewindFastForwardCaseNextSegment(that, video_is_paused, find_segment, rw_ff_time);
			}
			// Case 3: We do not make any other assumptions here, trigger re-buffering process
			// we skip to any arbitrarily point in time not fitting into case 1 or 2.
			// -----------------------------------------------------------------------
			else {
			
				that.rewindFastForwardCaseGeneral(that, video_is_paused, find_segment, rw_ff_time);
			}
		}
	}
}

Player.prototype.segmentSearch = function (that, rw_ff_time) {
	var find_segment = null;
	
	// heuristic to skip to nearby start-segment for search-start	
	for (var i = Math.floor(rw_ff_time / that.typ_duration) - 1; i < that.last_index && find_segment == null; i++) {
		// increment segment while desired time is lte than current segment-end-time
		if (rw_ff_time <= that.segment_end_time[i]) {
			find_segment = i;
			that.logger("rewind to segment " + find_segment + " time of " + rw_ff_time);
		}
	}
	return find_segment;
}

Player.prototype.rewindFastForwardCaseSameSegment = function (that, rw_ff_time, video_is_paused) {
	that.logger("RW FF case 'Same Segment' detected, rw_ff_time = " + rw_ff_time);
	var current_video_element = that.ui.getDesignatedVideoElement(that, that.getVideoToPlayIndex(that));
	rw_ff_time = rw_ff_time - (that.segment_end_time[that.getVideoToPlayIndex(that)] - current_video_element.duration);
	current_video_element.currentTime = rw_ff_time;
	if (video_is_paused == true) {
		current_video_element.play();
		/*setTimeout(function () {
			current_video_element.pause();
			that.pauseStatsUpdate(that);
		}, 33);*/
	} else {
		current_video_element.play();
	}
	that.buffering.rewindFastForward_in_progress = false;
}


Player.prototype.rewindFastForwardCaseNextSegment = function (that, video_is_paused, find_segment, rw_ff_time) {
	that.logger("RW FF case 'Next Segment' detected, find_segment = " + find_segment + " rw_ff_time = " + rw_ff_time);
	that.video_to_play_index = find_segment;
	var current_video_element = that.ui.getDesignatedVideoElement(that, find_segment);
	rw_ff_time = rw_ff_time - (that.segment_end_time[find_segment] - current_video_element.duration);
	if (video_is_paused == true) {
		current_video_element.currentTime = rw_ff_time;
		current_video_element.play();
		that.playFunctions(that);
		that.logger("calling readfile request from rw_ff case 'next segment'");
		that.readFileRequest(that, ++find_segment);
		/*setTimeout(function () {
			current_video_element.pause();
			that.pauseStatsUpdate(that);
		}, 33);*/
	} else {
		current_video_element.pause();
		current_video_element.currentTime = rw_ff_time;
		current_video_element.play();
		that.playFunctions(that);
		that.logger("calling readfile request from rw_ff case 'next segment'");
		that.readFileRequest(that, ++find_segment);
		that.buffering.rewindFastForward_in_progress = false;
	}
}

Player.prototype.rewindFastForwardCaseGeneral = function (that, video_is_paused, find_segment, rw_ff_time) {
	that.logger("RW FF case 'general segment' detected, find_segment = " + find_segment + " rw_ff_time = " + rw_ff_time);
	
	// NOTE: due to changes in with the FF process beyond the point of buffer, we cannot
	// "easily" determine which segments have been loaded already. So we start buffering
	// in every case, to be sure. As the loading-process improved and existing segments
	// on filesystem (if using filesystem-version) will not be loaded again, we
	// should not run into TOO much delay whatsoever.
	// maybe improve this in future work, by tracking each segment that has been downloaded
				
	var buffering_finished_callback = function () {
		// within the video-segment, set the desired time-spot (as accurately as we can determine it here)
		that.video_to_play_index = find_segment;
		var current_video_element = that.ui.getDesignatedVideoElement(that, find_segment);
		that.logger("rw_ff_time = " + rw_ff_time + " segment_end " + that.segment_end_time[find_segment] + " current duration " + current_video_element.duration + " find segment = " + find_segment);
		var relative_rw_ff_time = rw_ff_time - (that.segment_end_time[find_segment] - current_video_element.duration);
		current_video_element.currentTime = relative_rw_ff_time;
		that.ui.endLoadingAnimation(that);
		current_video_element.play();
		//that.playFunctions(that);
		that.logger("calling readfile request from rw_ff case 'general segment'");
		//that.readFileRequest(that, ++find_segment);
		//that.buffering.rewindFastForward_in_progress = false;
	};
				
	var buffering_progresses_callback = function () {
		that.buffering.initialiseReader(that, find_segment, find_segment, that.buffering.buffer_to_play, 500);
	};
				
	that.ui.loadingAnimation(that);
	that.writer_video_index = find_segment;
	that.video_to_play_index = find_segment;
	that.buffering.buffered_file_duration = that.segment_end_time[that.writer_video_index];
	that.max_duration = that.buffering.buffered_file_duration;
	that.currentSegmentLoaded = that.writer_video_index;
	that.calculateBufferStatusBar(that);
	that.pauseStatsUpdate(that);
	that.buffering.addBufferingFinishedObserver(that, buffering_finished_callback);
	that.buffering.addBufferingProgressesObserver(that, buffering_progresses_callback);
	// call check-buffer and hand over the callback to set the relative ff_rw_time inbetween the segment once buffering is finished
	that.buffering.checkBuffer(that, that.writer_video_index);
	that.buffering.rewindFastForward_in_progress = false;
}

Player.prototype.getPlayEpisode = function (that, time, episode_duration) {
	that.logger("time = " + time + "episode_duration " + episode_duration);
	return Math.ceil(time / episode_duration);
}

Player.prototype.getEpisodeDuration = function (that) {
	return that.typ_duration * (that.last_index - that.first_index + 1);
}

Player.prototype.getModTime = function (that, time, episode_duration) {
	return time % episode_duration;
}

Player.prototype.liveRewindFastForward = function (that, rw_ff_time, mod_rw_ff_time, find_segment, video_is_paused, a_current_time, mod_play_index, play_index) {
	that.logger("Live mode detected, current play index = " + play_index + " mod_play_index = " + mod_play_index);
	var current_video_element = that.ui.getDesignatedVideoElement(that, play_index);
	that.logger("live rewind called, current time = " + a_current_time + ", ff time = " + rw_ff_time + ", and live = " + that.live);
	var live_time = that.getLiveTime(that);

	// TODO: LIVE video rw and ff needs to be fixed
	that.logger('LIVE rw and ff is not possible right now. Needs fix in future');
	
	/*
	// Case 1: If video is not live
	// ----------------------------------------------
	if (that.live == false) {
		that.logger(" get live time is " + that.getLiveTime(that) + "live =" + that.live);

		// Case 1a: If user tries to fast forward past live time
		// ------------------------------------------------------
		if (rw_ff_time > live_time) {
			//        alert("I'm sorry, but you can'n fast forward past live time. Your are now playing live.");
			rw_ff_time = live_time;
			ep_dur = that.getEpisodeDuration(that);
			mod_rw_ff_time = that.getModTime(that, rw_ff_time, ep_dur);
			that.liveButtonToggle(that, "on", "#FFFF00");
			that.logger("calling change_reader_directory");
			that.changeReaderDirectory(that, "LIVE");
			that.live = true;
		}
		var episode_diff;
		//      var mod_rw_ff_time=0;
		var episode_duration = that.getEpisodeDuration(that);
		// User fast forwards past the current episode. This can happen if the
		// user presses the live button.
		// ----------------------------------------------
		//if(rw_ff_time > episode_duration) {
			// if the desired rw/ff time is larger than an episode duration,
			// then the modulus of that time is needed to determine the point to ff to.
			// determine and set new play_episode global variable
			//that.logger("rw_ff_time = " + rw_ff_time + " episode_duration = " + episode_duration);
			//that.play_episode = that.getPlayEpisode(that,rw_ff_time,episode_duration);
			//that.logger("desired play episode = " + that.play_episode);
			// Get the mod fw/ff time, by using the episode duration
			//mod_rw_ff_time = that.getModTime(that,rw_ff_time,episode_duration);
			//that.logger("mod rw_ff_time is " + mod_rw_ff_time);
		//}
		//else {
			//mod_rw_ff_time = rw_ff_time;
		//}
		var find_segment = that.segmentSearch(that, rw_ff_time);
		var mod_find_segment = find_segment % (that.last_index - that.first_index + 1);
		that.logger("mod_find_segment = " + mod_find_segment);

		var mod_live_time = live_time;
		if (live_time > episode_duration) {
			that.logger("The current live episode = " + that.live_episode);
			mod_live_time = live_time % episode_duration;
			that.logger("mod live_time is " + mod_live_time);
		}

		if (play_index == find_segment) {
			that.logger("case 2 detected");
			that.rewindFastForwardCase2(that, mod_rw_ff_time, video_is_paused);
			that.logger("rw_ff_time = " + rw_ff_time + " mod_rw_ff_time = " + mod_rw_ff_time + "live_time = " + live_time +
				" mod live_time is " + mod_live_time + " that.live_episode = " + that.live_episode + "that.play_episode = " + that.play_episode);
			if (rw_ff_time == live_time && that.live_episode == that.play_episode) {
				that.live = true;
				that.logger("live set to true");
			} else {
				that.live = false;
				that.logger("live set to false");
			}
		}
		// If fast forwarding to next segment that is already loaded
		// there is no need to load segments.
		// ------------------------------------------------------
		else if (play_index + 1 == find_segment) {
			that.logger("case 3 detected for live mode");
			that.rewindFastForwardCase3(that, video_is_paused, mod_find_segment, mod_rw_ff_time);
			that.logger("rw_ff_time" + rw_ff_time + " mod_rw_ff_time = " + mod_rw_ff_time + "live_time = " + live_time +
				"that.live_episode = " + that.live_episode + "that.play_episode = " + that.play_episode);
			if (rw_ff_time == live_time && that.live_episode == that.play_episode) {
				that.live = true;
				that.logger("live set to true");
			} else {
				that.live = false;
				that.logger("live set to false");
			}
		}
		// All other scenarios which RW or FF to other segements
		// which requires segments to be loaded.
		// ------------------------------------------------------
		else {
			that.rewindFastForwardCase4(that, video_is_paused, mod_find_segment, mod_rw_ff_time);
			that.logger("rw_ff_time  " + rw_ff_time + " mod_rw_ff_time = " + mod_rw_ff_time + "live_time = " + live_time +
				"that.live_episode = " + that.live_episode + " that.play_episode = " + that.play_episode);
			if (rw_ff_time == live_time && that.live_episode == that.play_episode) {
				that.live = true;
				that.logger("live set to true");
			} else {
				that.live = false;
				that.logger("live set to false");
			}
		}
		//      rw_ff_time= that.live_time(that);       
	}
	// If video is live
	// ------------------------------------------------------
	else if (that.live == true) {
		var mod_find_segment = find_segment % (that.last_index - that.first_index + 1);
		if (rw_ff_time > a_current_time) {
			that.logger("I'm sorry, but you can'n fast forward past live time");
			that.liveIndicatorFlash(that, 9, "off")
			that.buffering.rewindFastForward_in_progress = false;
		} else if (rw_ff_time < a_current_time) {
			//that.getLiveCountBaseline(that);//gives time stamp for at point live time was left
			that.logger("live time is " + live_time);
			//that.leave_live_time = a_current_time;
			that.live = false;
			that.logger("live time changed to = false");
			that.logger("calling change_reader_directory");
			that.changeReaderDirectory(that, "VOD");
			that.liveButtonToggle(that, "off", "#FFFF00");
			if (play_index == find_segment) {
				that.logger("case 2 detected");
				that.rewindFastForwardCase2(that, mod_rw_ff_time, video_is_paused);
			}
			// Case 3: If fast forwarding to next segment that is already loaded
			// there is no need to load segments.
			// ------------------------------------------------------
			else if (play_index + 1 == find_segment) {
				that.logger("case 3 detected");
				that.rewindFastForwardCase3(that, video_is_paused, mod_find_segment, mod_rw_ff_time);
			}
			// Case 4: All other scenarios which RW or FF to other segements
			// which requires segments to be loaded.
			// ------------------------------------------------------
			else {
				that.logger("case 4 detected");
				that.rewindFastForwardCase4(that, video_is_paused, mod_find_segment, mod_rw_ff_time);
			}
		}
	} else {
		that.logger("not detected case in live rw ff");
		that.buffering.rewindFastForward_in_progress = false;
	}
	*/
}

Player.prototype.liveIndicatorFlash = function (that, flash_remaining, position) {
	//  that.logger("live flash called");
	var live_toggle = document.getElementById("live_toggle_" + that.video_id);
	if (flash_remaining >= 1) {
		that.liveButtonToggle(that, position, "#FF0000");
		if (position == "on") {
			position = "off";
		} else {
			position = "on";
		}
		setTimeout(function () {
			that.liveIndicatorFlash(that, --flash_remaining, position);
		}, 200);
	} else if (flash_remaining == 0) {
		that.liveButtonToggle(that, position, "#FFFF00");
	}
}