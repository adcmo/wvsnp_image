/*
 * NOT MAINTAINED RIGHT NOW! OUTDATED, WILL PROBABLY NOT WORK!
 *
 * TODO: NEEDS RETOUCHING!
 */

console.log('using blob to download videos');

Player.prototype.loadVideoBLOB = function(that, video_element, a_writer_video_index) {
	var xhr = new XMLHttpRequest();
	xhr.open("POST", that.getRemoteFileName(that, a_writer_video_index), true);
	xhr.setRequestHeader("pragma", "no-cache");
	
	xhr.responseType = (that.use_no_fs_blob) ? "blob" : "arraybuffer";
	xhr.onload = function () {
		
		var blob = null;
		if(that.use_no_fs_blob)
		{
			blob = new Blob([this.response], {type: 'video/' + that.v_container});
		}
		else
		{
			var BlobBuilder = window.WebKitBlobBuilder || window.MozBlobBuilder;
			var bb = new BlobBuilder();
			bb.append([this.response]);
			blob = bb.getBlob('video/' + that.v_container);
		}

		video_element.src = window.URL.createObjectURL(blob);
		setTimeout(function() {
			that.startPlayingAndWaitForVideo(that, video_element, function () {
			that.tempVideoLoaded(that, a_writer_video_index);
			});
		}, 200);
		// TODO: put this inside "delete_file_request" !
		//window.URL.revokeObjectURL(video_element.src); // Clean up after yourself.
	};
	xhr.send();
}

Player.prototype.deleteFileRequestBLOB = function(that, video_index) {
	window.URL.revokeObjectURL(that.ui.getDesignatedVideoElement(that, video_index).src); // Clean up after yourself.
}