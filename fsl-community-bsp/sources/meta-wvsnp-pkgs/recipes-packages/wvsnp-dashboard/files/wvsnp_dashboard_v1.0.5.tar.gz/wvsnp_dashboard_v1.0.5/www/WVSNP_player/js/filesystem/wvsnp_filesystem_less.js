/*
 * NOT MAINTAINED RIGHT NOW! OUTDATED, WILL PROBABLY NOT WORK!
 *
 * TODO: NEEDS RETOUCHING!
 */

/** @brief helper function for oncanplaythrough event of temporary video-element
 * 
 * This function is called when the event "oncanplaythrough" is fired once a
 * temporary video element finnished loading its content and is ready to play
 * 
 * .............................................................................
 */
Player.prototype.tempVideoLoaded = function (that, a_writer_video_index) {

	that.logger('temp_video_loaded ' + a_writer_video_index);
	var temp_video_element = document.getElementById('wvsnp_temp_video_' + a_writer_video_index + '_' + that.video_id);

	that.logger('duration: ' + temp_video_element.duration);
	
	if(temp_video_element.duration == "" || isNaN(temp_video_element.duration))
	{
		alert(a_writer_video_index + " will be called again");
		window.setTimeout(function() { that.tempVideoLoaded(that, a_writer_video_index); }, 2000);	
		return;
	}

	that.buffering.canPlay(that, a_writer_video_index);
	that.getDuration(that, a_writer_video_index);

	temp_video_element.addEventListener('playing', function() { that.playingListener(that, a_writer_video_index); }, false);
	temp_video_element.addEventListener("timeupdate", function() { that.videoTimeupdateFunction(that, temp_video_element); }, false);
}

/** @brief Requests the video with a_writer_video_index from the server
 * 
 * A function to request a specific video-segment from the server, which
 * will be stored in a hidden HTML5 video-element from which it can be played
 * 
 * .............................................................................
 */
Player.prototype.triggerFileDownload = function (that, a_writer_video_index) {
	var that = this;
	
	var temp_video_element = document.getElementById('wvsnp_temp_video_' + a_writer_video_index + '_' + that.video_id);
	if(this.use_no_fs_blob == null)
	{
		temp_video_element.src = that.getRemoteFileName(that, a_writer_video_index);
		that.startPlayingAndWaitForVideo(that, temp_video_element, function () {
			that.tempVideoLoaded(that, a_writer_video_index);
		});
	}
	else
	{
		that.loadVideoBLOB(that, temp_video_element, a_writer_video_index);
	}
	
} //END of create_file_request--------------------------------------------------------------


//helper function for initalize_reader with callback to initalize reader
//that decrements buffer_to_play index if the file is found in the local 
//directory.
Player.prototype.checkLocalDirectory = function (that, start_reader_i, play_i, buffer_to_play) {
}



/** @brief Requests a local file and loads it to a video element
 * 
 * A function that makes a request to access local file then calling 
 * function read_load_video()
 * 
 *..............................................................................
 */
Player.prototype.readFileRequest = function (that, a_reader_video_index) {

	// TODO: shouldn't the last check be sufficient? The writer should not go past the last index anyways?
	if (a_reader_video_index <= that.last_index && a_reader_video_index < that.writer_video_index) {
	
		a_reader_video_index++;	
		// nothing to do here, since the video-data is already loaded into the video-element
	}	
}


/** @brief Requests a file from the File System and deletes it.
 * 
 * A function that requests a file from the File System and deletes it.
 * 
 * .............................................................................
 */
Player.prototype.deleteFileRequest = function (that, file_name) {

	// TODO: delete temp-video element instead, or free ObjectURL
	var regexpSearch = /^(.*?)-([0-9]+)-([0-9]+)\.(.+?)$/g;
	var video_index = file_name.replace(regexpSearch, '$3');
	
	that.logger('delete file: ' + file_name);
	if(that.use_no_fs_blob != null)
	{
		that.deleteFileRequestBLOB(that, video_index);
	}
	that.ui.getDesignatedVideoElement(that, video_index).src = "";
	that.ui.getDesignatedVideoElement(that, video_index).load(); // load the now "empty" video
}

Player.prototype.calcRealToPlayIndex = function (that, mod_play_i) {
	return ((that.last_index - that.first_index + 1) * (that.play_episode - 1) + mod_play_i);
}

//123456789012345678901234567890123456789012345678901234567890123456789012345678