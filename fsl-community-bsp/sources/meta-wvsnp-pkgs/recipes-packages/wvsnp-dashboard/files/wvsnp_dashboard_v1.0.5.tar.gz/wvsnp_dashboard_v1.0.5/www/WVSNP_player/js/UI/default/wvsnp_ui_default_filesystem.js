/** @file video_player_filesystem.js
 *  @brief A video player that plays segmented videos continuously and seamlessly
 * 
 * Extension of video_player.js
 * adding functions to the player to support the FileSystem API.
 */

Player_UI.prototype.hideVideoElements = function(that, except_playing) {

	for(var i = 0; i < 2; i++)
	{
		var temp_video_element = that.ui.getDesignatedVideoElement(that, i);
		if(temp_video_element)
		{			
			if(i != (except_playing % 2))
			{
				/*temp_video_element.hidden = false;*/
				temp_video_element.muted = "muted";
				temp_video_element.volume = 0.1;
			}
			else
			{
				/*temp_video_element.hidden = that.ui.has_canvas;*/
				temp_video_element.muted = false;
				temp_video_element.volume = 1.0;
			}
		}
	}
}

Player_UI.prototype.resetVideoDimensions = function(that) {
	for(var i = 0; i < 2; i++)
	{
		var temp_video_element = that.ui.getDesignatedVideoElement(that, i);
		if(temp_video_element)
		{
			// TODO: what about the non-canvas version?
			/*
			// workaround for fullscreen
			if(that.ui.is_fullscreen)
			{
				temp_video_element.style.width = '100%';
				temp_video_element.style.height = '100%';
			}
			else
			{
				temp_video_element.style.width = that.ui.w + 'px';
				temp_video_element.style.height = that.ui.h + 'px';
			}
			*/
		}
	}
}

Player_UI.prototype.create_video_elements = function(that) {
	// hack for android: we need to create app video-elements from scratch right now
	// <video> elements cannot be started from code using play() unless they have
	// been started one time already with user-interaction.
	// the "click" event is a user-interaction, so create our video-elements,
	// call "play()" and directly after that "pause()". Android will accept this as
	// user-manipulation and thereafter the video-elements can be used from javascript code
	for(var i = 0; i < 2; i++)
	{
		// get the current video element
		var temp_video_element = that.ui.getDesignatedVideoElement(that, i);
		temp_video_element.play();
		temp_video_element.pause();
		//temp_video_element.style.width = (that.ui.w) + "px";
		//temp_video_element.style.height = (that.ui.h) + "px";
		temp_video_element.addEventListener('error', function(err){
			// Nothing to see here...
			that.logger('ERROR in Video Element!');
			that.logger(err);
		}, false);
	}
	var bufferVideoElement = document.getElementById('check_buffered_duration_' + that.video_id);
	bufferVideoElement.play();
	bufferVideoElement.pause();
}

Player_UI.prototype.dynamicSourceInput = function (that) {

	var dynamic_source_value = document.getElementById("dynamic_source_input_" + that.video_id).value;
	that.logger("dynamic source value is " + dynamic_source_value);

	// now create a new player-element from scratch (clean approach)
	var dynamic_player = new Player(++maximumVideoPlayerId, document.getElementById('player_wrapper_' + that.video_id), dynamic_source_value);

	setTimeout(function() {
		if(dynamic_player.ui.html_setup)
		{
			// initialize the video object
			dynamic_player.triggerPlaybackStart(dynamic_player);
		}
		that = null;
	}, 200);
}


/** @brief Sets the current_video_element to point to the video element 
 * that is currently playing
 * 
 * A function that sets the current_video_element to point to the video 
 * element that is currently playing. This global variable is used by
 * functions such as play_pause, draw_screen, rewind_fast_forward, and other  
 * control related functions.
 * 
 * .............................................................................
 */
Player_UI.prototype.setCurrentVideoElement = function (that, video_index) {

	var videoElement = that.ui.getDesignatedVideoElement(that, video_index);
	that.ui.current_video_element = videoElement;
	
	return videoElement;
}

/** @brief returns the video-element that will show the given video-index
 *
 * other than setCurrentVideoElement, this will not set anything. Use this
 * as sole getter-element!
 */
Player_UI.prototype.getDesignatedVideoElement = function (that, video_index) {

	if (video_index % 2 == 0) {
		return document.getElementById("wvsnp_video1_" + that.video_id);
	} else {
		return document.getElementById("wvsnp_video2_" + that.video_id);
	}
}

/** @brief Listens for the end of each segment.
 * 
 * A function that listens for the end of the current segment that is playing.
 * At the end of the segment the video_to_play index is updated. Then play_pause
 * is called, which then plays the proper video element. 
 * 
 * .............................................................................
 */
Player_UI.prototype.endOfSegementTimer = function (that) {
	
	//  that.logger("end of segment timer called");
	var handler;
	that.start_end_of_segment_timer = true;
	var video_element1 = document.getElementById("wvsnp_video1_" + that.video_id);
	var video_element2 = document.getElementById("wvsnp_video2_" + that.video_id);

	video_element1.addEventListener('playing', function() { that.playingListener(that, that.video_to_play_index); }, false);
	video_element2.addEventListener('playing', function() { that.playingListener(that, that.video_to_play_index); }, false);
	video_element1.addEventListener("timeupdate", function() { that.videoTimeupdateFunction(that, video_element1); }, false);
	video_element2.addEventListener("timeupdate", function() { that.videoTimeupdateFunction(that, video_element2); }, false);
}