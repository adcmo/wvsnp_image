/*######################################################################
 *
 *  FILE: buttonfunctions.c
 *  AUTHOR: Julius Eddards
 *
 *  DESCRIPTION:
 *	This code will create html buttons that when pressed will
 *      execute a function to interact with XBee modules.  
 *
 *  This file is designed to create a HTML file that can be embedded
 *  in the WVSNP dash.
 *
 *  LAST MODIFIED: 12/07/2013 [JE]
 *######################################################################
*/

#define SERVER_NAME cgiServerName   //The server name is set in the mongoose config file.
#define MAX_PAYLOAD_BYTES 72        // From testing the max bytes that can be sent is 70 (at the moment)
#define INIT_FILE_TRANSFER 0xA1
#define FILE_PAYLOAD 0xA2
#define FILELOCATION "../received/" //Default file location on the server in relation to CGI file location

#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include "xbee.h"
#include <math.h>

//Prototypes for the handler methods
int handle_b1();
int handle_b2();
int handle_b3();
int handle_b4();
int handle_b5();
int handle_b6();
int handle_b7();
int handle_b8();
void ShowForm();

//##################### Global Variables ######################################
int d4 = 0;		//Used to hold value of D4

//This just for my asynchrounous coordination
int needs_response = 1; //default.
                        //0 => the command just issues needs no response.
                        //2 => implies check only for IO

int configure_set = 0; //default.
                       //1 reconfigure module before readout
                       //2 set D4 to ON else set it to OFF.
                       
int resent = 0; // For error recovery of file transfer

cgiFilePtr file;    // File Pointer
char name[100];     // Name of the file for cgi
char filename[64];  // Temporary variable to save the file's name when it is received

//###################### INITIALIZE FILE TRANSFER ###########################
void init_send_file( char *file_name, struct xbee *xbee, struct xbee_con *con )
{
	unsigned char buffer[MAX_PAYLOAD_BYTES];
	//int payload_size = MAX_PAYLOAD_BYTES - 2;
	long f_size;
	xbee_err ret;
	f_size = strlen( file_name );
	buffer[0] = INIT_FILE_TRANSFER;
	buffer[1] = f_size % MAX_PAYLOAD_BYTES;
	strcpy( &buffer[2], file_name );
	if ((ret = xbee_conTx(con, NULL, buffer)) != XBEE_ENONE) {
		xbee_log(xbee, -1, xbee_errorToStr(ret));
	}
}

//################### RECEIVE FILE FOR FILE TRANSFER ########################
int receive_file( unsigned char *payload )
{
	FILE *destination;
	int count;
	char nameOnServer[64];     // Variable to store the path to the directory on the server along with the file name
	
	strcpy(nameOnServer, FILELOCATION);
	strcat(nameOnServer, filename); // name of the file is stored in the second index of the payload
	destination = fopen( nameOnServer, "ab" );
	//destination = fopen("../received/copy", "ab");
	
	if( destination == NULL )
	{
		fprintf(stderr, "Unable to create the destination file %s\n.", nameOnServer);
		return -1;
	}
	
	//Get the number bytes in the payload
	count = (uint8_t)payload[0];
	
	if( count > 0 )
	{
		fwrite( &payload[1], 1, count, destination );
	}
	else
	{
		printf( "Nothing in the buffer.\n" );
	}
	
	fclose( destination );
	
	return 0;
}


//###################### ERROR RECOVERY FOR FILE TRANSFER ###################################
int error_recovery_resend_packet(unsigned char *buf, struct xbee *xbee, struct xbee_con *con )
{
	resent++;

	//printf("Re-initializing file transfer.\n");
	//init_send_file( file_name, xbee, con );
	
	printf("Resending file.\n");
	//send_file( file_name, xbee, con );
	
	printf("Number of times packet has tried to be resent: %d\n", resent);
	
	if(xbee_connTx(con, NULL, buf, MAX_PAYLOAD_BYTES) != XBEE_ENONE)
	{
		printf("Timeout occurred during resending of packet.\n");
		
		// keeps trying to send the packet
		error_recovery_resend_packet(buf, xbee, con);
	}
	
	resent = 0;
	return 0;
}


//################### SEND FILE FOR FILE TRANSFER ########################
int send_file( char *file_name, struct xbee *xbee, struct xbee_con *con)
{
	unsigned char buffer[MAX_PAYLOAD_BYTES];
	uint8_t payload_size = MAX_PAYLOAD_BYTES - 2;
	FILE *source;
	long f_size;
	int chunks;
	xbee_err ret;
	int fopenissue = 0;
	int size;
	
	// opens file for read as a binary
	source = fopen( file_name, "rb" );
	//file = open(file_name, "rb");
	
	if( source == NULL )
	{
		printf( "%s:Unable to open %s.", __FUNCTION__, file_name );
		return -1;
	}
	if( cgiFormFileOpen("file", &file) != cgiFormSuccess ) 
        {
        	fprintf( cgiOut, "Could not open the file.<p>\n" );
        	fopenissue = 1;
        }
	
	//Determine the size of the file
	fseek( source, 0, SEEK_END );

	f_size = ftell( source );
	rewind( source );

	//Determine the number of chucks to be sent
	chunks = f_size / payload_size;
	
	if( f_size % payload_size != 0 )
	{
		chunks += 1;
	}
	
	while( chunks > 0 )
	{
		
		//Declare the type of tranmission
		buffer[0] = FILE_PAYLOAD;
	
		//Determine payload size for each individual chunk
		if( chunks == 1 )
		{
			buffer[1] = f_size % payload_size;	
			if( buffer[1] == 0 )
			{
				buffer[1] = payload_size;
			}
		}
		else
		{
			buffer[1] = payload_size;
		}
		
		//Must cast buffer[0] as an 8-bit number because if it is large enough
		//it will be interpereted as a negative number
		//Example:
		//		(uint8_t) 0xFE = 254
		//		(int) 0xFE = -2
		fread( &buffer[2], 1, (uint8_t)buffer[1], source );
		
		if ((ret = xbee_connTx(con, NULL, buffer, MAX_PAYLOAD_BYTES)) != XBEE_ENONE) {
			xbee_log(xbee, -1, xbee_errorToStr(ret));
			// calls function to resend the file/packet with the current xbee connection
			error_recovery_resend_packet(buffer, xbee, con);
		}	
		chunks--;
	}
	fclose( source );
	//cgiFormFileClose(file);

	return 0;
}


//###### Callback function for getting the connected device ID (called from handle_b1)
void myCB(struct xbee *xbee, struct xbee_con *con, struct xbee_pkt **pkt, void **data) {

	if ((*pkt)->dataLen == 0) {

		printf("too short...\n");

		return;
	}

	fprintf( cgiOut, "Device ID: [%s]<p>\n", ((*pkt)->data));
	//fprintf( cgiOut, "line[%d]..................functionname[%s]\n", __LINE__, __func__ );

}



//###### Callback function for getting the remote device ID 
void myCB2( 
    struct xbee *xbee,
    struct xbee_con *con,
    struct xbee_pkt **pkt,
    void **data ) {

	xbee_err ret;
	int value;
	int channel;

    if ( needs_response > 1 ) {
        //Scan for all available Digital IO status returned.
		for ( channel = 0; channel <= 8; channel++ ) {
        
			if ( ( ( ret = xbee_pktDigitalGet(*pkt, channel, 0, &value) ) != XBEE_ENONE ) 
                && ( ret != XBEE_ENOTEXISTS ) ) {
				
                printf( "xbee_pktDigitalGet(channel=%d): ret %d\n", channel, ret );
        
			} else if (ret != XBEE_ENOTEXISTS) {

                //printf( "D%d: %d\n", channel, value );
		
		        if (channel == 4) {
			
		            d4 = value;				
		        }
            }
		}
        
        //Scan for all available Analog IO status returned.
		for ( channel = 0; channel <= 3; channel++ ) {
        
			if ( ( (ret = xbee_pktAnalogGet(*pkt, channel, 0, &value) ) != XBEE_ENONE ) 
                && ( ret != XBEE_ENOTEXISTS ) ) {

				printf( "xbee_pktAnalogGet(channel=%d): ret %d\n", channel, ret );

			} else if (ret != XBEE_ENOTEXISTS) {

				//printf("A%d: %d\n", channel, value);

			}
		}

        return;
    }

	if ( (*pkt)->dataLen == 0 ) {

        if ( needs_response == 1 ) {

            printf("Packet too short/empty!!!\n");

        } else {

            needs_response = 1;

        }

	} else if ( (*pkt)->dataLen == 1 ) {
		/*
        printf(
            "(1) rx[%x], length[%d].\n",
            (*pkt)->data[0],
            (*pkt)->dataLen
        );
		*/
        if ( ( (*pkt)->data[0]) == 0x4) {
       	    fprintf ( cgiOut, "Light is: OFF.<p>\n");
        } else {
       	    if ( ( (*pkt)->data[0]) == 0x5){
    		    fprintf ( cgiOut, "Light is: ON.<p>\n");
    	    }
        }

	} else if ( (*pkt)->dataLen == 2 ) {
		/*
        printf(
            "(2) rx[%x,%x], length[%d].\n",
            (*pkt)->data[0],
            (*pkt)->data[1],
            (*pkt)->dataLen
        );
		*/
    } else {

        printf( "(3) rx[%s], length[%d].\n", (*pkt)->data, (*pkt)->dataLen );

    }

//if rx = 4 then OFF, rx = 5 if ON.

	return;

} //END myCB2() handler.



//###### Callback function for getting the Temperature from a device sensor
void myCBT(struct xbee *xbee, struct xbee_con *con, struct xbee_pkt **pkt, void **data) {

    xbee_err ret;
    int value;
    int channel;

    //Analog_Voltage = (Analog_String/1023)*1.2 = 1.0147 Volts
    //Resistance_Thermistor = (2000)/(5/Analog_String - 1) = 509.22 Ohms
    //Temperature_Celsius = 3000/ln(Resistance_Thermistor/0.0128) - 273.15 = 10.105Celcius
    //Temperature_Farenheit = Temperature_C(1.8)+32 = 50.189 Farenheit

    double analog_voltage = 0;
    double resistance_thermistor = 0;
    double temperature_celsius = 0;
    double temperature_farenheit = 0;

	
	for (channel = 0; channel <= 8; channel++) {
		if ((ret = xbee_pktDigitalGet(*pkt, channel, 0, &value)) != XBEE_ENONE && ret != XBEE_ENOTEXISTS) {
			printf("xbee_pktDigitalGet(channel=%d): ret %d\n", channel, ret);
		} else if (ret != XBEE_ENOTEXISTS) {
			//printf("D%d: %d\n", channel, value);
		}
	}
	for (channel = 0; channel <= 3; channel++) {
		if ((ret = xbee_pktAnalogGet(*pkt, channel, 0, &value)) != XBEE_ENONE && ret != XBEE_ENOTEXISTS) {
			printf("xbee_pktAnalogGet(channel=%d): ret %d\n", channel, ret);
		} else if (ret != XBEE_ENOTEXISTS) {
			//printf("A%d: %d\n", channel, value);
		}
	}

    for (channel = 0; channel <= 8; channel++) {

        if ((ret = xbee_pktDigitalGet(*pkt, channel, 0, &value)) != XBEE_ENONE && ret != XBEE_ENOTEXISTS) {
            printf("xbee_pktDigitalGet(channel=%d): ret %d\n", channel, ret);
        } else if (ret != XBEE_ENOTEXISTS) {
            //printf("D%d: %d\n", channel, value);
        }

    }

    for (channel = 0; channel <= 3; channel++) {

        if ((ret = xbee_pktAnalogGet(*pkt, channel, 0, &value)) != XBEE_ENONE && ret != XBEE_ENOTEXISTS) {

            printf("xbee_pktAnalogGet(channel=%d): ret %d\n", channel, ret);

        } else if (ret != XBEE_ENOTEXISTS) {

            //printf("A%d: %d\n", channel, value);

            if ( channel == 3 ) {

            	//fprintf(cgiOut, "<p>Value = %d<p>", value);

                analog_voltage = ((double)value/1023)*1.2;
                resistance_thermistor = (2000)/(5/analog_voltage - 1);
                temperature_celsius = 3000/log(resistance_thermistor/0.0128) - 258.15;
                temperature_farenheit = temperature_celsius*(1.8)+32;

                //fprintf(cgiOut, "analog_voltage=[%f].<p>\n", analog_voltage );
                //fprintf(cgiOut, "resistance_thermistor=[%f].<p>\n", resistance_thermistor );
                fprintf(cgiOut, "Temperature Celsius = [%f].<p>\n", temperature_celsius );
                fprintf(cgiOut, "Temperature Fahrenheit = [%f].<p>\n", temperature_farenheit );

            }

        }
    }

}//end of myCBT



//###### Callback function for getting the light sensor data
void myCBL(struct xbee *xbee, struct xbee_con *con, struct xbee_pkt **pkt, void **data) {
	xbee_err ret;
	int value;
	int channel;
	
	for (channel = 0; channel <= 8; channel++) {
		if ((ret = xbee_pktDigitalGet(*pkt, channel, 0, &value)) != XBEE_ENONE && ret != XBEE_ENOTEXISTS) {
			printf("xbee_pktDigitalGet(channel=%d): ret %d\n", channel, ret);
		} else if (ret != XBEE_ENOTEXISTS) {
			printf("D%d: %d\n", channel, value);
		}
	}
	for (channel = 0; channel <= 3; channel++) {
		if ((ret = xbee_pktAnalogGet(*pkt, channel, 0, &value)) != XBEE_ENONE && ret != XBEE_ENOTEXISTS) {
			printf("xbee_pktAnalogGet(channel=%d): ret %d\n", channel, ret);
		} else if (ret != XBEE_ENOTEXISTS) {
			printf("A%d: %d\n", channel, value);
		}
	}
} //end MyCBL


//##################### CALLBACK FUNCTION FOR THE FILE TRANSFER (SENDING) ####################
void myCB_sendFile(struct xbee *xbee, struct xbee_con *con, struct xbee_pkt **pkt, void **data) {
	unsigned char *payload;
	if ((*pkt)->dataLen > 0) {
		
		payload = (*pkt)->data;
		
		if( payload[0] == INIT_FILE_TRANSFER )
		{
			printf( "length: %d\n", payload[1] );
			printf( "data: %s\n", &payload[2] );
		}
	}
}


//##################### CALLBACK FUNCTION FOR THE FILE TRANSFER (RECEIVING) ####################
void myCB_receiveFile(struct xbee *xbee, struct xbee_con *con, struct xbee_pkt **pkt, void **data) {
	unsigned char *payload;
	
	if ((*pkt)->dataLen > 0) {
		
		payload = (*pkt)->data;
		
		if( payload[0] == INIT_FILE_TRANSFER )
		{
			strcpy(filename, &payload[2]);
			printf("<p>Receiving File: %s\n<p>", &payload[2]);
		}
		else if( payload[0] == FILE_PAYLOAD )
		{
			receive_file( &payload[1] );
		}
	}
}



//&&&&&&&&&&&&&&&&&&&&&&&& THE MAIN FUNCTION &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int cgiMain() 
{
  /* Send the content type, letting the browser know this is HTML */
  cgiHeaderContentType("text/html");

  /* Top of the page */
  fprintf( cgiOut, "<HTML><HEAD>\n" );

  fprintf( cgiOut, "<TITLE>WVSNP DashBoard</TITLE></HEAD>\n" );

  fprintf( cgiOut, "<BODY>");

        
  if( cgiFormSubmitClicked("b1") == cgiFormSuccess )
  {
    handle_b1();	//B1 = Get Connected Device ID
  }
  if( cgiFormSubmitClicked("b2") == cgiFormSuccess )
  {
    handle_b2();	//B2 = Get Remote Device ID
  }
  if( cgiFormSubmitClicked("b3") == cgiFormSuccess )
  {
    handle_b3();	//B3 = Toggle Light On/Off
  }
  if( cgiFormSubmitClicked("b4") == cgiFormSuccess )
  {
  	handle_b4();	//B4 = Refresh
  	configure_set = 0;    //Reset configure_set flag after executing refresh
  }
  if( cgiFormSubmitClicked("b5") == cgiFormSuccess )
  {
  	handle_b5();	//B5 = Get Temperature Data
  }
  if( cgiFormSubmitClicked("b6") == cgiFormSuccess )
  {
  	handle_b6();	//B6 = Get Light Sensor Data
  }
  if( cgiFormSubmitClicked("b7") == cgiFormSuccess )
  {
  	handle_b7();	//B7 = Send File
  }
  if( cgiFormSubmitClicked("b8") == cgiFormSuccess )
  {
  	handle_b8();	//B8 = Receive File
  }
  ShowForm();
        
  /* Finish up the page */
  fprintf( cgiOut, "</BODY></HTML>\n" );
  return 0;
}
        


//&&&&&&&&&&&&&&&&&&&&&&&& CONNECTED DEVICE ID &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int handle_b1()
{
	void *d;
	struct xbee *xbee;
	struct xbee_con *con;
	unsigned char txRet;
	xbee_err ret;

	/* setup libxbee, using the USB to Serial adapter '/dev/ttyUSB0' at 57600 baud */
	if ((ret = xbee_setup(&xbee, "xbeeZB", "/dev/ttyUSB0", 57600)) != XBEE_ENONE) {
		fprintf( cgiOut, "ret: %d (%s)\n", ret, xbee_errorToStr(ret));
		return ret;
	}

	/* create a new AT connection to the local XBee */
	if ((ret = xbee_conNew(xbee, &con, "Local AT", NULL)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conNew() returned: %d (%s)", ret, xbee_errorToStr(ret));
		return ret;
	}

	/* configure a callback for the connection
	   this function is called every time a packet for this connection is recieved */
	if ((ret = xbee_conCallbackSet(con, myCB, NULL)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conCallbackSet() returned: %d", ret);
		return ret;
	}

	/* send the AT command 'NI' (request the Node Identifier)
	   when the response is recieved, the packet will be directed to the callback function */
	ret = xbee_conTx(con, &txRet, "NI");
	/* print out the return value
	   if this is non-zero, then check 'enum xbee_errors' in xbee.h for its meaning
	   alternatively look at the xbee_errorToStr() function */
	//fprintf( cgiOut, "tx: %d\n", ret);

	if (ret) {
		/* if ret was non-zero, then some error occured
		   if ret == XBEE_ETX then it is possible that txRet is now -17 / XBEE_ETIMEOUT
		   alternatively, txRet will contain the status code returned by the XBee */
		fprintf( cgiOut, "txRet: %d\n", txRet);

	} else {
		/* give the callback a chance to run */
		usleep(1000000);

	}

	/* shutdown the connection */
	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) {

		xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);

		return ret;

	}

	/* shutdown libxbee */
	xbee_shutdown(xbee);

return 0;

}



//&&&&&&&&&&&&&&&&&&&&&&&& REMOTE DEVICE ID &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int handle_b2()
{
	void *d;
	struct xbee *xbee;
	struct xbee_con *con;
	struct xbee_conAddress address;
	unsigned char txRet;
	xbee_err ret;

	if ((ret = xbee_setup(&xbee, "xbeeZB", "/dev/ttyUSB0", 57600)) != XBEE_ENONE) {

		fprintf( cgiOut, "ret: %d (%s)\n", ret, xbee_errorToStr(ret));

		return ret;
	}

	/* this is the 64-bit address of the remote XBee module
	   it should be entered with the MSB first, so the address below is
	   SH = 0x0013A200    SL = 0x40081826 */
	memset(&address, 0, sizeof(address));

	address.addr64_enabled = 1;

	address.addr64[0] = 0x00;
	address.addr64[1] = 0x13;
	address.addr64[2] = 0xA2;
	address.addr64[3] = 0x00;
                            //0x0013A200408BAE32
	//address.addr64[4] = 0x40;//light
	//address.addr64[5] = 0x8B;
	//address.addr64[6] = 0xAE;
	//address.addr64[7] = 0x32;
	
	address.addr64[4] = 0x40;//temperature
	address.addr64[5] = 0xBF;
	address.addr64[6] = 0x06;
	address.addr64[7] = 0xB1;

	//address.addr64[4] = 0x40;
	//address.addr64[5] = 0xBF;
	//address.addr64[6] = 0x06;
	//address.addr64[7] = 0xED;

	if ((ret = xbee_conNew(xbee, &con, "Remote AT", &address)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conNew() returned: %d (%s)", ret, xbee_errorToStr(ret));
		return ret;
	}

	if ((ret = xbee_conCallbackSet(con, myCB, NULL)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conCallbackSet() returned: %d", ret);
		return ret;
	}
	
	ret = xbee_conTx(con, &txRet, "NI");

	//printf("tx: %d\n", ret);

	if (ret) {

		fprintf( cgiOut, "txRet: %d\n", txRet);

	} else {

		usleep(1000000);

	}
	
	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) {

		xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);

		return ret;
	}

	xbee_shutdown(xbee);

    return 0;
}



//&&&&&&&&&&&&&&&&&&&&&&&& TOGGLE ON/OFF &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int handle_b3()
{
	void *d;
	struct xbee *xbee;
	struct xbee_con *con;
	struct xbee_conAddress address;
	unsigned char txRet;
	xbee_err ret;

    int baud_rate = 57600; //default

    configure_set = 0;

 	if ((ret = xbee_setup(&xbee, "xbeeZB", "/dev/ttyUSB0", 57600)) != XBEE_ENONE) {

		fprintf( cgiOut, "ret: %d (%s)\n", ret, xbee_errorToStr(ret));

		return ret;
	}

	memset(&address, 0, sizeof(address));
	address.addr64_enabled = 1;
   
   // printf( "String address parameter given=[%s]\n", argv[3] );
    //e.g. The above will look like: address64=F013A200408BAE32

   // unsigned long int hex_address = strtoul( argv[3], (char **)(argv[3]+18), 0 );
   // printf( "The hex interger conversion=[%lx]\n", hex_address );
  
   // unsigned char bytes_addr64[8];
   // memcpy(void *dest, const void *src, size_t n);
   // memcpy( &bytes_addr64[0], &hex_address, 8 );

    //DL=Router's SL
	address.addr64[0] = 0x00;
	address.addr64[1] = 0x13;
	address.addr64[2] = 0xA2;
	address.addr64[3] = 0x00;
    
    //DL=Router's SL
	//address.addr64[4] = 0x40;
	//address.addr64[5] = 0x8B;
	//address.addr64[6] = 0xAE;
	//address.addr64[7] = 0x72;

	address.addr64[4] = 0x40;
	address.addr64[5] = 0x8B;
	address.addr64[6] = 0xAE;
	address.addr64[7] = 0x32;

    /*/TJ's switch
	address.addr64[4] = 0x40;
	address.addr64[5] = 0x8B;
	address.addr64[6] = 0xAE;
	address.addr64[7] = 0x72;
    */

    //i.e. =f013a200408bae32 becomes
    //[32][ae][8b][40][0][a2][13][f0]
   /* printf( "Depending on your Endianness this will be:\n"\
            "[%0x][%0x][%0x][%0x][%0x][%0x][%0x][%0x]\n",
            address.addr64[0],            
            address.addr64[1],
            address.addr64[2],
            address.addr64[3],
                             
            //DL=Router's SL 
            address.addr64[4],
            address.addr64[5],
            address.addr64[6],
            address.addr64[7] );
*/
    //Creating a remote AT command connection----------------------------------
	if ( (ret = xbee_conNew(xbee, &con, "Remote AT", &address)) != XBEE_ENONE ) {

		xbee_log( 
            xbee, -1,
            "xbee_conNew() returned: %d (%s)",
            ret, xbee_errorToStr(ret)
        );

		return ret;
	}
	
    //Setting a remote AT command response handler----------------------------
	if ((ret = xbee_conCallbackSet(con, myCB2, NULL)) != XBEE_ENONE) {

		xbee_log(xbee, -1, "xbee_conCallbackSet() returned: %d", ret);

		return ret;
	}


    //verify
    //printf( "Will wait 0.1 second max for IR response.\n" );

	ret = xbee_conTx( con, &txRet, "IR" );
	if ( ret  != XBEE_ENONE ) {
		printf( "txRet[%d], IR failed.\n", txRet );
		return ret;
	} else {
		usleep(100000); //=0.1 second.

        //fprintf( cgiOut, "tx[%d].\n", ret );
	}

    //AT Command = IS     = Force Sample Forces a read of all enabled digital 
    //    and analog input lines.
    //
    //    Node Type       = CRE
    //    Parameter Range = --
    //    Default         = --
    //fprintf( cgiOut, "Will wait 1 second max for IS response.\n" );
    needs_response = 2;
    ret = xbee_conTx( con, &txRet, "IS" );
	if ( ret != XBEE_ENONE ) {
		fprintf( cgiOut, "txRet[%d], ret[%d], IS failed.\n", txRet, ret );
		xbee_log( xbee, -1, "xbee_conTx() returned: %d", ret );
		return ret;
	}

	usleep(100000);    //=0.1 second.

    //Set D4 LOW/HIGH.
    if ( d4 == 0 ) { //HIGH

        //AT Command = D4     = DIO4 Configuration. Select/Read function for DIO4.
        //
        //    Node Type       = CRE
        //    Parameter Range = 0, 3-5
        //                      0 – Disabled
        //                      3 – Digital input
        //                      4 – Digital output, low
        //                      5 – Digital output, high
        //    Default         = 0
    
        //Set D4 HIGH.
        //fprintf( cgiOut, "Will wait 0.1 second max for D4 HIGH response.\n" );
        needs_response = 0;
	    ret = xbee_conTx( con, &txRet, "D4%c", 5 );
        //ret = xbee_convTx( con, &txRet, "D4 %0x" 4 );
	    if ( ret  != XBEE_ENONE ) {
	    	fprintf( cgiOut, "txRet[%d], D4 5 failed[%s].\n", ret, xbee_errorToStr(ret) );
	    	return ret;
	    } else {
	    	usleep(100000); //=0.1 second.
            //fprintf( cgiOut, "tx[%d].\n", ret );
		}
	
    } else {

        //fprintf( cgiOut, "Will wait 0.1 second max for D4 LOW response.\n" );
        needs_response = 0;
		ret = xbee_conTx( con, &txRet, "D4%c", 4 );
		if ( ret  != XBEE_ENONE ) {
			fprintf( cgiOut, "txRet[%d], D4 4 failed[%s].\n", ret, xbee_errorToStr(ret) );
			return ret;
		} else {
			usleep(100000); //=0.1 second.
            //fprintf( cgiOut, "tx[%d].\n", ret );
		}
    	
    }//END D4 toggle choice
    	
    //Now let's check if it has been toggled HIGH/LOW.
    //fprintf( cgiOut, "Will wait 0.1 second max for D4 response.\n" );
	ret = xbee_conTx( con, &txRet, "D4" );
	if ( ret  != XBEE_ENONE ) {
		fprintf( cgiOut, "txRet[%d], D4 failed.\n", txRet );
		return ret;
	} else {
		usleep(100000); //=0.1 second.
        //fprintf( cgiOut, "tx[%d].\n", ret );
	}
    

	
	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);
		return ret;
	}

	xbee_shutdown(xbee);

	return 0;
}



//&&&&&&&&&&&&&&&&&&&&&&&& REFRESH &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int handle_b4()
{
	void *d;
	struct xbee *xbee;
	struct xbee_con *con;
	unsigned char txRet;
	xbee_err ret;
  	configure_set = 1;


	//Here we begin configuration steps to make sure we are talking and
    //the that the remote module is configured as we expect.	
    //If "configure" was set at invocation, then this section will change some
    //parameters.
   
    //CRE = Node types that support the command:
    //C=Coordinator, R=Router, E=End Device

    if ( configure_set == 1 ) {

        //AT Command = IR     = IO Sample Rate. Set/Read the IO sample rate to 
        //    enable periodic sampling. For periodic sampling to be enabled, IR 
        //    must be set to a non-zero value, and at least one module pin. Must 
        //    have analog or digital IO functionality enabled (see D0-D8, P0-P2 
        //    commands). The sample rate is measured in milliseconds.
        //
        //    Node Type       = CRE
        //    Parameter Range = 0, 0x32:0xFFFF (ms)
        //    Default         = 0
        fprintf( cgiOut, "Will wait 0.1 second max for IR 2000 response.\n" );    
		ret = xbee_conTx( con, &txRet, "IR%c%c", 0x7, 0xd0 );
		if ( ret  != XBEE_ENONE ) {
			fprintf( cgiOut, "txRet[%d], IR 2000 failed.\n", txRet );
			return ret;
		} else {
			usleep(100000); //=0.1 second.
            fprintf( cgiOut, "tx[%d].\n", ret );
		}
     

        //AT Command = RP     = RSSI PWM Timer. Time the RSSI signal will be output
        //    on the PWM after the last RF data reception or APS acknowledgment.
        //    When RP = 0xFF, output will always be on.
        //
        //    Node Type       = CRE
        //    Parameter Range = 0 - 0xFF [x 100 ms]
        //    Default         = 0x28 (40d)
        fprintf( cgiOut, "Will wait 0.1 second max for RP response.\n" );
    	ret = xbee_conTx( con, &txRet, "RP" );
    	if ( ret  != XBEE_ENONE ) {
			fprintf( cgiOut, "txRet[%d], RP failed.\n", txRet );
			return ret;
		} else {
			usleep(100000); //=0.1 second.
	        fprintf( cgiOut, "tx[%d].\n", ret );
		}
    
	    //Now that we know default RP is 4 seconds = 0x28 (40 decimal) let's change
        //it. To configure the duration of the RSSI/PWM output, set the RP command.
        //To achieve a 2 second PWM output, set
        //RP to 0x14 (20 decimal, or 2 seconds) and apply changes (AC command).
        fprintf( cgiOut, "Will wait 0.1 second max for RP response.\n" );
        needs_response = 0;
    	ret = xbee_conTx( con, &txRet, "RP%c", 20 );
    	if ( ret  != XBEE_ENONE ) {
    		fprintf( cgiOut, "txRet[%d], RP 20 failed.\n", txRet );
    		return ret;
    	} else {
			usleep(100000); //=0.1 second.
	        fprintf( cgiOut, "tx[%d].\n", ret );
		}


        //AT Command = AC     = Apply Changes. Applies changes to all command
        //    registers causing queued command register values to be applied. For
        //    example, changing the serial interface rate with the BD command will
        //    not change the UART interface rate until changes are applied with the
        //    AC command. The CN command and 0x08 API command frame also apply
        //    changes.
        //
        //    Node Type       = CRE
        //    Parameter Range = none
        //    Default         = none
	    fprintf( cgiOut, "Will wait 0.1 second max for AC response.\n" );
	    needs_response = 0;
		ret = xbee_conTx( con, &txRet, "AC" );
		if ( ret  != XBEE_ENONE ) {
			fprintf( cgiOut, "txRet[%d], AC failed.\n", txRet );
			return ret;
    	} else {
			usleep(100000); //=0.1 second.
            fprintf( cgiOut, "tx[%d].\n", ret );
	    }
	        
	}//END configuring the module.

	//AT Command = P0     = PWM0 Configuration. Select/Read function for PWM0.
    //
    //    Node Type       = CRE
    //    Parameter Range = 0 - Disabled.
    //                      1 - RSSI PWM Output.
    //                      2 - NA as shown by X-CTU
    //                      3- Digital input, monitored.
    //                      4- Digital output, default low.
    //                      5- Digital output, default high.
    //    Default         = 1
    //fprintf( cgiOut, "Will wait 0.1 second max for P0 response.\n" );
	ret = xbee_conTx( con, &txRet, "P0" );
	if ( ret  != XBEE_ENONE ) {
		fprintf( cgiOut, "txRet[%d], P0 failed.\n", txRet );
		return ret;
	} else {
		usleep(100000); //=0.1 second.
        //fprintf( cgiOut, "tx[%d].\n", ret );
	}

    //AT Command = NI     = Node Identifier. Stores a string identifier. The 
	//    register only accepts printable ASCII data. In AT Command Mode, a
    //    string can not start with a space. A carriage return ends the 
    //    command. Command will automatically end when maximum bytes for the
    //    string have been entered. This string is returned as part of the ND
    //    (Node Discover) command. This identifier is also used with the DN
    //    (Destination Node) command. In AT command mode, an ASCII comma (0x2C)
    //    cannot be used in the NI string
    //    
    //    Node Type       = CRE
    //    Parameter Range = 20-Byte printable ASCII string.
    //    Default         = ASCII space character (0x20)
    
    fprintf( cgiOut, "Will wait 0.1 second max for NI response.\n" );
	ret = xbee_conTx( con, &txRet, "NI" );
	if ( ret  != XBEE_ENONE ) {
		fprintf( cgiOut, "txRet[%d], NI failed.\n", txRet );
		return ret;
	} else {
		usleep(100000); //=0.1 second.
        fprintf( cgiOut, "tx[%d].\n", ret );
	}
    //D0-D8 = Sets the function of the I/O pins on the XBee, such as digital
    //output, input, ADC, RTS, CTS and other.

    //AT Command = D0     = AD0/DIO0 Configuration. Select/Read function for
    //    AD0/DIO0.
    //
    //    Node Type       = CRE
    //    Parameter Range = 1 - Commissioning button enabled
    //                      2 - Analog input, single ended
    //                      3 - Digital input
    //                      4 - Digital output, low
    //                      5 - Digital output, high
    //    Default         = 1
    //fprintf( cgiOut, "Will wait 0.1 second max for D0 response.\n" );
	ret = xbee_conTx( con, &txRet, "D0" );
	if ( ret  != XBEE_ENONE ) {
		fprintf( cgiOut, "txRet[%d], D0 failed.\n", txRet );
		return ret;
	} else {
		usleep(100000); //=0.1 second.
        //fprintf( cgiOut, "tx[%d].\n", ret );
	}

    //AT Command = D1     = AD1/DIO1 Configuration. Select/Read function for
    //    AD1/DIO1.
    //
    //    Node Type       = CRE
    //    Parameter Range = 0, 2-5
    //                      0 – Disabled
    //                      2 - Analog input, single ended
    //                      3 – Digital input
    //                      4 – Digital output, low
    //                      5 – Digital output, high
    //    Default         = 0
    //fprintf( cgiOut, "Will wait 0.1 second max for D1 response.\n" );
	ret = xbee_conTx( con, &txRet, "D1" );
	if ( ret  != XBEE_ENONE ) {
		fprintf( cgiOut, "txRet[%d], D1 failed.\n", txRet );
		return ret;
	} else {
		usleep(100000); //=0.1 second.
        //fprintf( cgiOut, "tx[%d].\n", ret );
	}

    //AT Command = D3     = AD3/DIO3 Configuration. Select/Read function for
    //    AD3/DIO3.
    //
    //    Node Type       = CRE
    //    Parameter Range = 0, 2-5
    //                      0 – Disabled
    //                      2 - Analog input, single ended
    //                      3 – Digital input
    //                      4 – Digital output, low
    //                      5 – Digital output, high
    //    Default         = 0
    //fprintf( cgiOut, "Will wait 0.1 second max for D3 response.\n" );
	ret = xbee_conTx( con, &txRet, "D3" );
	if ( ret  != XBEE_ENONE ) {
		fprintf( cgiOut, "txRet[%d], D3 failed.\n", txRet );
		return ret;
	} else {
		usleep(100000); //=0.1 second.
        //fprintf( cgiOut, "tx[%d].\n", ret );
	}

    //Set D4 LOW/HIGH.
    if ( d4 == 0 ) { //HIGH

        //AT Command = D4     = DIO4 Configuration. Select/Read function for DIO4.
        //
        //    Node Type       = CRE
        //    Parameter Range = 0, 3-5
        //                      0 – Disabled
        //                      3 – Digital input
        //                      4 – Digital output, low
        //                      5 – Digital output, high
        //    Default         = 0
    
        //Set D4 HIGH.
        //fprintf( cgiOut, "Will wait 0.1 second max for D4 HIGH response.\n" );
        needs_response = 0;
	    ret = xbee_conTx( con, &txRet, "D4%c", 5 );
        //ret = xbee_convTx( con, &txRet, "D4 %0x" 4 );
	    if ( ret  != XBEE_ENONE ) {
	    	fprintf( cgiOut, "txRet[%d], D4 5 failed[%s].\n", ret, xbee_errorToStr(ret) );
	    	return ret;
	    } else {
	    	usleep(100000); //=0.1 second.
            //fprintf( cgiOut, "tx[%d].\n", ret );
		}
	
    } else {

        //fprintf( cgiOut, "Will wait 0.1 second max for D4 LOW response.\n" );
        needs_response = 0;
		ret = xbee_conTx( con, &txRet, "D4%c", 4 );
		if ( ret  != XBEE_ENONE ) {
			fprintf( cgiOut, "txRet[%d], D4 4 failed[%s].\n", ret, xbee_errorToStr(ret) );
			return ret;
		} else {
			usleep(100000); //=0.1 second.
            //fprintf( cgiOut, "tx[%d].\n", ret );
		}
    	
    }//END D4 toggle choice
    	
    //Now let's check if it has been toggled HIGH/LOW.
    //fprintf( cgiOut, "Will wait 0.1 second max for D4 response.\n" );
	ret = xbee_conTx( con, &txRet, "D4" );
	if ( ret  != XBEE_ENONE ) {
		fprintf( cgiOut, "txRet[%d], D4 failed.\n", txRet );
		return ret;
	} else {
		usleep(100000); //=0.1 second.
        //fprintf( cgiOut, "tx[%d].\n", ret );
	}
	
	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);
		return ret;
	}

	xbee_shutdown(xbee);

	return 0;
}



//&&&&&&&&&&&&&&&&&&&&&&&& GET TEMPERATURE SENSOR DATA &&&&&&&&&&&&&&&&&&&&&&&&&&&&
int handle_b5()
{
    void *d;
    struct xbee *xbee;
    struct xbee_con *con;
    struct xbee_conAddress address;
    unsigned char txRet;
    xbee_err ret;

    if ((ret = xbee_setup(&xbee, "xbeeZB", "/dev/ttyUSB0", 57600)) != XBEE_ENONE) {
        printf("ret: %d (%s)\n", ret, xbee_errorToStr(ret));
        return ret;
    }

    memset(&address, 0, sizeof(address));
    address.addr64_enabled = 1;

	address.addr64[0] = 0x00;
	address.addr64[1] = 0x13;
	address.addr64[2] = 0xA2;
	address.addr64[3] = 0x00;
                            //0x0013A200408BAE32 or 72
	address.addr64[4] = 0x40;
	address.addr64[5] = 0xBF;
	address.addr64[6] = 0x06;
	address.addr64[7] = 0xB1;

    if ((ret = xbee_conNew(xbee, &con, "Remote AT", &address)) != XBEE_ENONE) {
        xbee_log(xbee, -1, "xbee_conNew() returned: %d (%s)", ret, xbee_errorToStr(ret));
        return ret;
    }

    if ((ret = xbee_conCallbackSet(con, myCBT, NULL)) != XBEE_ENONE) {
        xbee_log(xbee, -1, "xbee_conCallbackSet() returned: %d", ret);
        return ret;
    }

    if ((ret = xbee_conTx(con, &txRet, "IS")) != XBEE_ENONE) {
        xbee_log(xbee, -1, "xbee_conTx() returned: %d", ret);
        return ret;
    }

    usleep(1000000);

    if ((ret = xbee_conEnd(con)) != XBEE_ENONE) {
        xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);
        return ret;
    }

    xbee_shutdown(xbee);

    return 0;
}


//&&&&&&&&&&&&&&&&&&&&&&&& GET LIGHT SENSOR DATA &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
int handle_b6() {
	void *d;
	struct xbee *xbee;
	struct xbee_con *con;
	struct xbee_conAddress address;
	unsigned char txRet;
	xbee_err ret;

	if ((ret = xbee_setup(&xbee, "xbeeZB", "/dev/ttyUSB0", 57600)) != XBEE_ENONE) {
		printf("ret: %d (%s)\n", ret, xbee_errorToStr(ret));
		return ret;
	}

	memset(&address, 0, sizeof(address));
	address.addr64_enabled = 1;
	address.addr64[0] = 0x00;
	address.addr64[1] = 0x13;
	address.addr64[2] = 0xA2;
	address.addr64[3] = 0x00;
	address.addr64[4] = 0x40;
	address.addr64[5] = 0xBF;
	address.addr64[6] = 0x06;
	address.addr64[7] = 0xB1;
	if ((ret = xbee_conNew(xbee, &con, "Remote AT", &address)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conNew() returned: %d (%s)", ret, xbee_errorToStr(ret));
		return ret;
	}
	
	if ((ret = xbee_conCallbackSet(con, myCBL, NULL)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conCallbackSet() returned: %d", ret);
		return ret;
	}
	
	if ((ret = xbee_conTx(con, &txRet, "IS")) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conTx() returned: %d", ret);
		return ret;
	}

	usleep(1000000);
	
	
	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);
		return ret;
	}

	xbee_shutdown(xbee);

	return 0;
}

//####################### SEND FILE #############################
int handle_b7()
{
	struct xbee *xbee;
	struct xbee_con *con;
	struct xbee_conAddress address;
	xbee_err ret;
	int nofilespec = 0;
	int size;
	char contentType[1024];
	int fopenissue = 0;

	//fprintf( cgiOut, "line[%d]..................functionname[%s]\n", __LINE__, __func__ );

	//printf( "1..................name[%s]\n",name );

	if( cgiFormFileName("file", name, sizeof(name)) != cgiFormSuccess )
	{
		printf("<p>No file was uploaded.<p>\n");
		nofilespec = 1;
    	}
	if(!nofilespec)
	{
		fprintf( cgiOut, "File sent: " );
	        cgiHtmlEscape( name );
	        fprintf( cgiOut, "<p>\n" );
	        cgiFormFileSize( "file", &size );
	        fprintf( cgiOut, "The file size is: %d bytes<p>\n", size );
	        cgiFormFileContentType( "file", contentType, sizeof(contentType) );
	        fprintf( cgiOut, "File type: " );
	        cgiHtmlEscape(contentType);
	        fprintf( cgiOut, "<p>\n");
	        fprintf(cgiOut, "Number of chunks being sent: %d\n<p>", size / MAX_PAYLOAD_BYTES);
	        
	    	if ((ret = xbee_setup(&xbee, "xbeeZB", "/dev/ttyUSB0", 57600)) != XBEE_ENONE) {
			printf("ret: %d (%s)\n", ret, xbee_errorToStr(ret));
			return ret;
		}
		
		//Set static address of the remote node
		memset(&address, 0, sizeof(address));
		address.addr64_enabled = 1;
		address.addr64[0] = 0x00;
		address.addr64[1] = 0x13;
		address.addr64[2] = 0xA2;
		address.addr64[3] = 0x00;
		//address.addr64[4] = 0x40;
		//address.addr64[5] = 0x8B;
		//address.addr64[6] = 0xAE;
		//address.addr64[7] = 0x72;

	address.addr64[4] = 0x40;
	address.addr64[5] = 0xBF;
	address.addr64[6] = 0x06;
	address.addr64[7] = 0xED;


		//printf( "2..................name[%s]\n",name );
		if ((ret = xbee_conNew(xbee, &con, "Data", &address)) != XBEE_ENONE) {
			xbee_log(xbee, -1, xbee_errorToStr(ret));
			return ret;
		}
	
		if ((ret = xbee_conDataSet(con, xbee, NULL)) != XBEE_ENONE) {
			xbee_log(xbee, -1, xbee_errorToStr(ret));
			return ret;
		}
	
		if ((ret = xbee_conCallbackSet(con, myCB_sendFile, NULL)) != XBEE_ENONE) {
			xbee_log(xbee, -1, xbee_errorToStr(ret));
			return ret;
		}
		
		if( cgiFormFileOpen("file", &file) != cgiFormSuccess ) 
	        {
		        fprintf( cgiOut, "Could not open the file.<p>\n" );
		        fopenissue = 1;
	        }
		
		//printf( "3..................name[%s]\n",name );

	        if(!fopenissue)
	        {
	    		init_send_file( name, xbee, con );
	    		send_file( name, xbee, con );
	    	}
	}
	cgiFormFileClose(file);
	return 0;
}


//######################### RECEIVE FILE ###########################
int handle_b8()
{
	struct xbee *xbee;
	struct xbee_con *con;
	struct xbee_conAddress address;
	xbee_err ret;
	
	fprintf( cgiOut, "line[%d]..................functionname[%s]\n", __LINE__, __func__ );

	if ((ret = xbee_setup(&xbee, "xbeeZB", "/dev/ttyUSB1", 57600)) != XBEE_ENONE) {
		printf("ret: %d (%s)\n", ret, xbee_errorToStr(ret));
		return ret;
	}

	// address of remote server module
	memset(&address, 0, sizeof(address));
	address.addr64_enabled = 1;
	address.addr64[0] = 0x00;
	address.addr64[1] = 0x13;
	address.addr64[2] = 0xA2;
	address.addr64[3] = 0x00;
	address.addr64[4] = 0x40;
	address.addr64[5] = 0x8B;
	address.addr64[6] = 0xAD;
	address.addr64[7] = 0x2D;


	fprintf( cgiOut, "line[%d]..................functionname[%s]\n", __LINE__, __func__ );

	if ((ret = xbee_conNew(xbee, &con, "Data", &address)) != XBEE_ENONE) {
		//xbee_log(xbee, -1, "xbee_conNew() returned: %d (%s)", ret, xbee_errorToStr(ret));
		xbee_log(xbee, -1, xbee_errorToStr(ret));
		return ret;
	}

	if ((ret = xbee_conDataSet(con, xbee, NULL)) != XBEE_ENONE) {
		//xbee_log(xbee, -1, "xbee_conDataSet() returned: %d", ret);
		xbee_log(xbee, -1, xbee_errorToStr(ret));
		return ret;
	}

	//printf( "2..................[%s]\n","/dev/ttyUSB1" );

	if ((ret = xbee_conCallbackSet(con, myCB_receiveFile, NULL)) != XBEE_ENONE) {
		//xbee_log(xbee, -1, "xbee_conCallbackSet() returned: %d", ret);
		xbee_log(xbee, -1, xbee_errorToStr(ret));
		return ret;
	}
	
	//printf("<p>Waiting to receive files...<p>");
	for(;;)
	{
	/*This for loop is what makes the client wait forever to receive files. Must stop 
	  process with CTRL+C to free the resource.*/
	}
	
	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) {
		//xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);
		xbee_log(xbee, -1, xbee_errorToStr(ret));
		return ret;
	}

	//printf( "3..................[%s]\n","/dev/ttyUSB1" );

	xbee_shutdown(xbee);
	
	return 0;
}


//&&&&&&&&&&&&&&&&&&&&&&&& HTML FORM DISPLAY &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
void ShowForm()
{
  fprintf( cgiOut, "<form method=\"POST\" enctype=\"multipart/form-data\" ");
  fprintf( cgiOut, " action=\"");
  cgiValueEscape(cgiScriptName);
  fprintf( cgiOut, "\">\n");

  //Set up the buttons:
  //B1 = Get Connected Device ID
  //B2 = Get Remote Device ID
  //B3 = Toggle Light On/Off
  //B4 = Refresh
  //B5 = Get Temperature Data
  //B6 = Get Light Sensor Data
  //B7 = Send File
  //B8 = Receive File
  fprintf( cgiOut, "\n");
  fprintf( cgiOut, "<input type=\"submit\" name=\"b1\" value=\"Get Connected Device ID\">\n");
  fprintf( cgiOut, "<p>\n" );  

  fprintf( cgiOut, "<input type=\"submit\" name=\"b2\" value=\"Get Remote Device ID\">\n");
  fprintf( cgiOut, "<p>\n" );  

  fprintf( cgiOut, "<input type=\"submit\" name=\"b3\" value=\"Toggle ON/OFF\">\n");
  fprintf( cgiOut, "<p>\n" );  

  fprintf( cgiOut, "<input type=\"submit\" name=\"b4\" value=\"Refresh\">\n");
  fprintf( cgiOut, "<p>\n" );

  fprintf( cgiOut, "<input type=\"submit\" name=\"b5\" value=\"Get Temperature Data\">\n");
  fprintf( cgiOut, "<p>\n");

  fprintf( cgiOut, "<input type=\"submit\" name=\"b6\" value=\"Get Light Sensor Data\">\n");
  fprintf( cgiOut, "<p>\n");
  
  fprintf( cgiOut, "<input type=\"file\" name=\"file\" value=\"\">\n");
  fprintf( cgiOut, "<input type=\"submit\" name=\"b8\" value=\"Receive File\">\n");
  fprintf( cgiOut, "<input type=\"submit\" name=\"b7\" value=\"Send File\">\n");
  fprintf( cgiOut, "<p>\n");

  fprintf( cgiOut, "</form>\n" );

}
