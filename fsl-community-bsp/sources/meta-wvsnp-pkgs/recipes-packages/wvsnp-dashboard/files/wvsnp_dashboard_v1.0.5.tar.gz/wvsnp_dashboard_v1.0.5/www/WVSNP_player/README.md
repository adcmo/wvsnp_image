WVSNP HTML5 Media Player
====================================================

HTML5 Media Player to play back video streams natively in the browser in a DASH-like segmented format.
The video is segmented into several short video-segments (e.g. 2, 5, or 10 seconds) and then stitched together
by Javascript to create a continuous video stream.

It also supports HLS, and by using the external JS-library dash.js, browsers supporting
Media Source Extensions are able to play back MPEG-DASH.
https://github.com/Dash-Industry-Forum/dash.js/

The (core) player will work pluginfree in every browser that supports key features of HTML5:
- Video playback
- Javascript Filesystem API [1]
- Blob URLs / File API [2]
- Canvas

[1] third party libraries provide wrappers for WebSQL and IndexedDB
* http://dev.w3.org/2009/dap/file-system/pub/FileSystem/
* https://developer.mozilla.org/en/IndexedDB
**	https://github.com/ebidel/idb.filesystem.js/
* http://www.w3.org/TR/webdatabase/
**	https://github.com/axemclion/IndexedDBShim
[2] including video-playback from Blob URLs


Supported Browsers
--------------------

Although almost all browsers support the required HTML5 features in general, the support for the WVSNP
core player is limited to these browsers:

* Google Chrome 20+
* Mozilla Firefox 11+
* Chromium for Android Revision 247699+[1]
* Internet Explorer 11

Additionally, support for HLS enables Safari on Mac OSX and iOS, as well as some recent Android 4.X devices.

[1] http://commondatastorage.googleapis.com/chromium-browser-continuous/Android/247725/chrome-android.zip




Known Restrictions
====================================================

Internet Explorer 11
--------------------
Internet Explorer supports IndexedDB, therefore a wrapper for Filesystem API is working.
However, the support still is not satisfying yet, as the player freezes randomly.
Furthermore, IE11 should support Media Source Extensions for playback of MPEG-DASH using dash.js, but
not in Windows 7.
http://msdn.microsoft.com/en-us/library/ie/dn254959%28v=vs.85%29.aspx


Android
--------------------
Google Chrome for Android does not work with the player right now, as there is a bug that prevents
videos being played back from Blob URLs:
http://code.google.com/p/chromium/issues/detail?id=253465

This issue has been solved in Chromium - however, as of now it is only available as Nightly Build:
* Chromium Nightly Build, Revision 245108
* http://src.chromium.org/viewvc/chrome?view=revision&revision=245108
* http://commondatastorage.googleapis.com/chromium-browser-continuous/Android/245199/changelog.xml
* http://commondatastorage.googleapis.com/chromium-browser-continuous/Android/245199/chrome-android.zip

Furthermore, Android does not seem to be able to draw frames from a hidden video element to a canvas.
This issue has lead to the problem that full-screen mode was not supported and the transitions between
videos were not very smooth due to flickering caused by resizing video-elements
* Bug reports:
* http://code.google.com/p/chromium/issues/detail?id=309162
* http://code.google.com/p/chromium/issues/detail?id=306339
* http://jsbin.com/IQANIZe/1/

Bugreports say the issue should have been fixed, however, tests revealed that is still has issues that
need workarounds.
* http://src.chromium.org/viewvc/chrome?view=revision&revision=247334
* http://src.chromium.org/viewvc/chrome?view=revision&revision=247699
* http://commondatastorage.googleapis.com/chromium-browser-continuous/index.html?path=Android/247725/
* http://commondatastorage.googleapis.com/chromium-browser-continuous/Android/247725/chrome-android.zip


Safari
--------------------
Safari has the same issue as Android, it is not able to play back videos from Blob URLs
https://bugs.webkit.org/show_bug.cgi?id=101671

Furthermore, on a related note, Safari for Windows seems to be discontinued, it does not work with
WVSNP at all. Safari on iOS and Mac OSX have support for HLS, Windows however does not have Quicktime-X,
so HLS will not work either.
* http://www.howtogeek.com/132602/safari-for-windows-is-probably-dead-how-to-migrate-to-another-browser/