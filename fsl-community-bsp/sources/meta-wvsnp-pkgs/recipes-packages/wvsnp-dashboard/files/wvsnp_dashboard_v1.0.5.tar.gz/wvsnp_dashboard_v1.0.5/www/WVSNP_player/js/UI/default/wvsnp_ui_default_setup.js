Player_UI.prototype.setupNativeVideo = function (that, srcString, mpegDash) {
/*  ignore playback option for HLS- until later developed
*   reload playlist regularily from server for live HLS
    if(that.play_back_option=="LIVE"){
      that.createDirectory(that, that.video_id, "LIVE_vod");
    }
*/	
	
	that.logger('Source String: ' + srcString);
	
	var wrapper = document.createElement('div');
	var newAttr = document.createAttribute('class');
	newAttr.nodeValue = 'player_wrapper';
	wrapper.setAttributeNode(newAttr);

	var newAttr = document.createAttribute('id');
	newAttr.nodeValue = 'player_wrapper_' + that.video_id;
	wrapper.setAttributeNode(newAttr);

	var newAttr = document.createAttribute('id');
	newAttr.nodeValue = 'player_video_' + that.video_id;
	that.video.setAttributeNode(newAttr);
	that.video.removeAttribute('controls');

	// no controls needed, as they will be included natively by iOS
	var video_template = '<input type="text" id="dynamic_source_input_' + that.video_id + '" size=60px value="Enter dynamic source input here" >' + '<button id="source_button_' + that.video_id + '" type="button">Submit</button><br><div style="font-size: 9px">Playing back: ' + srcString + '</div>';
	video_template += '<video id="video_' + that.video_id + '" src="' + srcString + '" controls ></video>';
	wrapper.innerHTML = video_template;

	// check if called
	var current_wrapper_element = (that.ui.html_setup ? document.getElementById('player_wrapper_' + that.video_id) : that.video);

	current_wrapper_element.parentNode.replaceChild(wrapper, current_wrapper_element);
	// TODO: change width and height by applying css (aspect ratio)
	// https://gist.github.com/jimjeffers/1219207
	//document.getElementById("video_" + that.video_id).width = that.ui.w;
	//document.getElementById("video_" + that.video_id).height = that.ui.h;
	document.getElementById('player_wrapper_' + that.video_id).style.marginBottom = "0px";

	//! event to dynamically get source input from text field and call function
	document.getElementById("source_button_" + that.video_id).addEventListener('click', function () {
		that.ui.dynamicSourceInput(that);
	});
	//! focus-event for dsource input field, remove value
	document.getElementById("dynamic_source_input_" + that.video_id).addEventListener('focus', function () {
		that.ui.DSI_focus(that);
	});

	/*
	* ---------
	* setup of MPEG-DASH
	* using dash.js - DOES NOT WORK??
	* ----------
	*/
	/*if(mpegDash)
	{
		console.log('SETUP MPEG-DASH SOURCE: ' + srcString);
		// see example
		// http://msopentech.com/blog/2014/01/03/streaming_video_player/
		var context = new Dash.di.DashContext();
		var player = new MediaPlayer(context);
		player.startup();
		player.attachView(document.getElementById("video_" + that.video_id));
		player.attachSource(srcString);
	}*/
	
	
	/*
	* ---------
	* setup of MPEG-DASH
	* using DASH-JS
	* ----------
	*/
	if(mpegDash) {
		var dashPlayer = new DASHPlayer(document.getElementById("video_" + that.video_id), srcString);
	}

}

/** @brief A function that creates the html template for each video object
 * 
 * 
 * 
 * .............................................................................
 */
Player_UI.prototype.setup = function (that) {

	// NOTE: creation of directory is now done in parseVideoSource by initFilesystem.
	// we only want (mostly) encapsulated UI functionality here

	//!> BEGIN HTML_SETUP
	//!> If html has been setup we dont need to do it again.
	if (that.ui.html_setup == false) {
		that.ui.html_setup = true;

		var wrapper = document.createElement('div');
		wrapper.setAttribute('class', 'player_wrapper');
		wrapper.setAttribute('id', 'player_wrapper_' + that.video_id);
		
		// TODO: create this using DOM? might look more professional, but also more confusing. What about performance?
		that.template = '<div id="dynamic_source_wrapper_' + that.video_id + '"><input type="text" id="dynamic_source_input_' + that.video_id + '" size=60px value="Enter dynamic source input here" >' + '<button id="source_button_' + that.video_id + '" type="button">Submit</button></div>'
		+ '<div style="font-size: 9px;" id="current_playback_segment">' + that.video_src_string + '</div>'
		// canvas used to switch between both videos
		// temp div that contains all temporary video-elements
		+ '<div id="wvsnp_temp_video_elements_' + that.video_id + '" style="z-index: 500; overflow: visible; height: 1px; width: 1px">'
			// two video elements
			// workaround for Android: as the picture of a video can only be drawn to a canvas-context, if the video is visible, they need to be in the frame
			// fortunately it works if they are just 1x1 pixel and have an opacity of 0.01
			+ '<video class="wvsnp_video_element" id="wvsnp_video1_' + that.video_id + '" src="' + that.video_src_string + '"'
				// only do that on Android, save CPU load for drawing the picture on Desktop
				+ (detectedOS == "Android" ? ' style="visibility: visible; opacity: 0.01; z-index: 510;"' : ' style="display: none"')
				// only do that on Android, save CPU load for drawing the picture on Desktop
			+ '></video>' + '<video class="wvsnp_video_element" id="wvsnp_video2_' + that.video_id + '" src="' + that.video_src_string + '"'
				+ (detectedOS == "Android" ? ' style="visibility: visible; opacity: 0.01; z-index: 510;"' : ' style="display: none"')
			+ '></video>'
		+ '</div>'
		+ '<canvas class="wvsnp_canvas_element" id="wvsnp_canvas_' + that.video_id + '" style="position: relative; z-index: 0; cursor: pointer"></canvas>'
		// temp video element used during loading to check segment-length
		+ '<video id="check_buffered_duration_' + that.video_id + '" hidden="true"></video>'
		// controls
		+ '<div class="video_controls" id="video_controls_' + that.video_id + '" >'
			+ '<div class="progress" id="progress_' + that.video_id + '" role="slider" aria-valuemin="0" aria-valuemax="0" aria-valuenow="0" style="float: none">' + '<div class="load_progress" id="load_progress_' + that.video_id + '"></div>' + '<div class="play_progress" id="play_progress_' + that.video_id + '"></div>' + '<span class="timebar_status" id="timebar_status_' + that.video_id + '"></span>' + '</div>'
			+ '<div class="play_div" id="play_div_' + that.video_id + '">' + '<button class="play_toggle" id="play_toggle_' + that.video_id + '" ><img class="play_toggle_img" id="play_toggle_img_' + that.video_id + '" title="Play" /></button>' + '</div>'
			+ '<div class="volumectrl_div" id="volumectrl_div_' + that.video_id + '">' + '<button class="volumectrl_btn" id="volumectrl_btn_' + that.video_id + '" ><img class="volumectrl_img" id="volumectrl_img_' + that.video_id + '" title="Volume" /></button>' + '</div>'
			+ '<div class="live_div" id="live_div_' + that.video_id + '">' + '<button class="live_toggle" id="live_toggle_' + that.video_id + '" >Live</button>' + '</div>'
			+ '<div class="time" id="time_' + that.video_id + '" role="timer">' + '<span class="current_time" id="current_time_' + that.video_id + '">00:00</span> / ' + '<span id="duration_' + that.video_id + '">00:00</span></div>'
			+ '<div class="settingsctrl_div" id="settingsctrl_div_' + that.video_id + '">' + '<button class="settingsctrl_btn" id="settingsctrl_btn_' + that.video_id + '" >' + '<img class="settingsctrl_img" id="settingsctrl_img_' + that.video_id + '" title="Settings" />' + '</button>' 
				+ '<div class="settingsctrl_popover" id="settingsctrl_popover_' + that.video_id + '">'
					+ '<div class="settingsctrl_popover_quality" id="settingsctrl_popover_quality_' + that.video_id + '" style="float: left"></div>'
					+ '<div class="settingsctrl_popover_hls" id="settingsctrl_popover_hls_' + that.video_id + '" style="float: left"></div>'
					+ '<p style="clear: both"></p>'
				+ '</div>'
			+'</div>'
			// do not show full-screen button on Android
			+ (that.ui.has_canvas ? '<div class="fullscreen_div" id="fullscreen_div_' + that.video_id + '">' + '<button class="fullscreen_btn" id="fullscreen_btn_' + that.video_id + '" >' + '<img class="fullscreen_img" id="fullscreen_img_' + that.video_id + '" title="Fullscreen" />' + '</button>' + '</div>' : '')
		+ '</div>';
		wrapper.innerHTML = that.template;
		//! Replace the video element in the html file with the wrapper.
		that.video.parentNode.replaceChild(wrapper, that.video);
		
		that.ui.resetPlayerControls(that);
		that.ui.setupSettingsMenu(that);

		//! event to dynamically get source input from text field and call function
		document.getElementById("source_button_" + that.video_id).addEventListener('click', function () {
			that.ui.dynamicSourceInput(that);
		}, false);
		//! focus-event for dsource input field, remove value
		document.getElementById("dynamic_source_input_" + that.video_id).addEventListener('focus', function () {
			that.ui.DSI_focus(that);
		}, false);

		//! event that waits on the first play click to initialize the video stream
		document.getElementById("play_toggle_" + that.video_id).addEventListener('click', that.ui.init_player_trigger, false);
		document.getElementById("wvsnp_canvas_" + that.video_id).addEventListener('click', that.ui.init_player_trigger, false);

		//! event that waits on the first play click to initialize the video stream
		document.getElementById("settingsctrl_btn_" + that.video_id).addEventListener('click', function (e) {

			var settingsPopover = document.getElementById('settingsctrl_popover_' + that.video_id);
			var settingsPopoverQuality = document.getElementById('settingsctrl_popover_quality_' + that.video_id);
			settingsPopover.style.visibility = (settingsPopover.style.visibility == 'visible' ? 'hidden' : 'visible');
			
			settingsPopover.style.top = - (settingsPopoverQuality.offsetHeight) + "px";
		}, false);
	}
	//!> END HTML_SETUP
}

Player_UI.prototype.setupSettingsMenu = function (that) {

	var settingsPopover = document.getElementById('settingsctrl_popover_' + that.video_id);
	var settingsPopoverQuality = document.getElementById('settingsctrl_popover_quality_' + that.video_id);
	var settingsPopoverHls = document.getElementById('settingsctrl_popover_hls_' + that.video_id);
	
	/*
	// setup quality
	*/
	settingsPopoverQuality.appendChild(document.createTextNode('Quality:'));
	settingsPopoverQuality.appendChild(document.createElement('p'));
	
	for(var n = that.pres_int_max; n >= that.pres_int_min; n--)
	{
		var currentQualitySelection = document.createElement('button');
		currentQualitySelection.className = 'quality_selection_button ' + (that.v_quality == n ? 'quality_selection_button_active' : '');
		currentQualitySelection.setAttribute('id', 'player_' + that.video_id + '_quality_' + n);
		currentQualitySelection.appendChild(document.createTextNode(n + (n == that.pres_int_max ? ' (High)' : '') + (n == that.pres_int_min ? ' (Low)' : '')));
		
		//! event that waits on the first play click to initialize the video stream
		currentQualitySelection.addEventListener('click', 
			(function(newQuality) {
				return function(e) {
					that.v_quality = newQuality;
					for(var x = 0; x <= that.pres_int_max; x++) {
						document.getElementById('player_' + that.video_id + '_quality_' + x).className = 'quality_selection_button ' + (newQuality == x ? 'quality_selection_button_active' : '');
					}
					
					// TODO: move this to somewhere else? forward this call to ff_rw, maybe and trigger redownload?
					that.writer_video_index = Math.min(Math.min(that.writer_video_index, that.video_to_play_index + 1), that.last_index);
					that.buffering.buffered_file_duration = that.segment_end_time[that.writer_video_index];
					that.max_duration = that.buffering.buffered_file_duration;
					that.currentSegmentLoaded = that.writer_video_index;
					that.calculateBufferStatusBar(that);
					for(var j = that.writer_video_index; j <= that.last_index; j++) {
						that.segment_quality[j] = newQuality;
					}
					// reload segments with new chosen quality
					that.buffering.checkBuffer(that, that.writer_video_index);
				};
			})(n), true);
		
		settingsPopoverQuality.appendChild(currentQualitySelection);
	}
	
	/*
	// draw first frame of video to the canvas (looks nicer than a black screen)
	*/
	setTimeout(function() {
		var context = document.getElementById("wvsnp_canvas_" + that.video_id).getContext("2d");
		context.save();
		context.globalAlpha = 0.7;
		context.drawImage(that.ui.getDesignatedVideoElement(that, that.first_index), 0, 0, that.ui.w, that.ui.h);
		
		var temp_image = document.createElement('img');
		temp_image.src = that.ui.base64images.big_play_button;
		// put the "play button" in the center, half dimensions 130/130
		// subtract 53 in y-dimension since canvas is 53px smaller than that.ui.h
		context.drawImage(temp_image, (that.ui.w/2)-65, (that.ui.h/2)-65-27);
		
		context.restore();
		context.globalAlpha = 1.0;
		that.ui.getDesignatedVideoElement(that, that.first_index).src = '';
		that.ui.getDesignatedVideoElement(that, that.first_index+1).src = '';
		
	}, 1000);
}

Player_UI.prototype.resetPlayerControls = function (that) {

	document.getElementById('player_wrapper_' + that.video_id).style.height = (that.ui.h) + 'px';
	document.getElementById('player_wrapper_' + that.video_id).style.width = (that.ui.w) + 'px';
	document.getElementById("wvsnp_canvas_" + that.video_id).height = (that.ui.h) - 53;
	document.getElementById("wvsnp_canvas_" + that.video_id).width = (that.ui.w);
	document.getElementById('video_controls_' + that.video_id).style.height = '53px';
	document.getElementById('video_controls_' + that.video_id).style.width = (that.ui.w) + 'px';
	document.getElementById('video_controls_' + that.video_id).style.webkitBorderTopLeftRadius = "0px";
	document.getElementById('video_controls_' + that.video_id).style.webkitBorderTopRightRadius = "0px";
	document.getElementById('video_controls_' + that.video_id).style.BorderTopLeftRadius = "0px";
	document.getElementById('video_controls_' + that.video_id).style.BorderTopRightRadius = "0px";
	
	that.ui.progress_w = (that.ui.w - 24);
	document.getElementById('progress_' + that.video_id).style.width = that.ui.progress_w + 'px';
	document.getElementById('progress_' + that.video_id).style.marginTop = "0px";
	document.getElementById('progress_' + that.video_id).style.marginLeft = "12px";
	document.getElementById('progress_' + that.video_id).style.marginRight = "12px";
	document.getElementById('progress_' + that.video_id).style.marginBottom = "8px";
	document.getElementById('progress_' + that.video_id).style.top = "8px";
	
	document.getElementById('volumectrl_div_' + that.video_id).style.marginTop = "0px";
	document.getElementById('settingsctrl_div_' + that.video_id).style.marginTop = "0px";
	document.getElementById('play_div_' + that.video_id).style.marginTop = "0px";
		
	if(that.ui.has_canvas)
	{
		//! Loads full screen image 
		document.getElementById("fullscreen_img_" + that.video_id).src = that.ui.base64images.fullscreen_control;
		document.getElementById('fullscreen_div_' + that.video_id).style.marginTop = "0px";
	}
	//! Loads the play image on play_toggle
	document.getElementById("play_toggle_img_" + that.video_id).src = that.ui.base64images.play_control;
	//! Loads the volume control image
	document.getElementById("volumectrl_img_" + that.video_id).src = that.ui.base64images.volume_control;
	//! Loads the settings image on settingsctrl_img
	document.getElementById("settingsctrl_img_" + that.video_id).src = that.ui.base64images.settings_control;
}

Player_UI.prototype.DSI_focus = function (that) {
	document.getElementById("dynamic_source_input_" + that.video_id).value = "";
}


Player_UI.prototype.initEventListeners = function (that) {

	//!Listener for the play and pause button
	document.getElementById("play_toggle_" + that.video_id).addEventListener('click', function (e) {
		that.playPauseButton(that, that.video_to_play_index);
	}, false);
			
	//! clicking on the canvas should have the same effect
	document.getElementById("wvsnp_canvas_" + that.video_id).addEventListener('click', function (e) {
		that.playPauseButton(that, that.video_to_play_index);
	}, false);
	
	document.getElementById("progress_" + that.video_id).addEventListener('click', function (e) {
		that.logger("rw ff clicked");
		if (that.segment_transition == false) {
			that.rewindFastForward(that, e, that.writer_video_index);
		} else {
			setTimeout(function () {
				that.rewindFastForward(that, e, that.writer_video_index);
			}, 300);
		}
	}, false);
	//!Listener for notice timecode on an mousemove event over the progress bar
	document.getElementById("timebar_status_" + that.video_id).parentNode.addEventListener('mousemove', function (e) {
		that.noticeTimecode(that, e)
	}, false);
	//!Listener that shows the full screen video controls on mouseover
	document.getElementById("video_controls_" + that.video_id).addEventListener('mouseover', function (e) {
		//that.mouseEnter(that, that.ui.showPopup(that));
		that.ui.showPopup(that);
	}, false);
	//!Listener that which hides the full screen video controls on mouseout
	document.getElementById("video_controls_" + that.video_id).addEventListener('mouseout', function (e) {
		//that.mouseEnter(that, that.ui.hidePopup(that));
		that.ui.hidePopup(that);
	}, false);
	// if we are using the canvas-version, add listener for fullscreen-toggle
	// the non-canvas version does not support fullscreen
	if(that.ui.has_canvas)
	{
		//!Listener for the full screen function
		document.getElementById('fullscreen_btn_' + that.video_id).addEventListener('click', function (e) {
			that.ui.fullscreen(that);
		}, false);
	}
	//!Listener for the exit_function
	window.addEventListener('pagehide', function() { that.exitFunction(that); }, false);
	//!Listener to end the full screen mode
	// webkit
	window.addEventListener('webkitfullscreenchange', function (e) {
		that.logger("webkitfullscreenchange called = " + document.webkitIsFullScreen);
		if (document.webkitIsFullScreen == false && that.ui.is_fullscreen == true) {
			that.ui.fullscreen(that);
	}
	}, false);
	// no prefix
	window.addEventListener('fullscreenchange', function (e) {
		that.logger("fullscreenchange called = " + document.fullScreen);
		if (document.fullscreen == false && that.ui.is_fullscreen == true) {
			that.ui.fullscreen(that);
		}
	}, false);
	// mozilla
	window.addEventListener('mozfullscreenchange', function (e) {
		that.logger("mozfullscreenchange called = " + document.mozFullScreen);
		if (document.mozFullScreen == false && that.ui.is_fullscreen == true) {
			that.ui.fullscreen(that);
		}
	}, false);
	document.getElementById("live_toggle_" + that.video_id).addEventListener('click', function (e) {
		var mod_play_index = that.getVideoToPlayIndex(that);
		var play_index = that.calcRealToPlayIndex(that, mod_play_index);
		that.liveRewindFastForward(that, 9999999, 0, 0, false, 0, mod_play_index, play_index);
	}, true);
}