/** @brief initialises the file-system. In this case, 
 * will trigger the creation of the directory on the file-system.
 * moved outside from setup-function, as this has nothing to do with UI
 */
Player.prototype.initFilesystem = function (that) {
    that.createDirectory(that, that.video_id, that.play_back_option);
    if(that.play_back_option == "LIVE"){
      that.createDirectory(that, that.video_id, "LIVE_vod");
    }
}

Player.prototype.checkForLocalFile = function (that, a_writer_video_index, successCallback, failCallback) {

	// index with wrap-around (in case of LIVE-video?)
	var temp_i = a_writer_video_index % (that.last_index - that.first_index + 1);
	temp_i = (temp_i < that.first_index ? that.first_index : temp_i);
	that.segment_quality[a_writer_video_index] = that.v_quality;
	// TODO: maybe save files in a directory called after the video-name instead of video-id? so a different player-id still will find the videos?
	var file_name = that.play_back_option + "_" + that.video_id + "/" + that.getFileNameForQuality(that, that.segment_quality[a_writer_video_index]) + a_writer_video_index + "." + that.v_container;

	if(that.play_back_option != "LIVE") {
		// if it is VOD stream, first check if video exists already
		window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function (fs) {
			fs.root.getFile(file_name, {}, function (fileEntry) {
				if (fileEntry.isFile === true) {
					// file exists already, no need to re-download it
					// directly move forward to capture its duration
					fileExists = true;
					that.readFileRequest(that, a_writer_video_index, true, function() {
						that.startPlayingAndWaitForVideo(that, document.getElementById("check_buffered_duration_" + that.video_id), successCallback, failCallback);
					});
				}
				else
					failCallback();
			}, failCallback);
		});
	}
	else {
		failCallback();
	}
}

/** @brief Creates a directory in the sandbox for the video object
 * 
 * A function that creates a directory in the sandbox for the video object. Its
 * name is based on the video_id and a_playback_option parameters that are 
 * passed to it. More specifically, the directory name will be 
 * [a_playback_option]_[video_id]
 * 
 * @param video_id - the unique id number denoted to each video object used to 
 * identify the directory.
 * 
 * @param a_play_back_option - playback mode or option used to name the directory
 * 
 * .............................................................................
 */
Player.prototype.createDirectory = function (that, video_id, a_play_back_option) {

	// NOTE: this would remove the directory, if existing, to minimise interference with existing files.
	// But right now, we WANT existing files and directory for bootstrap speed-up and reduced network-load.
	/*// create directory if not existing
	window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function (fs) {
		fs.root.getDirectory(
			a_play_back_option + "_" + video_id,
			{},
			function (dirEntry) {
				dirEntry.removeRecursively(function() {
					that.logger('Directory removed, now recreating');

					fs.root.getDirectory(
						a_play_back_option + "_" + video_id,
						{create: true},
						function (dirEntry_inner) {
							that.logger("Dir created (callback) " + a_play_back_option + "_" + video_id);
						},
						error_handler
					);

				});
			},
			error_handler
		);
	}, error_handler);*/

	// in case the directory did not exist, above will produce an error,
	// so to be sure, create the directory again
	// create directory if not existing
	window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function (fs) {
		fs.root.getDirectory(
			a_play_back_option + "_" + video_id,
			{create: true},
			function (dirEntry) {
				that.logger("Dir created (outer loop) " + a_play_back_option + "_" + video_id);
			},
			error_handler
		);
	}, error_handler);
}

Player.prototype.copyFile = function (that, cwd, src, dest) {
	cwd.getFile(src, {}, function (fileEntry) {
		cwd.getDirectory(dest, {}, function (dirEntry) {
			fileEntry.copyTo(dirEntry);
		}, error_handler);
	}, error_handler);
}

//function copies segment from live file to live_vod by calling file_copy function
Player.prototype.copyToLiveVOD = function (that, src, dest) {
	that.logger("copy_to_live_vod called " + src);
	window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function (fs) {
		that.copyFile(that, fs.root, src, dest);
	}, error_handler);

}

Player.prototype.createVideoRequest = function(that, filename, callback) {
	var xhr = new XMLHttpRequest();
	xhr.open("GET", filename, true);
	xhr.setRequestHeader("pragma", "no-cache");
	xhr.responseType = "blob";
	xhr.addEventListener("load", function() {
		if(4 == this.readyState && 200 == this.status) {
			callback();
		}
	}, false);
	xhr.send();
	
	return xhr;
}

/** @brief Requests a temporary file and calls the nested XHR_file_writer function
 * 
 * A function to request, a temporary file to be stored on the client file system.  
 * Once requested, it calls the nested function XHR_file_writer.
 *
 * @param a_writer_video_index - index for segment to load/write
 * @param overwrite - if specified and true, will load the segment and overwrite it, even if it exists (e.g. if the file is corrupted and won't start)
 * .............................................................................
 */
Player.prototype.triggerFileDownload = function (that, a_writer_video_index, overwrite) {

	that.currentSegmentLoaded = a_writer_video_index;

	// index with wrap-around (in case of LIVE-video?)
	var temp_i = a_writer_video_index % (that.last_index - that.first_index + 1);
	temp_i = (temp_i < that.first_index ? that.first_index : temp_i);
	that.segment_quality[a_writer_video_index] = that.v_quality;
	// TODO: maybe save files in a directory called after the video-name instead of video-id? so a different player-id still will find the videos?
	var file_name = that.play_back_option + "_" + that.video_id + "/" + that.getFileNameForQuality(that, that.segment_quality[a_writer_video_index]) + a_writer_video_index + "." + that.v_container;
	
	// flag whether or not the file exists already on filesystem (also, in this particular quality)
	// if so, no need to re-download it
	var fileExists = false;
	
	/**@brief Makes a XMLHttpRequest and stores file locally
	 * 
	 * A nested function that makes a XMLHttpRequest (XHR). The XHR gets a video 
	 * segment, which is then stored as the local file.
	 * 
	 * ...........................................................................
	 */
	function XHR_file_writer(fs) {
	
		//that.logger('Now downloading: ' + a_writer_video_index);
	
		fs.root.getFile(file_name, {create: true}, function (fileEntry) {

			fileEntry.createWriter(function (fileWriter) {
				fileWriter.onwriteend = function (e) {
					
					//copy live video to live_vod folder if 
					if (that.play_back_option == "LIVE") { // && that.live_episode == that.play_episode){            
						var buffer_ep = Math.floor(a_writer_video_index / (that.last_index - that.first_index + 1)) + 1;
						//that.logger("writer_index = " + a_writer_video_index + ' buffer_episode = ' + buffer_ep + ' play episode = ' + that.play_episode);
						if (buffer_ep == that.play_episode) {
							that.logger("copy to live_vod called from file_writer, index " + a_writer_video_index);
							that.copyToLiveVOD(that, "/" + file_name, "LIVE_vod_" + that.video_id + "/");
						}
					}
				};
				
				fileWriter.onerror = function (e) {
					console.error('Write failed: ' + e.toString());
				};
        
				
				// create XMLHttpRequest for this file
				var xhr = that.createVideoRequest(that, that.getRemoteFileName(that, temp_i), function () {
					var blob = new Blob([xhr.response], {type: 'video/' + that.v_container});

					fileWriter.write(blob); // write blob out
					document.getElementById("check_buffered_duration_" + that.video_id).src = window.URL.createObjectURL(blob);
					that.startPlayingAndWaitForVideo(that, document.getElementById("check_buffered_duration_" + that.video_id), function () {
						that.buffering.tempVideoLoaded(that, a_writer_video_index);
					}, function() {
						that.triggerFileDownload(that, a_writer_video_index, true);
					});
				});
			}); //END fileEntry.createWriter ------------------------------------------
		}); //END fs.root.getFile() --------------------------------------------------
	} //END of XHR_file_writer------------------------------------------------------------
	
	window.requestFileSystem(window.TEMPORARY, 1024 * 1024, XHR_file_writer);
	
} //END of create_file_request--------------------------------------------------------------

//helper function for initalize_reader with callback to initalize reader
//that decrements buffer_to_play index if the file is found in the local 
//directory.
Player.prototype.checkLocalDirectory = function (that, start_reader_i, play_i, buffer_to_play) {
	window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function (fs) {
		// TODO: where does "a_reader_video_index" come from??? (inserted call that. before)
		var temp_i = that.a_reader_video_index % (that.last_index - that.first_index + 1);
		fs.root.getFile(that.play_back_option + "_" + that.reader_playback_extension + that.video_id + "/" + that.getFileNameForQuality(that, that.segment_quality[that.a_reader_video_index]) + temp_i + "." + that.v_container, {}, function (fileEntry) {
			if (fileEntry.isFile === true) {
				that.buffering.initialiseReader(that, ++start_reader_i, play_i, --buffer_to_play);
				that.logger("check local dir is true");
			}
		}, function () {
			that.buffering.initialiseReader(that, ++start_reader_i, play_i, buffer_to_play);
			that.logger("check local dir is false");
		});
	});


}

/** @brief Requests a local file and loads it to a video element
 * 
 * A function that makes a request to access local file then calling 
 * function read_load_video()
 * 
 *..............................................................................
 */
Player.prototype.readFileRequest = function (that, a_reader_video_index, bufferDurationVideo, callbackOnFinish) {

	// TODO: shouldn't the last check be sufficient? The writer should not go past the last index anyways?
	if (a_reader_video_index <= that.last_index && (a_reader_video_index < that.writer_video_index || bufferDurationVideo)) {
		window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function (e) {
			that.readLoadVideo(that, e, a_reader_video_index, bufferDurationVideo, callbackOnFinish);
		});
	}
	else if (a_reader_video_index <= that.last_index && (a_reader_video_index == that.writer_video_index) && !bufferDurationVideo) {
		setTimeout(function() {
			that.readFileRequest(that, a_reader_video_index, bufferDurationVideo, callbackOnFinish);
		}, 400);
	}
}

/**
 *
 * A function that reads video from local directory and loads it
 * to the browser.
 */
Player.prototype.readLoadVideo = function (that, fs, a_reader_video_index, bufferDurationVideo, callbackOnFinish) {
	
	// check if we should load the video into the bufferDurationVideo element
	if(bufferDurationVideo)
	{
		var video_element_to_load = document.getElementById("check_buffered_duration_" + that.video_id);
	}
	else
	{
		// TODO: move this into UI module? Do not "hard-reference" the video-elements here!
		/*!Determine which video element to load based on the reader_video_index 
		  global variable. An even numbered index will be loaded to wvsnp_video_element1 */
		var video_element_to_load = document.getElementById("wvsnp_video" + ((a_reader_video_index % 2) + 1) + "_" + that.video_id);
	}
	//var temp_i = a_reader_video_index % (that.last_index - that.first_index + 1);

	//that.logger("reading file " + that.play_back_option + "_" + that.reader_playback_extension + that.video_id + "/" + that.getFileNameForQuality(that, that.segment_quality[a_reader_video_index]) + a_reader_video_index + "." + that.v_container + (bufferDurationVideo ? ' BUFFER DURATION VIDEO' : ''));
	fs.root.getFile(that.play_back_option + "_" + that.reader_playback_extension + that.video_id + "/" + that.getFileNameForQuality(that, that.segment_quality[a_reader_video_index]) + a_reader_video_index + "." + that.v_container, {}, function (fileEntry) {
		// Get a File object representing the file,
		// then use FileReader to read its contents.
		fileEntry.file(function (file) {
		
			var videoLoadedAlready = false; // flag to prevent double calling
			var reader = new FileReader();
			reader.onloadend = function (e) {
			
				if(!videoLoadedAlready) {
					videoLoadedAlready = true;
				
					// IE will not recognise the blob as mp4-video if not created explicitly.
					// therefore, create a new blob out of "file" here
					var blob = new Blob([file], {type: 'video/' + that.v_container});
					video_element_to_load.src = window.URL.createObjectURL(blob);
					
					// if this is just to load the buffer duration, do not change anything
					if(!bufferDurationVideo)
					{
						// set the video-segment-index for this video-element
						that.video_elements_index[ a_reader_video_index % 2 ] = a_reader_video_index;
						that.logger('Video ' + a_reader_video_index + ' loaded into video');
						
						a_reader_video_index++;
						that.setReaderVideoIndex(that, a_reader_video_index);
						
						if(that.waiting_for_next_segment == true) {
							that.waiting_for_next_segment = false;
						}
					}
					
					if(typeof callbackOnFinish != null && typeof callbackOnFinish != "undefined") {
						// call the callback, presumably a wrapped call to tempVideoLoaded
						callbackOnFinish();
					}
				}
			};
			reader.readAsDataURL(file);
		}, error_handler);
	}, function () {
		that.logger("ERROR read file not found = " + that.read_file + " that.live = " + that.live);
	});
	//    check_buffer();   
}


/** @brief Requests a file from the File System and deletes it.
 * 
 * A function that requests a file from the File System and deletes it.
 * 
 * .............................................................................
 */
Player.prototype.deleteFileRequest = function (that, file_name) {
	
	window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function (fs) {
		fs.root.getFile(file_name, {
			create: false
		}, function (fileEntry) {
			fileEntry.remove(function () {
				that.logger('File ' + file_name + ' removed.');

			}, error_handler);
		}, error_handler);
	}, error_handler);
}

//Called whe a new episode is called to play. Deletes the segments in the 
//LIVE_VOD folder and 
Player.prototype.vodDirNewEpisode = function (that) {
	that.logger("vod_dir_new_episode called");
	if (that.live_episode == that.play_episode) {
		//Deletes videos in LIVE_vod folder
		for (var i = that.first_index; i <= that.last_index; i++) {
			var file_name = "LIVE_vod_" + that.video_id + "/" + that.getFileNameForQuality(that, that.segment_quality[i]) + i + "." + that.v_container;
			that.deleteFileRequest(that, file_name);
		}
		for (var i = that.first_index; i <= that.first_index + 2; i++) {
			var file_name = that.play_back_option + "_" + that.video_id + "/" + that.getFileNameForQuality(that, that.segment_quality[i]) + i + "." + that.v_container;
			that.copyToLiveVOD(that, "/" + file_name, "LIVE_vod_" + that.video_id + "/");
		}

	}
}

error_handler = function (e) {
	var msg = '';

	switch (e.code) {
	case FileError.QUOTA_EXCEEDED_ERR:
		msg = 'QUOTA_EXCEEDED_ERR';
		break;
	case FileError.NOT_FOUND_ERR:
		msg = 'NOT_FOUND_ERR';
		break;
	case FileError.SECURITY_ERR:
		msg = 'SECURITY_ERR';
		break;
	case FileError.INVALID_MODIFICATION_ERR:
		msg = 'INVALID_MODIFICATION_ERR';
		break;
	case FileError.INVALID_STATE_ERR:
		msg = 'INVALID_STATE_ERR';
		break;
	default:
		msg = 'Unknown Error';
		break;
	};

	console.log('Error: ' + msg);
}


//123456789012345678901234567890123456789012345678901234567890123456789012345678